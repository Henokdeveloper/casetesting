﻿using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace ForecastService.FunctionApp.Functions
{
    public class IntegrationMessageFunction
    {
        private readonly ILogger<IntegrationMessageFunction> _logger;

        public IntegrationMessageFunction(ILogger<IntegrationMessageFunction> logger)
        {
            _logger = logger;
        }

        [Function(nameof(HelloWorld))]
        public async Task HelloWorld(
            [ServiceBusTrigger("mytopic", "mysubscription", Connection = "ServiceBusConnectionString")] ServiceBusReceivedMessage message)
        {
            _logger.LogInformation($"Received message: {message.Body}");
            await Task.CompletedTask;
        }
    }
}

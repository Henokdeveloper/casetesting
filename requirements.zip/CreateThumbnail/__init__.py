from azure.storage.blob import BlobServiceClient
import os
import cv2
import numpy as np
import logging
from pathlib import Path
import incucyte_tools
from incucyte_tools.parse import metadata
from azure.storage.blob import BlobServiceClient, generate_blob_sas, BlobSasPermissions
from datetime import datetime, timedelta
import urlpath
from PIL import Image
import io
from azure.identity import DefaultAzureCredential
from other_tools import thumbnails_creation, upload_blob


# --------
from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential
# --------

# Note that function.json needs to be defined correctly otherwise 
# orchestration will fail.

def main(name: str) -> str:

    blob_name = name["converted_blob_name"]
    blob_name_no_ext = blob_name.split(".")[0]
    project_id = name["project_id"]
    experiment_id = name["experiment_id"]
    image_type = name["image_type"]

    userAssignedClientId = "7485cf78-5a87-4f82-89f9-30878fc4d4ea" 
    # source
    source_account_name = "stdevsagcellgridweu"
    source_account_url = f"https://{source_account_name}.blob.core.windows.net"
    origin_container_name = "conformance"
    origin_loc_in_container = f"incucyte/{project_id}/{experiment_id}/fullsize/"
    origin_blob_name_with_location = origin_loc_in_container + blob_name # blob_name_w_path

    # destination
    dest_container_name = "conformance"
    dest_loc_in_container = f"incucyte/{project_id}/{experiment_id}/thumbnails/"

    # create credential and client
    default_credential = DefaultAzureCredential(managed_identity_client_id=userAssignedClientId)
    blob_service_client_origin = BlobServiceClient(account_url=source_account_url, credential=default_credential)
    blob_service_client_origin2 = BlobServiceClient(account_url=source_account_url, credential=default_credential)

    blob_origin = blob_service_client_origin.get_blob_client(container=origin_container_name, blob=origin_blob_name_with_location)
    
    bytes = blob_origin.download_blob().readall()

    try:
        nparr = np.frombuffer(bytes, dtype='uint16')
    except:
        nparr = np.frombuffer(bytes, dtype='uint8')

    img_np = cv2.imdecode(nparr, cv2.IMREAD_UNCHANGED)

    if image_type == "Ph":

        thumbnail_info, create_thumbnail = thumbnails_creation.phase_img_thumbnail(
            img_np, 
            blob_name_no_ext, 
            blob_service_client_origin, 
            dest_container_name, 
            dest_loc_in_container
        )
    
    elif image_type == "Seed":
        logging.info("this was a seed image -  no thumbnails are created")
        
    else:
        
        thumbnail_info, create_thumbnail = thumbnails_creation.channel_img_thumbnail(
                img_np, 
                blob_name_no_ext, 
                blob_service_client_origin, 
                dest_container_name, 
                dest_loc_in_container
            )
        
    thumbnail_name = thumbnail_info["name"]
        
    dest_blob_full_path = f"{source_account_url}/{dest_container_name}/{dest_loc_in_container}{thumbnail_name}"

    payload = {
        "thumbnail":{
            "name": thumbnail_info["name"], 
            "resolution": thumbnail_info["resolution"], 
            "quality": thumbnail_info["quality"], 
            "uri": dest_blob_full_path
        },
        "convert_img_payload": name
    }

    logging.info("payload: %s", payload)
    return payload
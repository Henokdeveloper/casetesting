import incucyte_tools
from incucyte_tools.parse import metadata
import os
import datetime
from pathlib import Path
from datetime import timezone, datetime

# from random import randint
# import cv2
# from PIL import Image
# import numpy as np
# import collections
# import getpass
# import pymongo


def utc_timestamp() -> str:
    """
    This functions is to be used for logging the timestamps
    where image transformations need to be recorded in the metadata of
    "derived" data, in the filtered metadata document
    """
    dt = datetime.now(timezone.utc)
    utc_timestamp = (dt.replace(tzinfo=timezone.utc)).isoformat()

    return utc_timestamp

class RawImageMetadata:
    """
    Raw metadata document format has the structure
    {
        "_id": ObjectId("..."),
        "Timestamp: "timestamp",
        "Type": "Incucyte Microscopy Image",
        "Metadata":{
            "AcquisitionInfo": {},
            "DeviceInfo": {}, 
            "FirmwareInfo": {}, 
            "ScanInfo": {}, 
            "Other" :{ this section is not raw from the metadata, but it is built into it}
        },
        "Data: {}
    }
    """
    def __init__(self, image_metadata, source_img_loc):
        self.img_metadata = image_metadata
        self.img_source_location = source_img_loc

    def metadata_other_key(self):
        """
        Returns a dictionary with the following fields
        that are needed for raw and filtered metadata
        """

        # get other fields in dict
        # convert timestamp from datetime to ISO 8601 format
        other_info ={
            "Timestamp": self.img_metadata.timestamp.isoformat(), 
            "Well": self.img_metadata.well,
            "ImageIndex": self.img_metadata.image_index, 
            "VesselID": self.img_metadata.vessel_id,
            "MetadataVersion": self.img_metadata.metadata_version, 
            "ExactScanTime": self.img_metadata.exact_scan_time.isoformat(),
            "ImageName": (self.img_metadata.image_name).split(".")[0],
            "ImageType": self.img_metadata.image_type
        }

        return other_info

    
    def metadata_key(self):
        """
        This fucntion populates the Metadata key in the daw metadata document
        "metadata": {}
        """
        # get the main fields 
        # ["acquisition_info", "device_info", "firmware_info", "scan_info"] into a dict
        metadata_dict = {
            "AcquisitionInfo": self.img_metadata.acquisition_info,
            "DeviceInfo": self.img_metadata.device_info,
            "FirmwareInfo": self.img_metadata.firmware_info,
            "ScanInfo": self.img_metadata.scan_info, 
            "OtherInfo": self.metadata_other_key()
        }
        return metadata_dict
        

    def data_raw_key(self):
        """
        Data section in the document for Cosmos DB needs format
        Data:{
            Raw: {},
            Derived: {}
        }

        Where
        Raw:{
            "ImageType": "i.e. Phase",
            "Uri": "Uri", 
            "Timestamp": "timestamp
        }
        """

        # timestamp below is metadata.timestamp and NOT timestamp.exact_scan_time
        #  as per documentation
        # see https://dev.azure.com/sartorius-cr-ada/Deep.Learning/_wiki/wikis/Deep.Learning.wiki/109/Metadata-structure
        
        data_raw = {
            "ImageType": self.metadata_other_key()["ImageType"],
            "Uri": self.img_source_location, 
            "Timestamp":(self.metadata_other_key()["Timestamp"])
        }
        return data_raw
    

    def raw_document(self):
        """
        This function returns the complete document format as explained at the beginning of the class

        Please note the document_type = "Incucyte Microscopy Image" should NOT be changed unless agreed upon with 
        maria.caroprese@sartorius.com
        """

        document_type = "Incucyte Microscopy Image"

        raw_document = {
            "Timestamp": self.img_metadata.timestamp.isoformat(),
            "Type": document_type, 
            "Metadata": self.metadata_key(),
            "Data":{
                "Raw": self.data_raw_key()
            }
        }
        return raw_document
    

class FilteredImageMetadata:
    def __init__(self, image_metadata, experiment_name, img_source_location, img_dest_location, thumbnail_info):
        self.img_metadata = image_metadata
        self.img_source_location = img_source_location
        self.experiment_name = experiment_name
        self.img_dest_location = img_dest_location
        self.thumbnail_info = thumbnail_info

    def select_filtered_metadata_fields(self):
        """
        This function selects the agreed metadata fields to be in the filtered document
        as documented in 
        https://dev.azure.com/sartorius-cr-ada/Deep.Learning/_wiki/wikis/Deep.Learning.wiki/109/Metadata-structure
        """

        acquisition_info = self.img_metadata.acquisition_info
        device_info = self.img_metadata.device_info
        scan_info = self.img_metadata.scan_info

        metadata_dict = {
            "AcquisitionInfo": {
                "ObjectiveMagnification": acquisition_info["ObjectiveMagnification"],
                "ImageType":acquisition_info["ImageType"],
                "Location":{
                    "ImagesPerWellorSector": acquisition_info["Location"]["ImagesPerWellorSector"]
                },
                "CameraSettings": {
                    "BitsPerPixel": acquisition_info["CameraSettings"]["BitsPerPixel"]
                },
                "Timestamp": acquisition_info["TimeStamp"]
            },
            "DeviceInfo":{
                "IncuCyteID": device_info["IncuCyteID"],
                "OpticalModule": ImageDetails(self.img_metadata).get_colour_channels()
            },
            "ScanInfo": {
                "VesselID": scan_info["VesselID"],
                "ScanType": scan_info["ScanType"],
                "Labware":{
                    "Name": scan_info["Labware"]["Name"]
                }
            }
        }
        other_info = RawImageMetadata(self.img_metadata, self.img_source_location).metadata_other_key()
        #TODO line above needs to be updated where sample image = image location 
        metadata_dict.update({"OtherInfo": other_info})

        return metadata_dict
    

    
    def derived_full_size_key(self):
        #TODO add timestamp in CET
        """
        example:
        "Derived" : {
			"FullSize" : {
				"ImageName" : "A1-1_Vessel-518_2022-04-12_14h00m00s_C1.png",
				"Uri" : "https://sartcompanalyticsdev.blob.core.windows.net/conformance/cell_grid/experiments/20221006_Coculture_NHDF_SKBR3/fullsize/A1-1_Vessel-518_2022-04-12_14h00m00s_C1.png",
				"Timestamp" : "2022-04-12T14:00:00"
                }
            }
        """

        image_name = ImageDetails(self.img_metadata).image_name_no_ext() 
        
        #TODO thumbnails here is hardcoded, need to change it to use the function
        full_size = {
            "ImageName": image_name + ".png",
            "Uri": self.img_dest_location,
            "Timestamp": utc_timestamp(), 
            "Thumbnails":[
                            {
                                "ImageName": self.thumbnail_info["name"], 
                                "Resolution": self.thumbnail_info["resolution"], 
                                "Quality": self.thumbnail_info["quality"],
                                "Uri": self.thumbnail_info["uri"], 
                                "Timestamp": utc_timestamp()
                            }
                        ]} #self.img_metadata.timestamp.isoformat()}
        
        return full_size
    
    def thumbnails_metadata(self):

        thumbnail_metadata = {
            "ImageName": self.thumbnail_info["name"], 
            "Resolution": self.thumbnail_info["resolution"], 
            "Quality": self.thumbnail_info["quality"],
            "Uri": self.thumbnail_info["dest_full_path"], 
            "Timestamp": utc_timestamp()
        }

        return thumbnail_metadata

    def filtered_document(self):

        
        metadata_section = self.select_filtered_metadata_fields()
        data_raw_section = RawImageMetadata(self.img_metadata, self.img_source_location).data_raw_key()
        image_type = ImageDetails(self.img_metadata).image_type()

        if image_type == "Seed":
            filtered_document = {
                "Timestamp": self.img_metadata.timestamp.isoformat(),
                "Type": "Incucyte Microscopy Image", 
                "Metadata": metadata_section,
                "Data":{
                    "Raw": data_raw_section
                }
            }
            return filtered_document

        else:

            filtered_document = {
                "Timestamp": self.img_metadata.timestamp.isoformat(),
                "Type": "Incucyte Microscopy Image", 
                "Metadata": metadata_section,
                "Data":{
                    "Raw": data_raw_section,
                    "Derived":{
                        "FullSize": self.derived_full_size_key(), 
                        }
                }
            }

            return filtered_document
    


class ImageDetails:
    def __init__(self, image_metadata):
        self.img_metadata = image_metadata
    
    def image_name_no_ext(self) -> str:
        """
        takes in image metadata and returns the image name
        without extension
        i.e. A2-18_Vessel-176_2021-10-14_08h39m00s_Ph
        """
        org_name = self.img_metadata.image_name
        image_name = org_name.split(".")[0]
        
        return image_name
    
    
    def image_name_png_full_size(self) -> str:
        """
        Uses the unique image name with no extension and returns 
        the image name with png
        """
        return f"{self.image_name_no_ext()}.png"
    
    
    def image_type(self) ->str:
        """
        Takes in the image name, and takes the last element after "_" of the string
        which indicates the image type. 
        Image type can refer to 
        Ph = phase image
        C1, C2, C3, ... channel images
        Seed = Seed
        #TODO Unsure if there can be more? Can check with BioA team for this
        """

        image_name = self.image_name_no_ext()
        image_type = image_name.split("_")[-1]
        return image_type

    def get_colour_channels(self) -> dict:
        """
        Dynamically retrieves the number of colour channels available
        and returns a dictionary of the colour channel and its name
        i.e. {'ColorChannel1': {'Name': 'Green'}, 'ColorChannel2': {'Name': 'Red'}}
        this is to be consistent with the original raw metadata structure 
        """
        optical_module = self.img_metadata["device_info"]["OpticalModule"]
        colour_channels = {}
        for k in optical_module:
            if k.startswith("ColorChannel"):
                colour_channels[k] = {"Name": optical_module[k]["Name"]}

        return colour_channels





class OtherMetadataFields():
    def __init__(self, thumbnail_metadata, ml_model_metadata):
        self.thumbnail_meta = thumbnail_metadata, 
        self.ml_model_meta = ml_model_metadata
        

    
    
    def ml_model(self):
        #TODO still need to figure out how the following values will be passed
        # model details are not part of image metadata, they need to be created
        # perhaps having a sql table with all models, model ids, colours and so on?

        # uris can be passed as payload in durable orchestration

        image_name = self.ml_model_meta["ImageName"]
        model_name = self.ml_model_meta["ModelName"]
        model_id = self.ml_model_meta["ModelID"]
        mask_colour = self.ml_model_meta["MaskColour"]
        objective = self.ml_model_meta["Objective"]
        uri_to_annotation_json  = self.ml_model_meta["UriToAnnotationJson"]
        uri_to_annotation_img  = self.ml_model_meta["UriToAnnotationImg"]
        uri_to_mask_img = self.ml_model_meta["UriToMaskImg"]
        
        ml_model_metadata = {
							"ImageName" : image_name,
							"ModelName" : model_name,
							"ModelID" : model_id,
							"MaskColour" : mask_colour,
							"Objective" : objective,
							"UriToAnnotationJson" :uri_to_annotation_json,
							"UriToAnnotationImg" : uri_to_annotation_img,
							"Timestamp" : utc_timestamp(),
							"MaskInfo" : {
								"UriToMaskImg" : uri_to_mask_img,
								"Thumbnails" : [
									self.thumbnails()
								]
							}
						}
        
        return ml_model_metadata



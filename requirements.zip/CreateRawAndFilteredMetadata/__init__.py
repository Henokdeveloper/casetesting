import json
import logging
import metadata_tracker.metadata_extraction as metadata_extraction
from other_tools.sas_url import generate_blob_sas_url
from azure.storage.blob import BlobServiceClient
from incucyte_tools.parse import metadata
import azure.functions as func
from azure.identity import DefaultAzureCredential
from azure.cosmos import CosmosClient, PartitionKey
import urlpath
import os
from azure.keyvault.secrets import SecretClient
import uuid
import json
# import pymongo no longer needed

def insert_sample_document(collection, field_to_add):
    """Insert a sample document and return the contents of its _id field"""
    document_id = collection.insert_one(field_to_add).inserted_id
    print("Inserted document with _id {}".format(document_id))
    return document_id

def create_database_unsharded_collection(client, db_name, unsharded_collection_name):
    """Create sample database with shared throughput if it doesn't exist and an unsharded collection"""
    db = client[db_name]

    # Create database if it doesn't exist
    if db_name not in client.list_database_names():
        # Database with 400 RU throughput that can be shared across the DB's collections
        db.command({'customAction': "CreateDatabase", 'offerThroughput': 400})
        print("Created db {} with shared throughput". format(db_name))

        #logging.info("indexes: %s", db[unsharded_collection_name].index_information())
    
    return db[unsharded_collection_name]

def create_collection(client, db_name, unsharded_collection_name):
    """Create sample database with shared throughput if it doesn't exist and an unsharded collection"""
    db = client[db_name]
        
    
    # Create collection if it doesn't exist
    if unsharded_collection_name not in db.list_collection_names():
        # Creates a unsharded collection that uses the DBs shared throughput
        db.command({'customAction': "CreateCollection", 'collection': unsharded_collection_name})
        print("Created collection {}". format(unsharded_collection_name))
        # create index for timestamp - required for the cell-grid app
        db.unsharded_collection_name.create_index({"Timestamp": 1})  
        #logging.info("indexes: %s", db[unsharded_collection_name].index_information())
    
    return db[unsharded_collection_name]

def upload_json_to_storage(img_png_bytes, name, blob_service_client, container_name, blob_path):
        
    converted_blob_name = name + '.png'
    blob_dest = blob_service_client.get_blob_client(container=container_name, blob = blob_path + converted_blob_name)
    blob_dest.upload_blob(img_png_bytes)
    return converted_blob_name



def main(name: str) -> str:

    origin_blob_full_path = name["convert_img_payload"]["origin_blob_full_path"]
    dest_blob_full_path = name["convert_img_payload"]["dest_blob_full_path"]
    converted_blob_name = name["convert_img_payload"]["converted_blob_name"]
    project_id = name["convert_img_payload"]["project_id"]
    experiment_id = name["convert_img_payload"]["experiment_id"]

    blob_access = name["convert_img_payload"]["blob_access"]
    account_name = blob_access["account_name"]
    origin_container = blob_access["container"]
    account_url = blob_access["account_url"]
    relative_path_to_blob = blob_access["relative_path"]

    thumbnail_info = name["thumbnail"]
    # thumbnail_name = name["thumbnail"]["name"]
    # thumbnail_dest_full_path = name["thumbnail"]["dest_full_path"]

    logging.info("origin_blob_full_path: %s, dest_blob_full_path: %s, experiment_id: %s", origin_blob_full_path, dest_blob_full_path, experiment_id)
    

    # get access to the blob to get its metadata
    # ---------------------------------------------------------------------------------------------------------
    userAssignedClientId = "7485cf78-5a87-4f82-89f9-30878fc4d4ea" 
    # create credential and client
    default_credential = DefaultAzureCredential(managed_identity_client_id=userAssignedClientId)
    blob_service_client_origin = BlobServiceClient(account_url=account_url, credential=default_credential)

    origin_blob_url = generate_blob_sas_url(
                                            blob_service_client_origin,
                                            account_name,
                                            origin_container,
                                            relative_path_to_blob
                                            )

    logging.info("this is the image url %s", origin_blob_url)
    img_metadata = metadata.get_image_metadata(urlpath.URL(origin_blob_url))

    # create raw metadata dict
    raw_metadata = metadata_extraction.RawImageMetadata(img_metadata, origin_blob_full_path).raw_document()
    logging.info("raw_metadata %s", raw_metadata)

    # create filtered metadata dict
    filtered_metadata = metadata_extraction.FilteredImageMetadata(img_metadata, experiment_id, origin_blob_full_path, dest_blob_full_path, thumbnail_info).filtered_document() 
    logging.info("filtered_metadata %s", filtered_metadata)


    # get cosmos connection string from key-vault
    # ---------------------------------------------------------------------------------------------------------
    kv_name = "kv-dev-sag-cellgrid-weu"
    kv_uri = f"https://{kv_name}.vault.azure.net"
    token_credential = DefaultAzureCredential()
    kv_client = SecretClient(vault_url=kv_uri, credential=token_credential)

    secret_name = "devCellGridCosmosDb" 
    secret_val = (kv_client.get_secret(secret_name)).value
    

    # connect to cosmosdb for NoSQL
    # ---------------------------------------------------------------------------------------------------------

    cosmos_client = CosmosClient.from_connection_string(secret_val)
    logging.info("successful connection to CosmosDB")


    raw_db = "raw_metadata"
    filtered_db = "filtered_metadata"
    db_name = "ExperimentImages"



    # create database in cosmosdb if it does not exist
    # filtered_database = cosmos_client.create_database_if_not_exists(id=db_name)
    
    # create container if it does not exist
    #TODO check with Ram on RUs: This can be done per database
    # rus = 400
    # partition_key = PartitionKey(path="/Timestamp")
    # container = filtered_database.create_container_if_not_exists(
    #     id=experiment_id,
    #     partition_key=partition_key,
    #     offer_throughput=rus
    # )

    container_name = "Images"
    database = cosmos_client.get_database_client(db_name)
    container = database.get_container_client(container_name)

    # raw metadata collection -> we don;t need anymore, need to save as json
    # raw_collection = create_database_unsharded_collection(client, raw_db, experiment_id)
    # raw_doc = insert_sample_document(raw_collection, raw_metadata)
    # logging.info("raw_metadata with of experiment %s with id %s", experiment_id, raw_doc)


    #create item within container
    # id filed must be added to filtered metadata dictionary as requirement by NoSQL
    doc_id = str(uuid.uuid4())
    filtered_metadata["id"] = doc_id
    filtered_metadata["ProjectId"] = project_id
    filtered_metadata["ExperimentId"] = experiment_id

    container.create_item(filtered_metadata)

    # save raw metadata in azure storage
    # save file with unique name
    blob_name = converted_blob_name.split(".")[0]
    raw_metadata_filename = f"{blob_name}.json"
    # convert dict to json string
    raw_metadata_json = json.dumps(raw_metadata)
    blob_service_client_origin
    # blob client
    dest_container = "conformance"
    dest_path = f"incucyte/experiments/{project_id}/{experiment_id}/raw_metadata/"
    blob_dest = blob_service_client_origin.get_blob_client(container=dest_container, blob = dest_path + raw_metadata_filename)
    blob_dest.upload_blob(raw_metadata_json, overwrite=True)

    payload = {
        "convert_img_payload": name["convert_img_payload"], 
        "thumbnail_payload": name["thumbnail"]
    }

    return payload
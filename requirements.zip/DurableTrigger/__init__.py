import logging
import azure.functions as func
from azure.durable_functions import DurableOrchestrationClient

from incucyte_tools import image_tools

def payload_info(blob_url: str) -> dict:
    """
    This function uses the blob url and the folder name
    which can only be cell_grid or v7_upload 
    to return the needed payload that is then passed for 
    durable orchestration function

    archive:
    - standard: original nested folder structure as data is compiled from the incucyte
    - flexible: folder structure is independent from original incucyte nested folder structure
    """
    container_name = "landing"
    archive_standard = "standard" 
    archive_flexible = "flexible"
    
    archives = [archive_standard, archive_flexible]
    
    blob_name = blob_url.split("/")[-1]
    blob_url_container_split = blob_url.split(f"{container_name}/")
    storage_url = blob_url_container_split[0]
    path_to_blob = blob_url_container_split[-1]

    # folder_split = blob_url.split(folder_name)[-1]
        # check type or archive structure 

    for arc in archives:

        if arc in path_to_blob:
            archive_str = f"{arc}/"
            archive_split = path_to_blob.split(archive_str)[-1] 
            info = archive_split.split("/")
            project_id = info[0]
            experiment_id = info[1]
            
            payload = {
                "blob_name": blob_name,  
                "project_id": project_id,
                "experiment_id": experiment_id, 
                "path_to_blob": path_to_blob, 
                "container": container_name, 
                "blob_url": blob_url, 
                "archive_type": arc, 
                "storage_url": storage_url
            }

            # do I need landing_folder? 

            return payload
        


async def main(event: func.EventGridEvent, starter: str):
   
    function_name = "DurableOrchestration"
    logging.info('STARTER = ' + starter)

    # create a payload which is passed to next function
    blob_url = event.get_json().get('url')  

    incucyte_folder = "incucyte"

    if incucyte_folder in blob_url:
            payload = payload_info(blob_url)

    else:
            print("data was not uploaded to the correct location")

    logging.info("blob_url = " + str(blob_url))

    logging.info("payload = " + str(payload))
    client = DurableOrchestrationClient(starter)

    await client.start_new(function_name,None,payload)

from azure.storage.blob import BlobServiceClient
import os
import cv2
import numpy as np
import logging
from pathlib import Path
import incucyte_tools
from incucyte_tools.parse import metadata
from azure.storage.blob import BlobServiceClient, generate_blob_sas, BlobSasPermissions
from datetime import datetime, timedelta
import urlpath
from PIL import Image
import io
from azure.identity import DefaultAzureCredential, ManagedIdentityCredential, AzureCliCredential, ChainedTokenCredential


# Blob tif file is converted to a png file.
# Note that function.json needs to be defined correctly otherwise 
# orchestration will fail.

# TODO how many image channels can there ever be and what colours are they assigned?   
# color_c1 = (36, 255, 60) # green
# color_c2 = (252,107,3) # orange
# color_c3 = (38, 183, 188) # tail

def get_image_name(metadata):
    """
    Returns the name of the image, with no extension
    """
    tif_name = metadata.image_name 
    image_name = tif_name.split(".")[0]
    return(image_name)

def generate_blob_sas_url(blob_service_client, account_name, container_name,blob_name_w_path):
    """
    Produces a string of required blob url with sas permissions
    """
    udk = blob_service_client.get_user_delegation_key(
        key_start_time=datetime.utcnow() -  timedelta(hours=1), 
        key_expiry_time=datetime.utcnow() + timedelta(hours=1)
    )
    sas = generate_blob_sas(
        account_name=account_name,
        container_name=container_name, 
        blob_name=blob_name_w_path, 
        user_delegation_key=udk, 
        permission=BlobSasPermissions(read=True),
        start=datetime.utcnow() - timedelta(minutes=15),
        expiry = datetime.utcnow() + timedelta(hours=2)
    )

    origin_blob_url = f'https://{account_name}.blob.core.windows.net/{container_name}/{blob_name_w_path}?{sas}'

    return origin_blob_url


def convert_channel_image_tif_to_png(image_8bit, color_channel):
    """
    This function takes as input the 8 bit image and 
    the channel colour required 
    
    it returns the image saved in the location required
    """
    image_8bit_transparent = incucyte_tools.image_tools.make_transparent_flr_image(image_8bit, color_channel)
    pil_image_transparent = Image.fromarray(image_8bit_transparent)
    buffer = io.BytesIO()
    pil_image_transparent.save(buffer, "PNG")
    content = buffer.getvalue()
    img_png_bytes = content
    return img_png_bytes    

def upload_png_bytes_to_dest_blob(img_png_bytes, name, blob_service_client, container_name, blob_path):
        
    converted_blob_name = name + '.png'
    blob_dest = blob_service_client.get_blob_client(container=container_name, blob = blob_path + converted_blob_name)
    blob_dest.upload_blob(img_png_bytes)
    return converted_blob_name

def get_colour_channels(img_metadata):
    """
    Dynamically retrieves the number of colour channels available
    and returns a dictionary of the colour channel and its name
    i.e. {'ColorChannel1': {'Name': 'Green'}, 'ColorChannel2': {'Name': 'Red'}}
    this is to be consistent with the original raw metadata structure 
    """
    optical_module = img_metadata.device_info["OpticalModule"]
    colour_channels = {}
    for k in optical_module:
        if k.startswith("ColorChannel"):
            colour_channels[k] = {"Name": optical_module[k]["Name"]}
            #colour_channels.update(mydict)

    return colour_channels

#TODO what are all possible channel colour names?
channel_colour = dict({
    "green": (36, 255, 60), 
    "orange": (252,107,3),
    "tail": (38, 183, 188), 
    "red": (255, 0, 0), 
    "nir": (38, 183, 188)
})

def channel_and_colour_img_conv(colour_channels):
    """
    This function takes the input as it comes from the metadata in a dict format
    input i.e. {'ColorChannel1': {'Name': 'Green'}, 'ColorChannel2': {'Name': 'Red'}}
    and returns a nested dictionary with 
    colour channel and colour, which can be used as a guide for image conversion of
    channel images from tif to png in another function #TODO name function
    returns i.e. {'C1': 'green', 'C2': 'red'}
    """
    channel_and_colour = dict()

    for count, key in enumerate(colour_channels):
        colour = colour_channels[key]["Name"].lower()
        channel = f"C{count + 1}"
        output_dir = {channel: colour}
        channel_and_colour.update(output_dir)

    return channel_and_colour


def main(name: str) -> str:
    
    logging.info("this is the image url %s", name)

    userAssignedClientId = "7485cf78-5a87-4f82-89f9-30878fc4d4ea" 
    
    project_id = name["project_id"]
    experiment_id = name["experiment_id"]
    blob_name = name["blob_name"]
    # landing_folder = name["landing_folder"] # if works won't need this #TODO delete if it works
    origin_path_to_blob = name["path_to_blob"]
    image_type = (blob_name.split('-')[-1]).split(".")[0]
    origin_blob_full_path = name["blob_url"]
    storage_url = name["storage_url"]

    # source
    source_account_url = storage_url
    source_account_name = storage_url.split(".")[0].split("/")[-1]
    source_container = "landing" 
    
    # destination
    # source and destination are in the same storage account so in this script source and destination can point to storage_url
    dest_account_url = storage_url 
    dest_account_name = dest_account_url.split(".")[0].split("/")[-1]
    dest_container = "conformance" 
    dest_path_to_blob = f"incucyte/{project_id}/{experiment_id}/fullsize/"

    

    # create credential and client
    default_credential = DefaultAzureCredential(managed_identity_client_id=userAssignedClientId)

    # managed_identity = ManagedIdentityCredential(client_id=userAssignedClientId) 
    # azure_cli = AzureCliCredential() 
    # default_credential = ChainedTokenCredential(managed_identity, azure_cli)

    blob_service_client_origin = BlobServiceClient(account_url=source_account_url, credential=default_credential)
    blob_service_client_origin2 = BlobServiceClient(account_url=dest_account_url, credential=default_credential)


    origin_blob_url = generate_blob_sas_url(
                                            blob_service_client_origin,
                                            source_account_name,
                                            source_container,
                                            origin_path_to_blob
                                            )

    logging.info("this is the image url %s", origin_blob_url)
    
    img_metadata = metadata.get_image_metadata(urlpath.URL(origin_blob_url))
    logging.info("this is the img_metadata %s", img_metadata)
    unique_image_name = get_image_name(img_metadata)
    logging.info("this is the unique_image_name %s", unique_image_name)
    dest_blob_full_path = f"{dest_account_url}/{dest_container}/{dest_path_to_blob}{unique_image_name}.png"

    logging.info("unique image name = %s", unique_image_name)
    temp = unique_image_name.split("-")[-1] 
    img_channel = temp.split("_")[-1]
    logging.info("image channel = %s", img_channel)
    

    if img_channel == "Ph":
        blob_origin = blob_service_client_origin.get_blob_client(container=source_container, blob=origin_path_to_blob)
        bytes = blob_origin.download_blob().readall()
        
        try:
            nparr = np.frombuffer(bytes, dtype='uint16')
        except:
            nparr = np.frombuffer(bytes, dtype='uint8')
        
        im_nparr = cv2.imdecode(nparr, cv2.IMREAD_UNCHANGED)
        _, img_encode = cv2.imencode('.png', im_nparr)
        img_png_bytes = img_encode.tobytes()
        
    elif img_channel != "Ph" and img_channel != "Seed":
            
        im = incucyte_tools.io.read_image(urlpath.URL(origin_blob_url), attempt_conversion=True) # attempt_conversion=True is applicable to 16-bit images only and scales them properly to 32-bit
        logging.info("type(im) = %s", type(im))
        image_8bit = np.uint8((im / im.max()) * 255)
        logging.info("type(image_8bit) = %s", type(image_8bit))

        colour_channels = get_colour_channels(img_metadata) # returns i.e. i.e. {'ColorChannel1': {'Name': 'Green'}, 'ColorChannel2': {'Name': 'Red'}}
        c_and_colour = channel_and_colour_img_conv(colour_channels) # returns i.e. {'C1': 'green', 'C2': 'red'}
        
        # use img_channel to pass the correct colour argument
        colour_name = c_and_colour[img_channel]
        colour_rgb = channel_colour[colour_name]
        
        #convert the image
        img_png_bytes = convert_channel_image_tif_to_png(image_8bit, colour_rgb)
        
    else:
        logging.info("Unknown or seed image channel used: %s", img_channel)
        img_png_bytes = None
   

    logging.info("type(img_png_bytes): %s",type(img_png_bytes))
    
    if img_png_bytes != None:
        
        logging.info("excuting upload_png_bytes_to_dest_blob")
        converted_blob_name = upload_png_bytes_to_dest_blob(
                                                            img_png_bytes, 
                                                            unique_image_name, 
                                                            blob_service_client_origin2,
                                                            dest_container, 
                                                            dest_path_to_blob
                                                            )
    else:
        converted_blob_name = ""
        logging.info("byte image to be uploaded has incorrect format/image channel incorrect")

    
    # This needs to be defined since None returns are not allowed.
    
    payload = {
        "origin_blob_full_path": origin_blob_full_path,
        "dest_blob_full_path":dest_blob_full_path,
        "converted_blob_name": converted_blob_name,
        "project_id": project_id,
        "experiment_id": experiment_id,
        "image_type": image_type, 
        "blob_access":{
            "account_name": source_account_name,
            "account_url": source_account_url,
            "container": source_container, 
            "relative_path": origin_path_to_blob
        }
    }
    logging.info("payload: %s", payload)
    
    return payload
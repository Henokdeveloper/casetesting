from datetime import datetime
from pathlib import Path
from typing import Optional, Sequence, Dict, Any, Generator, Tuple
from typing import *
from dataclasses import dataclass
from xml.etree import ElementTree
import io
import pandas as pd
import numpy as np
import tifffile

from incucyte_tools.io import force_local_path


@dataclass
class ImageMetaData:
    timestamp: datetime
    well: str
    image_index: int
    vessel_id: str
    metadata_version: str
    exact_scan_time: datetime
    image_name: str
    image_type: str

    # The following fields are parsed into nested-dicts because I haven't checked
    # whether their fields vary depending on the image-type. I believe that it is
    # the case since I found no conversion-factor in a phase-image, which I know
    # is present in fluorescence-ones.
    firmware_info: Dict[str, Union[Dict, str]]
    acquisition_info: Dict[str, Union[Dict, str]]
    device_info: Dict[str, Union[Dict, str]]
    scan_info: Dict[str, Union[Dict, str]]

    def __getitem__(self, item):
        # To ensure backwards compatibility on dict-based lookups.
        return getattr(self, item)


class ArchiveFilter:

    """ Store parameters to use for filter images. """

    def __init__(self,
                 *,
                 well: Optional[Sequence[str]] = None,
                 min_timestamp: Optional[datetime] = None,
                 max_timestamp: Optional[datetime] = None,
                 timestamp: Optional[Sequence[datetime]] = None,
                 image_index: Optional[Sequence[int]] = None,
                 vessel_id: Optional[Sequence[str]] = None,
                 image_type: Optional[Sequence[str]]=None):
        if timestamp is not None:
            if min_timestamp is not None or max_timestamp is not None:
                raise ValueError('param timestamps cannot be used at the same time as min_timestamp or max_timestamp')

        if (min_timestamp and max_timestamp) and (min_timestamp > max_timestamp):
            raise ValueError('min_timestamp should not be larger than max_timestamp')

        self.well = well
        self.min_timestamp = min_timestamp
        self.max_timestamp = max_timestamp
        self.timestamp = timestamp
        self.image_index = image_index
        self.vessel_id = vessel_id
        self.image_type = image_type

    @classmethod
    def from_dict(cls, filters: Dict[str, Any]):
        # Should probably implement some more input checking.
        return cls(**filters)

    def __repr__(self):
        class_name = self.__class__.__name__
        argument_strings = list()
        for key, value in self.__dict__.items():
            if value is not None:
                argument_strings.append(f'{key}={value}')
        return f'{class_name}({", ".join(argument_strings)})'

    def to_dict(self) -> Dict[str, Any]:
        filter_dict = {key: value for key, value in self.__dict__.items() if value is not None}
        return filter_dict


def parse_archive(archive_root: Path,
                  image_type: str = 'Ph',
                  archive_filter: Optional[ArchiveFilter] = None) -> Generator[Tuple[dict, Path], None, None]:
    scan_root = archive_root / 'EssenFiles' / 'ScanData'
    assert scan_root.exists(), 'Not a valid Essen archive'

    for image_path in scan_root.glob(f'*/**/*-{image_type}.tif'):
        metadata = get_image_metadata(image_path)
        if archive_filter is not None:
            if not filter_matches_metadata(archive_filter, metadata):
                continue
        yield metadata, image_path


def filter_matches_metadata(archive_filter: ArchiveFilter, metadata: Dict) -> bool:
    """ Compare filter to metadata-dictionary.

    Parameters
    ----------
    archive_filter : ArchiveFilter
        Filter to use (possibly empty).
    metadata : Dict
        Keyed by "well", "timestamp", "image_index" and "vessel_id"

    Returns
    -------
    True if metadata falls within domain defined by `archive_filter`
    """
    timestamp = metadata['timestamp']
    if archive_filter.min_timestamp and timestamp <= archive_filter.min_timestamp:
        return False
    if archive_filter.max_timestamp and archive_filter.max_timestamp <= timestamp:
        return False
    if archive_filter.timestamp and (timestamp not in archive_filter.timestamp):
        return False
    if archive_filter.well and metadata['well'] not in archive_filter.well:
        return False
    if archive_filter.image_index and metadata['image_index'] not in archive_filter.image_index:
        return False
    if archive_filter.vessel_id and metadata['vessel_id'] not in archive_filter.vessel_id:
        return False

    return True


def get_image_metadata(image_path: Path) -> ImageMetaData:
#def get_image_metadata(path: str) -> ImageMetaData:    
    with force_local_path(image_path) as path:
        with tifffile.TiffFile(str(path)) as tif:
            tif_tags = {}
            num_pages = len(tif.pages)
            for tag in tif.pages[num_pages - 1].tags.values():
                name, value = tag.name, tag.value
                tif_tags[name] = value

    cleaned_image_info_content = tif_tags['60020'].replace('\n', '')
    image_info_xml = ElementTree.parse(io.StringIO(cleaned_image_info_content)).getroot()
    assert image_info_xml.tag == 'ImageInfo'

    firmware_info = _xml_to_dict(image_info_xml.find('FirmwareInfo'))
    acquisition_info = _xml_to_dict(image_info_xml.find('AcqInfo'))
    device_info = _xml_to_dict(image_info_xml.find('DeviceInfo'))
    scan_info = _xml_to_dict(image_info_xml.find('ScanInfo'))

    well = acquisition_info['Location']['WellorSector']
    img_i = acquisition_info['Location']['UnityBasedImageIndex']
    timestamp = _parse_scan_date_time(scan_info['ScanDateTime'])

    vessel_id = scan_info['VesselID']
    meta = {
        'well': well,
        'image_index': img_i,
        'vessel_id': vessel_id,
        'timestamp': timestamp
    }
    image_type = image_path.stem.split('-')[-1]
    image_name = _format_name(meta, image_path, image_type)

    metadata = ImageMetaData(
        timestamp=timestamp,
        well=well,
        image_index=int(img_i),
        vessel_id=vessel_id,
        metadata_version=image_info_xml.find('IncuCyteMetadataVersion').text,
        firmware_info=firmware_info,
        acquisition_info=acquisition_info,
        device_info=device_info,
        scan_info=scan_info,
        exact_scan_time=datetime.strptime(tif_tags['DateTime'], '%Y:%m:%d %H:%M:%S'),
        image_type=image_type,
        image_name=image_name,
    )
    return metadata


def get_archive_metadata(archive_root: Path) -> pd.DataFrame:
    """ Parse metadata of all images in archive.

    Parameters
    ----------
    archive_root : Path
        Root of archive to parse.

    Returns
    -------
    DataFrame
        columns: [timestamp, well, image_index, vessel_id, image_type, path]
    """
    contents = list(parse_archive(archive_root, '*'))
    metadata, paths = list(zip(*contents))
    image_types = [path.stem.rsplit('-', maxsplit=1)[-1] for path in paths]
    standard_names = [_format_name(meta, paths[i], image_types[i]) for i, meta in enumerate(metadata)]
    image_types = [name.split("_")[-1].split(".")[0] for name in standard_names]

    meta_df = pd.DataFrame(metadata, index=standard_names)

    meta_df['image_type'] = image_types
    meta_df['path'] = paths
#    meta_df['image_type'] = image_types
    return meta_df


def get_sequences_from_metadata(metadata: pd.DataFrame) -> Dict[Tuple[str, int, str], pd.DataFrame]:
    """ Extract all time-lapse sequences based on archive metadata.

    Parameters
    ----------
    metadata : DataFrame
        Output from `get_archive_metadata`

    Returns
    -------
    dict
        Keys are `well`, `image_index`, `vessel_id`-tuples. Values are data-frames where row-indexed
        by timestamp, column-indexed by image-code (Ph, C1, etc) and values are paths to images.

    Notes
    -----
    Path will be NaN where a certain image-code is missing for a time-stamp.
    """

    sequences = dict()
    for index, sequence_df in metadata.groupby(['well', 'image_index', 'vessel_id']):
        sequence = sequence_df.set_index(['timestamp', 'image_type']).path.unstack(level='image_type').sort_index()
        sequences[index] = sequence

    return sequences


def _format_name(meta, path, image_type):
    time = datetime.strftime(meta['timestamp'], '%Y-%m-%d_%Hh%Mm%Ss')
    return f'{meta["well"]}-{meta["image_index"]}_Vessel-{meta["vessel_id"]}_{time}_{image_type}{path.suffix}'


def _is_valid_format_name(path: Union[str, Path]):
    """
    Should check if a filename is named with the _format_name convention
    Parameters
    ----------
    path

    Returns
    -------

    """
    path = Path(path)
    if not path.is_file():
        return False
    parse_name = str(path.name).split("_")
    if len(parse_name) != 5:
        return False

    if len(parse_name[0].split("-")) != 2:
        return False

    return True


def _xml_to_dict(xml: ElementTree) -> Dict[str, Union[Dict, str]]:
    xml_dict = dict()
    for child in xml:
        if len(child) > 0:
            xml_dict[child.tag] = _xml_to_dict(child)
        else:
            xml_dict[child.tag] = child.text
    return xml_dict


def _parse_scan_date_time(datetime_string: str) -> datetime:
    # Example input format: 06/28/2022 04:39 PM
    date, hour_minute_string = datetime_string.split(maxsplit=1)
    month, day, year = map(int, date.split('/'))
    hour_minute, midday_modifier = hour_minute_string.split()
    hour, minute = map(int, hour_minute.split(':'))
    assert 1 <= hour <= 12, 'Expected hour in range 1..12'
    if hour == 12 and midday_modifier.lower() == 'am':
        hour = 0
    elif hour == 12 and midday_modifier.lower() == 'pm':
        hour = 12
    else:
        hour = hour + 12 if midday_modifier.lower() == 'pm' else hour
    timestamp = datetime(year, month, day, hour, minute)
    return timestamp

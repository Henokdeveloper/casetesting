import string
from collections import defaultdict, namedtuple
from pathlib import Path
from typing import Dict, List, IO
from xml.etree import ElementTree

import pandas as pd


PlateMapReferenceItem = namedtuple('PlateMapReferenceItem', ['type', 'name', 'description'])
CellTypeInformation = namedtuple('CellTypeInformation', ['name',
                                                         'seeding_density',
                                                         'seeding_density_unit',
                                                         'passage'])

class PlateMap:

    """ Encapsulate all information in a PlateMap. """

    def __init__(self,
                 cell_type_info: Dict[str, CellTypeInformation],
                 compound_info_df: pd.DataFrame,
                 growth_condition_info: pd.Series,
                 reference_items: List[PlateMapReferenceItem]):
        self._cell_type_info = cell_type_info
        self._compound_info_df = compound_info_df
        self._growth_condition_info = growth_condition_info
        self._reference_items = reference_items

    @classmethod
    def from_xml_file(cls, path: Path) -> 'PlateMap':
        with path.open() as f:
            plate_map = parse_platemap(f)
        return plate_map

    @property
    def cell_type_info(self) -> Dict[str, CellTypeInformation]:
        return self._cell_type_info

    @property
    def compound_info(self) -> pd.DataFrame:
        return self._compound_info_df

    @property
    def growth_condition_info(self) -> pd.Series:
        return self._growth_condition_info

    @property
    def reference_items(self) -> List[PlateMapReferenceItem]:
        return self._reference_items


def parse_platemap(platemap_io: IO) -> PlateMap:
    """ Parse well metadata from .plateMap-files.

    Parameters
    ----------
    platemap_io : File-like
        File handle to plateMap-file.

    Returns
    -------
    pd.DataFrame
        DataFrame row-indexed by well, and column-indexed by multi-index.
        The first level of the column-index is the reference-name of the entity
        describing the well (for instance compounds used to treat it), and second level
        is entity specific information (for instance concentration, units-name, etc.)
    List[PlateMapReferenceItem]
        List of PlateMapReferenceItem-namedtuples, containing descriptions of entities
        used to describes wells.
    """
    tree = ElementTree.parse(platemap_io)
    root = tree.getroot()

    reference_items = list()
    reference_item_manager = root.find('referenceItemManager')
    for reference_item in reference_item_manager.find('referenceItems').findall('referenceItem'):
        item = _parse_reference_item(reference_item)
        reference_items.append(item)

    well_store = root.find('wellStore')

    compound_info = defaultdict(dict)
    cell_type_info = defaultdict(list)
    growth_condition_info = dict()

    for well in well_store.find('wells').findall('well'):
        row = string.ascii_uppercase[int(well.get('row'))]
        col = int(well.get('col')) + 1
        well_index = f'{row}{col}'
        well_items = well.find('items')
        if well_items is not None:
            for well_item in well.find('items').findall('wellItem'):
                well_item_children = well_item.getchildren()
                assert len(well_item_children) == 1, 'More than one wellItem child.'

                reference_item = _parse_reference_item(well_item_children[0])
                assert reference_item in reference_items, 'Unknown referenceItem.'
                if reference_item.type == 'CellType':
                    cell_type = CellTypeInformation(
                        reference_item.name,
                        _safe_type_guess(well_item.get('seedingDensity')),
                        _safe_type_guess(well_item.get('seedingDensityUnits')),
                        _safe_type_guess(well_item.get('passage'))
                    )
                    cell_type_info[well_index].append(cell_type)
                elif reference_item.type == 'Compound':
                    compound_key = (reference_item.name, _safe_type_guess(well_item.get('concentrationUnits')))
                    compound_info[compound_key][well_index] = _safe_type_guess(well_item.get('concentration'))
                elif reference_item.type == 'GrowthCondition':
                    growth_condition_info[well_index] = reference_item.name
                else:
                    raise RuntimeError(f'Unknown referenceItem-type: {reference_item.type}')

    compound_info_df = pd.DataFrame(compound_info)
    growth_condition_info = pd.Series(growth_condition_info)

    return PlateMap(cell_type_info, compound_info_df, growth_condition_info, reference_items)


def _parse_reference_item(reference_item: ElementTree.Element) -> PlateMapReferenceItem:
    item = PlateMapReferenceItem(reference_item.get('type'),
                                 reference_item.get('displayName'),
                                 reference_item.get('description'))
    return item


def _safe_type_guess(value: str):
    try:
        parsed_value = int(value)
    except ValueError:
        try:
            parsed_value = float(value)
        except ValueError:
            # If value cannot be converted to int or float we assume that it should be a string.
            # Since these strings are user-typed, there may be un-printable characters coming along,
            # and we want to clean those. And since we are measuring for instance concentrations,
            # we may also have µ coming, as in microliters, which we actually want to keep.
            # We also assume that names stick to ASCII otherwise, since most users write in English.
            parsed_value = ''.join(char for char in value if char in (string.printable + 'µ'))
    return parsed_value
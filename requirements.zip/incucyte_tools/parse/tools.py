from typing import *

from pathlib import Path

import boto3
from s3path import S3Path
from PIL import Image

from AzurePathLib.azurepath import AzurePath 

def seed_from_image_path(image_path: Path) -> Image:
    filename = image_path.stem.replace('Ph', 'Seed')
    seed_path = image_path.parent / (filename + image_path.suffix)
    assert seed_path.exists(), 'Cannot find seed.'
    return Image.open(seed_path)


def open_s3_bucket_as_path(bucket_name: str,
                           session: Optional[boto3.Session] = None, **credentials) -> Tuple[S3Path, boto3.Session]:
    if session is None:
        session = boto3.Session(**credentials)
    s3_resource = session.resource('s3')
    path = S3Path(bucket_name)

    # There is a bug in S3Path making it not loading profiles properly
    # so we fix this by explicitly replacing boto3 S3-resource.
    path._accessor.s3 = s3_resource
    return path, session


def open_azure_container_as_path(archive_path: str, connection_string: str) -> AzurePath:
    """
    Method to initiate a AzurePath with a relative archive_path (pointing to the archive root) inside the container.
    :param archive_path: - str that points to the archive root relative to the container
    :param connection_string - str connection string to the azure blob
    :return: - an AzurePath
    """
   # from AzurePathLib.azurepath import AzurePath  # 14/11/2022 make incucytetools independent of AzurePath unless function is used
    return AzurePath.from_sas_connection_string(path=archive_path, connection_string=connection_string)



from typing import Optional, Sequence, Dict, Any, Generator, Tuple, Union
import enum
import numpy as np
import cv2
from PIL import Image


class Color(enum.Enum):

    GREEN = (36, 255, 60)
    RED = (240, 15, 22)
    SARTORIUS_YELLOW = (255, 237, 0)
    SARTORIUS_SECONDARY_TEAL = (38, 183, 188)


def merge_videos(
        video: Generator,
        video_2: Generator,
        merge_axis: int = 1
):
    for i, (frame1, frame2) in enumerate(zip(video, video_2)):
        output = merge_frames(frame1=frame1,
                              frame2=frame2,
                              merge_axis=merge_axis
                              )
        yield output


def merge_frames(
        frame1,
        frame2,
        merge_axis: int = 1):
    # merge axis - 1, horizontal, - 2 vertical

    # If one of the images is grey-scale and the other is RGB, convert one to RGB
    if len(frame1.shape) < len(frame2.shape):
        frame1 = np.stack([frame1] * 3, axis=2)
    elif len(frame1.shape) > len(frame2.shape):
        frame2 = np.stack([frame2] * 3, axis=2)

    output = np.concatenate((frame1, frame2), axis=merge_axis)

    return output


def overlay_flr_video(
        video1,
        video2,
        flr_threshold=0,
        alpha_merge=False,
        flr_color=Color.GREEN,
        alpha_max=0.8,
        flr_min=None,
        flr_max=None,
        ):
    for frame1, frame2 in zip(video1, video2):
        if alpha_merge:
            yield alpha_merge_flr_image(frame1, frame2, flr_color=flr_color,
                                        alpha_max=alpha_max, flr_min=flr_min, flr_max=flr_max)
        else:
            yield overlay_flr_image(frame1, frame2, threshold=flr_threshold)


def alpha_merge_videos(
        video1,
        video2,
):
    for frame1, frame2 in zip(video1, video2):
        yield alpha_merge_images(frame1, frame2)


def alpha_merge_flr_image(
    image,
    flr,
    flr_color=Color.GREEN,
    alpha_max=0.8,
    flr_min=None,
    flr_max=None,
):
    """ Overlay image with transparent FLR-image.

    Parameters
    ----------
    flr : array
        Fluorescent image channel.
    flr_color : Color, Tuple[int, int, int]
        Color to use for FLR-channel. Default is green.
    alpha_max : float
        Value between 0 and 1, indicates maximum opaqueness of flr.
    flr_min : float, int, optional
        If provided, FLR-values will be lower bounded at `flr_min`, meaning that
        FLR-values at `flr_min` or below will be completely transparent.
    flr_max : float, int, optional
        If provided, FLR-values will be upper bounded at `flr_max`, meaning that
        FLR-values at `flr_max` or above will `alpha_max` opaque.

    Returns
    -------
    merged_image : array
        (H x W x 3)
    """
    image = safe_as_4channel(image)

    flr_color_image = make_transparent_flr_image(flr, flr_color, alpha_max, flr_max, flr_min)
    merged_image = alpha_merge_images(image, flr_color_image)
    return merged_image


def safe_as_4channel(image):
    if len(image.shape) == 2:
        image = np.stack([image, image, image, np.ones_like(image, dtype=np.uint8) * 255], axis=2)
    elif image.shape[2] == 3:
        new_image = np.ones((image.shape[0], image.shape[1], 4))
        new_image[..., :3] = image
        image = new_image
    elif image.shape[2] != 4:
        raise ValueError(f'Expected grayscale, 3- or 4- channel image. Not {image.shape}')
    return image


def alpha_merge_images(first_image, second_image, convert_rgb=True):
    """ Make alpha-composite of input images.

    Parameters
    ----------
    first_image : array
        (H x W x 4) image, uint8
    second_image : array
        (H x W x 4) image, uint8
    convert_rgb : bool
        If True, convert image to RGB before return.

    Returns
    -------
    Merged image, uint8. (H x W x 3) if `convert_rgb` is True otherwise (H x W x 4).
    """
    assert first_image.ndim == 3 and first_image.shape[2] == 4
    assert second_image.ndim == 3 and second_image.shape[2] == 4
    assert first_image.shape == second_image.shape
    pil_first = Image.fromarray(first_image)
    pil_second = Image.fromarray(second_image)
    merged_image = Image.alpha_composite(pil_first, pil_second)
    if convert_rgb:
        merged_image = merged_image.convert('RGB')
    merged_image = np.array(merged_image)
    return merged_image


def make_transparent_flr_image(
    flr: np.ndarray,
    flr_color: Union[Color, Tuple[int, int, int]] = Color.GREEN,
    alpha_max: float = 0.8,
    flr_min: Optional[Union[int, float]] = None,
    flr_max: Optional[Union[int, float]] = None,
    dtype: Optional[np.dtype] = None
):
    """ Convert FLR-image to semi-transparent color image.

    Parameters
    ----------
    flr : array
        Fluorescent image channel.
    flr_color : Color, Tuple[int, int, int]
        Color to use for FLR-channel. Default is green.
    alpha_max : float
        Value between 0 and 1, indicates maximum opaqueness of flr.
    flr_min : float, int, optional
        If provided, FLR-values will be lower bounded at `flr_min`, meaning that
        FLR-values at `flr_min` or below will be completely transparent.
    flr_max : float, int, optional
        If provided, FLR-values will be upper bounded at `flr_max`, meaning that
        FLR-values at `flr_max` or above will `alpha_max` opaque.
    dtype : numpy.dtype, optional
        If provided, output will be converted to `dtype` otherwise the output
        will be same dtype as `flr`

    Returns
    -------
    flr_color_img : array
        (H x W x 4)-channel image. Values between 0 and 255
    """
    if len(flr.shape) < 3:
        flr = np.stack([flr] * 4, axis=2)
    assert 0 <= alpha_max <= 1, 'alpha_max must be between 0 and 1'
    if isinstance(flr_color, enum.Enum):
        flr_color = flr_color.value
    flr_color = list(flr_color) + [int(alpha_max * 255)]
    flr_color = np.array(flr_color)[np.newaxis, np.newaxis]
    flr_max = flr_max or flr.max()
    flr_min = flr_min or flr.min()
    flr_dtype = dtype or flr.dtype
    flr_clipped = np.clip(flr.astype(float), flr_min, flr_max)
    flr_scaled = (flr_clipped - flr_min) / (flr_max - flr_min)
    flr_colored = (flr_color * flr_scaled)
    if flr_dtype in (np.uint8, np.uint16):
        flr_colored = np.round(flr_colored)
    flr_color_image = flr_colored.astype(flr_dtype)
    return flr_color_image


def overlay_flr_image(
        image,
        flr,
        threshold=30,
        flr_color=[36, 255, 60],
        alpha=0.4):
    """ Function that overlays an flourence image over another an image (usually phase), the flourecent image will only
    be overlaid where it values are over a certain threshold.

    Parameters
    ----------
    image - image that will have the flr overlaied on top of it
    flr - the flourecent image
    threshold - the threshold where flouresent values should be overlaid
    flr_color - select flr color
    alpha - alpha value for merging of images at flr areas

    Returns - the original image with a flourecent image overlaid on it.
    -------

    """

    # image need to be rgb, transforms it to rgb if it is greyscale
    if len(image.shape) < 3:
        image = np.stack([image]*3, axis=2)
    if len(flr.shape) < 3:
        flr = np.stack([flr] * 3, axis=2)

    flr_color = (np.zeros_like(image) + flr_color).astype(np.uint8)
    merged_image = cv2.addWeighted(image, 1-alpha, flr_color, alpha, 0)

    results = np.where((flr > threshold), merged_image, image)

    return results

def overlay_text_on_video(
        video: Generator,
        text_sequence: Sequence[str]):
    """ Function that can take in a video sequence (generator) and add text for each frame.

    Parameters
    ----------
    video - a generator that generates frames (images)
    text_sequence - a sequence of strings to be attached to the frames

    Returns a frame generator (video) with attached text to each frame
    -------

    """
    for frame, text in zip(video, text_sequence):
        frame = overay_text_on_image(frame, text)
        yield frame


def overay_text_on_image(
        img,
        text: str,
        position=None,
        fontScale: int =1,
        fontColor: Tuple[int] = (255,255,255),
        lineType: int = 2):
    """ Function that attaches text to an image, will add it to top-centrum if nothing else is specified

    Parameters
    ----------
    img -
    text -
    position -
    fontScale -
    fontColor -
    lineType -

    Returns - original image with text put untop of it
    -------

    """
    font = cv2.FONT_HERSHEY_SIMPLEX
    text_position = (int(img.shape[1] / 2), int(30)) if position is None else position

    cv2.putText(img, text,
                text_position,
                font,
                fontScale,
                fontColor,
                lineType)

    return img

import os
from typing import *
from pathlib import Path
import datetime

import numpy as np

import incucyte_tools.parse.metadata

try:
    from torch.utils.data import Dataset
except ImportError:
    raise ImportError('PyTorch needed to use the torch-module. Please install PyTorch.')

import incucyte_tools


class IncuCyteDataset(Dataset):

    """ Dataset-class to parse IncuCyte-archives.

    PyTorch-compatible Dataset-class implementing data-fetching and cachine
    from remote archives and parsing of item metadata.

    Parameters
    ----------
    paths : Sequence
        Sequence of paths to images.
    transform : Callable, optional
        Transformation function taking an numpy array as input.
    cache_dir : str, Path, optional
        Optional path to directory where remote images will be cached. If not
        provided, no images will be cached.
    """

    def __init__(self,
                 paths: Sequence[Union[str, Path]],
                 transform: Optional[Callable] = None,
                 cache_dir: Optional[Union[str, Path]] = None):
        self.paths = paths
        self.cache_dir = cache_dir
        self.transform = transform

        self._path_map = dict()
        if cache_dir is not None:
            assert Path(cache_dir).exists(), f'Cannot find "{cache_dir}"'

    def __len__(self) -> int:
        return len(self.paths)

    def __getitem__(self, item: int) -> Tuple[np.ndarray, Any]:
        path = self.paths[item]
        metadata = incucyte_tools.parse.metadata.get_image_metadata(path)

        if path in self._path_map:
            local_path = self._path_map[path]
            img = incucyte_tools.io.read_image(local_path)
        else:
            is_using_cache = self.cache_dir is not None
            with incucyte_tools.io.force_local_path(path,
                                                    persist=is_using_cache,
                                                    cache_dir=self.cache_dir) as local_path:
                img = incucyte_tools.io.read_image(local_path)
                if is_using_cache:
                    self._path_map[path] = local_path

        target = self.get_target(path, *metadata)

        if self.transform is not None:
            img = self.transform(img)

        return img, target

    @classmethod
    def from_archives(cls, *archives: Union[str, Path], image_type: str = 'Ph', **kwargs: Any):
        """ Instantiate a dataset directly from archives.

        Parameters
        ----------
        *archives : str, Path
            Paths to one or more IncuCyte archives.
        image_type : str
            Which image-modality to use, default "Ph" (phase images).
        **kwargs
            Key-word arguments passed to `__init__`.
        """
        paths = list()
        for archive_path in archives:
            archive_metadata = incucyte_tools.parse.metadata.get_archive_metadata(archive_path)
            archive_paths = archive_metadata.loc[archive_metadata.image_type == image_type].path.tolist()
            paths.extend(archive_paths)

        return cls(paths, **kwargs)

    def get_target(self,
                   path: Union[str, Path],
                   timestamp: datetime.datetime,
                   well: str,
                   image_index: int,
                   vessel_id: str) -> Any:
        """ Override to fetch target.

        Parameters
        ----------
        path : str, Path
            Path to image to fetch target for.
        timestamp : datetime.datetime
            Image time-stamp.
        well : str
            Well-identifier.
        image_index : int
            Index of image position.
        vessel_id : str
            Vessel/experiment-identifier.

        Returns
        -------
        target : Any
        """
        return None

    def clean_cache(self):
        for path in self._path_map.values():
            os.unlink(str(path))
        self._path_map = dict()


class IncuCyteInsilicoLabellingDataset(IncuCyteDataset):

    """ Loads phase-image with accompanying FLR-image(s). """

    def __init__(self, paths,
                 flr_channel: Union[str, Sequence],
                 convert_flr: bool = True,
                 target_transform: Optional[Callable] = None,
                 target_cache_dir: Optional[Union[str, Path]] = None,
                 **kwargs):
        super(IncuCyteInsilicoLabellingDataset, self).__init__(paths, **kwargs)
        if not isinstance(flr_channel, (list, tuple)):
            assert isinstance(flr_channel, str), 'Param flr_channel must be str, list or tuple.'
            flr_channel = [flr_channel]

        assert all(channel.startswith('C') for channel in flr_channel), 'FLR images uses "C"-prefix.'
        self.flr_channel = flr_channel
        self.convert_flr = convert_flr
        self.target_transform = target_transform
        self.target_cache_dir = self.cache_dir if target_cache_dir is None else target_cache_dir
        self._target_path_map = dict()

    def get_target(self,
                   path: Union[str, Path],
                   timestamp: datetime.datetime,
                   well: str,
                   image_index: int,
                   vessel_id: str) -> np.ndarray:
        if isinstance(path, str):
            path = Path(path)

        channel_images = list()
        for channel in self.flr_channel:
            flr_path = path.parent / (path.stem.replace('Ph', channel) + path.suffix)
            assert flr_path.exists(), f'Cannot find {flr_path}'

            if path in self._target_path_map:
                local_path = self._target_path_map[path]
                img = incucyte_tools.io.read_image(local_path)
            else:
                is_using_cache = self.target_cache_dir is not None
                with incucyte_tools.io.force_local_path(flr_path,
                                                        persist=is_using_cache,
                                                        cache_dir=self.target_cache_dir) as local_path:
                    img = incucyte_tools.io.read_image(local_path)
                    if is_using_cache:
                        self._target_path_map[path] = local_path

            if self.target_transform is not None:
                img = self.target_transform(img)

            channel_images.append(img)

        return np.stack(channel_images).squeeze()

    def clean_cache(self):
        super(IncuCyteInsilicoLabellingDataset, self).clean_cache()
        for path in self._target_path_map.values():
            os.unlink(str(path))
        self._target_path_map = dict()
from typing import *
from datetime import datetime
from pathlib import Path
import pandas as pd

import warnings
import copy
from incucyte_tools.io import IncuCyteFrameGenerator, write_video_from_generator
from incucyte_tools.image_tools import *
from incucyte_tools.parse.platemap import PlateMap

from incucyte_tools.parse.metadata import ArchiveFilter, get_archive_metadata, _format_name
from AzurePathLib.azurepath import initiate_accessor
import time

class IncucyteDatasetDefinition:

    def __init__(self, metadata: pd.DataFrame, archive_path=None):
        self._metadata = metadata
        self._split_filters = {}
        self._inter_train = False
        self.archive_path = archive_path

    @property
    def metadata(self) -> pd.DataFrame:
        return self._metadata.copy()

    @property
    def paths(self):
        return self.metadata.path

    @property
    def wells(self):
        return self.metadata.well.unique()

    @property
    def image_indexes(self):
        return self.metadata.image_index.unique()

    @property
    def timestamps(self):
        return self.metadata.timestamp.unique()

    @property
    def vessel_ids(self):
        return self.metadata.vessel_id.unique()

    @property
    def image_types(self):
        return self.metadata.image_type.unique()


    @property
    def platemaps(self) -> Dict[str, PlateMap]:

        assert self.archive_path is not None, "No given archive path, initilize the class with from_archive method to use this method"

        return _retrive_platemaps(self.archive_path)

    @property
    def splits(self) -> Dict[Union[str, Any], 'IncucyteDatasetDefinition']:
        """ Function that applies current split definitions and returns a dictionary with the name of the split and
        the corresponding IncucyteDatasetDefinition

        Returns a dict {str, IncucyteDatasetDefinition}
        -------

        """

        dataset_splits = {}

        if not self._validate_split():
            return dataset_splits

        splits = self._split_filters

        default_data = None
        if self._inter_train:
            default_data = self.metadata

        for split_name in splits:
            dataset_split = _filter_dataset(self.metadata, splits[split_name])
            dataset_splits[split_name] = IncucyteDatasetDefinition(dataset_split)

            if self._inter_train:
                default_data = pd.concat([default_data, dataset_split]).drop_duplicates(keep=False)

        if self._inter_train:
            dataset_splits['train'] = IncucyteDatasetDefinition(default_data)

        return dataset_splits

    def save(self, path: Optional[Union[str, Path]]):
        path_dir = Path(path).parent

        _force_directory(path_dir)
        save_data = self._metadata
        with pd.HDFStore(path, mode='w') as f:
            f.put('/incucyte_dataset', save_data)
        if self._split_filters:
            with pd.HDFStore(path, mode='a') as f:
                f.get_storer('/incucyte_dataset').attrs.metadata = self._split_filters
                f.get_storer('/incucyte_dataset').attrs.infer_train = self._inter_train


    @classmethod
    def load(cls, path: Optional[Union[str, Path]], azure_access_string=None):

        if azure_access_string is not None:
            initiate_accessor(azure_access_string)

        split_filters = {}
        infer_train = False
        with pd.HDFStore(path, mode='r') as f:
            if 'metadata' in f.get_storer('/incucyte_dataset').attrs:
                split_filters = f.get_storer('/incucyte_dataset').attrs.metadata
            if 'infer_train' in f.get_storer('/incucyte_dataset').attrs:
                infer_train = f.get_storer('/incucyte_dataset').attrs.infer_train

        metadata = pd.read_hdf(path)
        output = cls.from_metadata(metadata)
        output._split_filters = split_filters
        output._inter_train = infer_train

        return output



    def save_as_csv(self, path: Optional[Union[str, Path]] = None):
        raise NotImplementedError
        path = _force_directory(path)
        save_data = self._metadata
        if self._split_filters:
            save_data.attrs['_split_filters'] = self._split_filters

        save_data.to_csv(Path(path).joinpath("incucyte_dataset.csv"))

    @classmethod
    def load_csv(cls, path: Optional[Union[str, Path]]) -> 'IncucyteDatasetDefinition':
        raise NotImplementedError

        metadata = pd.read_csv(Path(path).joinpath("incucyte_dataset.csv"))
        filters = None
        if metadata.attrs.__contains__("_split_filters"):

            filters = ArchiveFilter.from_text_representation()

        return cls.from_metadata(metadata, filters)


    @classmethod
    def from_archive(cls, archives: Path,
                      filter: Optional[ArchiveFilter] = None) -> 'IncucyteDatasetDefinition':
        metadata = get_archive_metadata(archives)
        if filter is not None:
            metadata = _filter_dataset(metadata, filter)

        return cls(metadata, archive_path=archives)

    @classmethod
    def from_metadata(cls, metadata: pd.DataFrame, filter: ArchiveFilter=None): #Todo make this work with a filter class
        if filter is not None:
            metadata = _filter_dataset(metadata.copy(), filter)
        return cls(metadata)

    def download_data(self, dirpath: Union[str, Path], parse_on_split=False):
        """ Downloads all data to a selected path locally and returns a new dataset which points to those local paths

        Parameters
        ----------
        dirpath - download path, a path to a local directory

        Returns - a IncucyteDatasetDefinition with references to the local paths
        -------

        """
        dirpath = _force_path(dirpath)
        _create_dir_if_non_existing(dirpath)

        _local_metadata = self._metadata.copy()

        if parse_on_split:
            dataset_splits = self.splits
            for k in dataset_splits:
                split_dir = Path(dirpath, k)
                split_dir = _force_path(split_dir)
                _create_dir_if_non_existing(split_dir)
                split_metadata = dataset_splits[k].metadata

                for meta in dataset_splits[k]._metadata.iloc():
                    name = _format_name(meta, meta.path, meta.image_type)
                    path = meta.path

                    local_path = split_dir.joinpath(name)
                    with path.open(mode='rb') as src, local_path.open(mode='wb') as dst:
                        dst.write(src.read())

                    split_metadata.loc[split_metadata['path'] == path] = local_path
                dataset_splits[k]._metadata = split_metadata
            local_dataset = dataset_splits
        else:
            for meta in self._metadata.iloc():
                path = meta.path
                name = _format_name(meta, path, meta.image_type)
                local_path = dirpath.joinpath(name)
                with path.open(mode='rb') as src, local_path.open(mode='wb') as dst:
                    dst.write(src.read())

                _local_metadata.loc[_local_metadata['path'] == path, 'path'] = local_path
            local_dataset = IncucyteDatasetDefinition(_local_metadata)
            local_dataset._split_filters = copy.deepcopy(self._split_filters)
        return local_dataset


    def create_dataset_splits(
            self,
            splits: Dict = None,
            infer_train_data=False
    ):
        """ Function that defines dataset splits for the dataset class

        Parameters
        ----------
        splits - a dictionary containing the name of the split as key and the filters to define the dataset as elements
        infer_train_data - boolean set to true if if the user want to keep whatever is left after others splits as
                            a "train" split.

        -------

        """
        self._split_filters = splits
        self._inter_train = infer_train_data

    def _validate_split(self):
        valid = False
        if not self._split_filters:
            warnings.warn("No dataset split definition can be found, define those with create_dataset_splits function")
        else:
            valid = True
        return valid

    def filter(self,
                 well: Optional[Sequence[str]] = None,
                 min_timestamp: Optional[datetime] = None,
                 max_timestamp: Optional[datetime] = None,
                 timestamp: Optional[Sequence[datetime]] = None,
                 image_index: Optional[Sequence[int]] = None,
                 vessel_id: Optional[Sequence[str]] = None,
                 image_type: Optional[Sequence[str]]=None):
        if timestamp is not None:
            if min_timestamp is not None or max_timestamp is not None:
                raise ValueError('param timestamps cannot be used at the same time as min_timestamp or max_timestamp')

        if (min_timestamp and max_timestamp) and (min_timestamp > max_timestamp):
            raise ValueError('min_timestamp should not be larger than max_timestamp')


        filters = ArchiveFilter(well=well, min_timestamp=min_timestamp, max_timestamp=max_timestamp, timestamp=timestamp,
                                image_index=image_index, vessel_id=vessel_id, image_type=image_type)

        return IncucyteDatasetDefinition(_filter_dataset(self.metadata, filters))

    def generate_videos(
            self,
            save_dir:Union[str, Path],
            overlay: bool = False,
            flr_threshold: float=0.,
            save_prefix:Union[str, Path]="incucyte_video",
            verbatim: bool=False,
            **kwargs):

        #Will per default create a video for each image_index in each well( assumes that the user
        # have distilled the dataset already with filter. Can be changed by adding wells or image index in kwargs.
        wells = self.wells if not "well" in kwargs else kwargs['well']
        image_idx = self.image_indexes if not "image_index" in kwargs else kwargs['image_index']
        image_type = self.image_types if not "image_type" in kwargs else kwargs['image_type']

        #Generates separate sequences for each index_index per well
        video_idx = [(well, img_idx) for well in wells for img_idx in image_idx]
        video_datasets = [self.filter(well=idx[0], image_index=idx[1], image_type=image_type) for idx in video_idx]

        i = 0
        for data in video_datasets:
            p = Path(save_dir).joinpath(f"{save_prefix}_{video_idx[i][0]}_{video_idx[i][1]}.mp4")
            if verbatim:
                print(f"Constructing: {p}")
            start = time.time()

            phase_vid = IncuCyteFrameGenerator(_extract_paths(data, 'Ph'))
            c1_vid = IncuCyteFrameGenerator(_extract_paths(data, 'C1'), preprocessing_fn=flr_preprocess)

            phase_vid = overlay_flr_video(phase_vid, c1_vid, 26)
            merged = merge_videos(phase_vid, c1_vid)
            video = overlay_text_on_video(merged, _extract_timestamps(data))

            write_video_from_generator(video, p, grayscale=False)
            if verbatim:
                print(f"{p} done in {time.time() - start} sec")
            i += 1

def _force_path(path: Union[str, Path]) -> Path:
    if isinstance(path, str):
        return Path(path)
    elif isinstance(path, Path):
        return path
    else:
        raise ValueError(f'Assumed str or Path, got {type(path)}')


def _force_directory(path: Union[str, Path]):
    path = _force_path(path)

    if not path.exists():
        _create_dir_if_non_existing(path)
    if not path.is_dir():
        raise ValueError('param path must be directory')
    else:
        return path


def _create_dir_if_non_existing(path: Path):
    if not path.exists():
        path.mkdir(parents=True)

def _filter_dataset(metadata: pd.DataFrame, filter: ArchiveFilter):
    """ Helper function that can filter metadata based on a ArchiveFilter

    Parameters
    ----------
    metadata - a pandas dataframe
    filter - an ArchiveFilter defining how to match patch from metadata

    Returns a pandas df metadata object with applied filters on
    -------
    """

    filters = filter.to_dict()
    dataset = metadata

    if "min_timestamp" in filters or "max_timestamp" in filters:
        timestamps = metadata.timestamp
        if "min_timestamp" in filters:
            timestamps = [timestamp for timestamp in timestamps if timestamp >= filters["min_timestamp"]]
            del filters["min_timestamp"]
        if "max_timestamp" in filters:
            timestamps = [timestamp for timestamp in timestamps if timestamp <= filters["max_timestamp"]]
            del filters["max_timestamp"]
        filters['timestamp'] = timestamps


    for key in filters:
        filter = filters[key]
        if (not isinstance(filter, Sequence) or isinstance(filter, str)) and not isinstance(filter, np.ndarray):
            filter = [filter]

        dataset = dataset.loc[dataset[key].isin(filter)]

    return dataset


def _extract_paths(dataset, image_type='Ph'):
    df = dataset.metadata
    paths = df.loc[df['image_type'] == image_type]

    return paths.path.unique()


def _extract_timestamps(dataset, relative_time=True, parse=True):
    if relative_time:
        t1 = dataset.timestamps[0]
        times = [str((t - t1) / np.timedelta64(1, 'h')) + ' h' for t in dataset.timestamps]
    else:
        times = [str(t) for t in dataset.timestamps]

    return times

def _retrive_platemaps(archive_path: Path):

    platemap_path = archive_path.joinpath("EssenFiles", "PlateMaps")
    platemap_paths = platemap_path.glob("*PlateMap")
    return {platemap.name: PlateMap.from_xml_file(platemap) for platemap in platemap_paths}

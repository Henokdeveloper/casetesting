import numpy as np

from PIL import Image
from matplotlib import cm, colors
from matplotlib.colors import ListedColormap

from incucyte_tools.parse import seed_from_image_path


def make_transparent_cmap(base_cmap=cm.RdBu, power=2, end_alpha=.5, tail_fraction=1/3):

    # Get the colormap colors
    base_colors = base_cmap(np.arange(base_cmap.N))

    tail_length = int(base_cmap.N * tail_fraction)

    alpha_line = np.concatenate([np.linspace(end_alpha ** (1 / power), 0, tail_length),
                                 np.zeros((base_cmap.N - 2 * tail_length, )),
                                 np.linspace(0, end_alpha ** (1 / power), tail_length)]) ** power

    # Set alpha
    base_colors[:,-1] = alpha_line

    # Create new colormap
    new_cmap = ListedColormap(base_colors)
    return new_cmap


def convert_merged_image_to_rgb(img, seed_img):
    s_arr = np.array(seed_img)
    i_arr = np.array(img)[..., :3]
    mask = s_arr[..., 3][..., None].astype(float) / (255 * 1.5)
    s_arr_weighted = s_arr[..., :3] * mask
    merged = Image.fromarray(np.round(i_arr * (1 - mask) + s_arr_weighted).astype(np.uint8))
    return merged


def load_image_with_merged_seed(image_path,
                                convert_to_rgb=True,
                                end_alpha=.2,
                                power=1,
                                tail_fraction=.3,
                                vmin=6.8,
                                vmax=7):
    raw_seed = seed_from_image_path(image_path)
    img = Image.open(image_path)
    img = img.convert('RGBA')
    seed_arr = np.log(np.array(raw_seed))
    raw_seed.close()

    cmap = make_transparent_cmap(end_alpha=end_alpha, power=power, tail_fraction=tail_fraction)
    norm = colors.Normalize(vmin=vmin, vmax=vmax)
    color_arr = cmap(norm(seed_arr))
    seed_img = Image.fromarray(np.round(color_arr * 255).astype(np.uint8), mode='RGBA')

    img.paste(seed_img, (0, 0), seed_img)
    if convert_to_rgb:
        return convert_merged_image_to_rgb(img, seed_img)
    else:
        return img
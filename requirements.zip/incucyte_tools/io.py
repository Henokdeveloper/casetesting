import contextlib
from io import StringIO, BytesIO
from typing import *

import logging
import os
import tempfile
from pathlib import Path
from typing import Sequence, Union

import cv2
import numpy as np
import tifffile

# Try importing dependencies for remote paths.
try:
    from s3path import S3Path
except ImportError:
    S3Path = None
try:
    from AzurePathLib.azurepath import AzurePath
except ImportError:
    AzurePath = None
try:
    from urlpath import URL
except ImportError:
    URL = None

from video_stabilizer import FrameGenerator


class IncuCyteFrameGenerator(FrameGenerator):

    """ Yields image frames given sequence of paths to images.

    Parameters
    ----------
    paths : Sequence
        Ordered sequence of paths.
    flag : int
        Flag passed to `cv2.imread`, default `cv2.IMREAD_UNCHANGED`.
    attempt_conversion : bool
        If True, try to rescale images based on stored conversion factor.
    preprocessing_fn : callable, optional
        Function to preprocess frames before yielding.

    Yields
    ------
    frame : array
        Loaded image frame.
    """

    def __init__(self,
                 paths: Sequence[Union[str, Path]],
                 flag: int = cv2.IMREAD_UNCHANGED,
                 attempt_conversion: bool = False,
                 preprocessing_fn: Optional[Callable] = None):
        super(IncuCyteFrameGenerator, self).__init__(paths, flag, preprocessing_fn)
        self.attempt_conversion = attempt_conversion

    def __iter__(self) -> np.ndarray:
        for path in self.paths:
            img = read_image(path, self.flag, self.attempt_conversion)
            if self.preprocessing_fn is not None:
                img = self.preprocessing_fn(img)
            yield img


def read_image(path: Union[str, Path],
               flag: int = cv2.IMREAD_UNCHANGED,
               attempt_conversion: bool = False) -> np.array:
    """ Read image from file that is local or in AWS S3-bucket.

    Parameters
    ----------
    path : str, Path
        Path to image file.
    flag : int
        Flag passed to `cv2.imread`
    attempt_conversion : bool
        If True, try to rescale image based on stored conversion factor.

    Returns
    -------
    array
    """
    with force_local_path(path) as path:
        img_array = cv2.imread(str(path), flag)
        if attempt_conversion:
            try:
                conversion_factor = read_conversion_factor(path)
            except Exception:  # Yes, I did.
                pass
            else:
                img_array = img_array / conversion_factor

    return img_array


def write_video_from_generator(frame_generator: IncuCyteFrameGenerator,
                               output_path: Union[Path, str],
                               fourcc: str = 'XVID',
                               fps: float = 5.0,
                               grayscale: bool = True,
                               frame_preprocessing_fn: Optional[Callable] = None):
    """ Given IncuCyteFrameGenerator, write video.

    Parameters
    ----------
    frame_generator : IncuCyteFrameGenerator
        Frames to write to video.
    output_path : Path, str
        Where to write video.
    fourcc : str
        Four character code of video codec.
    fps : float
        Frames per second.
    grayscale : bool
        If True, write grayscale video.
    frame_preprocessing_fn: callable, optional
        Function to preprocess each frame before writing to video. Expected to
        return an array-like.
    """
    frame_iterator = iter(frame_generator)
    first_frame = next(frame_iterator)
    _write_video(first_frame, frame_iterator, output_path, fourcc, fps, grayscale, frame_preprocessing_fn)


def write_video_from_paths(paths: Sequence[Union[Path, str]],
                           output_path: Union[Path, str],
                           fourcc: str = 'XVID',
                           fps: float = 5.0,
                           grayscale: bool = True,
                           frame_preprocessing_fn: Optional[Callable] = None):
    """ Given sequence of image paths, write video.

    Parameters
    ----------
    paths : sequence
        Paths to images for frames.
    output_path : Path, str
        Where to write video.
    fourcc : str
        Four character code of video codec.
    fps : float
        Frames per second.
    grayscale : bool
        If True, write grayscale video.
    frame_preprocessing_fn: callable, optional
        Function to preprocess each frame before writing to video. Expected to
        return an array-like.
    """
    first_frame = read_image(paths[0])
    remaining_frames = IncuCyteFrameGenerator(paths[1:])

    _write_video(first_frame, remaining_frames, output_path, fourcc, fps, grayscale, frame_preprocessing_fn)


@contextlib.contextmanager
def force_local_path(path: Union[str, Path],
                     persist: bool = False,
                     cache_dir: Optional[Union[str, Path]] = None) -> Union[str, Path]:
    """ Context-manager that downloads to temporary directory if `path` is remote.

    Parameters
    ----------
    path : str, Path
        Path to file to ensure is local.
    persist : bool
        If True, keep local file. Default False.
    cache_dir: str, Path, optional
        If provided, use as local cache-directory. Otherwise use temp-dir.

    Yields
    ------
    path : str, Path
        Path to local file.
    """

    if _is_remote(path):
        if cache_dir is None:
            cache_dir = tempfile.gettempdir()
        tmp = os.path.join(str(cache_dir), os.urandom(32).hex() + path.suffix)
        #with path.open(mode='rb') as src, open(tmp, mode='wb') as dst:
        with _open_path(path) as src, open(tmp, mode='wb') as dst:
            dst.write(src.read())
        try:
            yield Path(tmp)
        finally:
            if not persist:
                os.unlink(tmp)
    else:
        yield path


def _write_video(first_frame: np.ndarray,
                 remaining_frames: Iterable[np.ndarray],
                 output_path: Union[Path, str],
                 fourcc: str = 'XVID',
                 fps: float = 5.0,
                 grayscale: bool = True,
                 frame_preprocessing_fn: Optional[Callable] = None):

    assert len(fourcc) == 4, 'FOURCC must be four characters'
    if frame_preprocessing_fn is None:
        def frame_preprocessing_fn(x):  # No-op.
            return x

    frame_height, frame_width = frame_preprocessing_fn(first_frame).shape[:2]
    logging.debug(f'Instantiates video at {output_path}')
    video_writer = cv2.VideoWriter(
        str(output_path),
        cv2.VideoWriter_fourcc(*fourcc),
        float(fps),
        (frame_width, frame_height),
        0 if grayscale else 1  # isColor
    )
    video_writer.write(first_frame)
    for i, frame in enumerate(remaining_frames):
        logging.debug(f'Writes frame {i}')
        img = frame_preprocessing_fn(frame)
        video_writer.write(img)
    video_writer.release()


def read_conversion_factor(path: Union[str, Path]) -> float:
    """ Read FLR conversion factor from file.

    Parameters
    ----------
    path : str, path
        Path to FLR tiff-file.

    Returns
    -------
    float
    """
    with force_local_path(path) as path:
        with tifffile.TiffFile(str(path)) as tif:
            tif_tags = {}
            num_pages = len(tif.pages)
            for tag in tif.pages[num_pages - 1].tags.values():
                name, value = tag.name, tag.value
                tif_tags[name] = value

    meta_data = tif_tags['60020']
    meta_data = meta_data.replace('/', '')
    conversion_scale = float(meta_data.split("<ConversionScale>")[1])
    return conversion_scale


def _is_remote(path):

    is_remote = False
    if AzurePath is not None:    
        is_remote = isinstance(path, AzurePath)
    if not is_remote and S3Path is not None:
        is_remote = isinstance(path, S3Path)
    if not is_remote and URL is not None:
        is_remote = isinstance(path, URL)
    return is_remote


@contextlib.contextmanager
def _open_path(path):
    if URL is not None and isinstance(path, URL):
        response = path.get()
        yield BytesIO(response.content)
    else:
        with path.open(mode='rb') as f:
            yield f

import numpy as np
import cv2


class FLRTransform:

    """ Callable transform to do background removal and optional log-transform. """

    def __init__(self, scale=None, use_log=False):
        self.scale = scale
        self.use_log = use_log

    def __call__(self, image):
        if self.scale is not None:
            image = image / self.scale

        std = 0.1  # What's the rationale behind this?
        image = tophat_background_removal(image)
        if self.use_log:
            image = log_transform(image, std)

        return image


def tophat_background_removal(image, kernel_size=3, morph_size=(30, 30)):
    """ Background removal using tophat-transform.

    Parameters
    ----------
    image : np.array
        Image to remove background from.
    kernel_size : int
        Width of kernel for background removal.
    morph_size : Tuple[int, int]
        Size of morphological operation.

    Returns
    -------
    np.array
    """
    image = image.astype(np.float32)

    blurred_img = cv2.medianBlur(image, kernel_size)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, morph_size)
    tophat = cv2.morphologyEx(blurred_img, cv2.MORPH_TOPHAT, kernel)
    background = image - tophat
    return image - background


def log_transform(image, noise_threshold=0):
    """ Log-transformation with scaling-constant.

    Parameters
    ----------
    image : np.array
    noise_threshold : int, float

    Returns
    -------
    np.array
    """
    image = np.maximum(image - noise_threshold + 1, 1)
    image = np.log(image)
    return image


def clipped_normalization(image, loc, scale, clip_at=6, max_after_scaling=255, dampen_edge_values=0):
    """ Clipped standard-scaling for efficient contrast enhancement of phase contrast images.

    Parameters
    ----------
    image : array
        Greyscale image to scale.
    loc : float
       Location for centering.
    scale : float
        Scaling constant.
    clip_at : float
        Multiplier of `scale` to use for clipping.
    max_after_scaling : int
        Max-value of images, typically 255.
    dampen_edge_values : int
        Clip intensity values at `[dampen_edge_values, max_after_scaling - dampen_edge_values]`.

    Returns
    -------
    array
    """
    dtype = image.dtype
    normalized = (image.astype(float) - loc) / scale
    clipped = np.clip(normalized, -clip_at, clip_at)
    back_scaled = (clipped + clip_at) * (max_after_scaling / (2 * clip_at))
    return np.clip(np.round(back_scaled).astype(dtype), dampen_edge_values, max_after_scaling - dampen_edge_values)



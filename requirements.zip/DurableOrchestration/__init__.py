import azure.functions as func
import azure.durable_functions as df
import os 
import logging

# Note that function.json needs to be defined correctly otherwise 
# orchestration will fail.



def orchestrator_function(context: df.DurableOrchestrationContext):

    trigger_payload = context.get_input()
    
    path_to_blob = trigger_payload["path_to_blob"]
    archive_type = trigger_payload["archive_type"]
    blob_name = trigger_payload["blob_name"]


    if archive_type == "standard":

        if "ScanData" in path_to_blob:
            # only convert data that is in ScanData folder

            # 1. convert the image directly from landing to conformance
            converted_fullsize_png = yield context.call_activity("ConvertImage",trigger_payload)

            logging.info("standard structure, ScanData converted_fullsize_png = %s",str(converted_fullsize_png))
            

    elif archive_type == "flexible":
            # any tif image uploaded will the converted to png
            converted_fullsize_png = yield context.call_activity("ConvertImage",trigger_payload)

    else:
        logging.info("experiment was added in unexpected folder = %s",str(converted_fullsize_png))



    image_type = converted_fullsize_png["image_type"]
    if image_type != "Seed":
        # 2. create thumbnails
        thumbnails = yield context.call_activity("CreateThumbnail",converted_fullsize_png)
        add_img_metadata = yield context.call_activity("CreateRawAndFilteredMetadata", thumbnails)
    
    # placeholder = 0
    # return placeholder

    return [thumbnails, add_img_metadata]
    

main = df.Orchestrator.create(orchestrator_function)
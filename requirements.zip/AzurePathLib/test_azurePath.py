from unittest import TestCase

import pytest
from azurepath import AzurePath, initiate_accessor
import pytest
import os


test_connection = os.environ.get("test_connection")

class TestAzurePath(TestCase):

    def test_initiating_accessor(self):
        print(test_connection)


        initiate_accessor(test_connection)
        ap = AzurePath("/")

        i = 0
        for p in ap.iterdir():
            print(p)
            i += 1

        assert i > 0

    def test_from_sas_connection_string(self):
        print(test_connection)
        ap = AzurePath.from_sas_connection_string("/", connection_string=test_connection)

        print("Going to iterate..")

        i = 0
        for p in ap.iterdir():
            print(p)
            i += 1

        assert i > 0
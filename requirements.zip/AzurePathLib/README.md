# AzurePath
## - Pathlib interface for azure blob storage

This readme will be updated with furter instructions, this project will only support a few functions like navigating the
azure file system like it would be a normal file-structure and reading files(blobs).

### Usage
````
from AzurePath import AzurePath
con_string = "connation_string_with_sas_token"
ap = AzurePath.from_sas_connection_string("/", connection_string=con_string)

for p in ap.iterdir():
    print(p)

````
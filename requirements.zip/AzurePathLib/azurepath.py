from pathlib import _PosixFlavour, _Accessor, Path, PurePath
from os import stat_result
from collections import namedtuple
from typing import Union, Generator, TypeVar
from azure.storage.blob import ExponentialRetry, ContainerClient
from io import UnsupportedOperation, RawIOBase, BytesIO, StringIO
import os
_P = TypeVar("_P", bound=PurePath)

_SUPPORTED_OPEN_MODES = {'r', "rb"} # , 'br', 'rb', 'tr', 'rt', 'w', 'wb', 'bw', 'wt', 'tw'}
DEFAULT_BUFFER_SIZE = -1



class _AzureFlavour(_PosixFlavour):
    is_supported = bool(ContainerClient)

    def parse_parts(self, parts):
        drv, root, parsed = super().parse_parts(parts)
        for part in parsed[1:]:
            if part == '..':
                index = parsed.index(part)
                parsed.pop(index - 1)
                parsed.remove(part)
        return drv, root, parsed

    def make_uri(self, path):
        uri = super().make_uri(path)
        return uri.replace('file:///', "https://")


class _AzureScandir:
    def __init__(self, *, azure_accessor, path):
        self._azure_accessor = azure_accessor
        self._path = path

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        return

    def __iter__(self):

        path = str(self._path)
        sep = self._path._flavour.sep

        if not path.endswith(sep):
            path += "/"

        blobs = self._azure_accessor.az.walk_blobs(path)

        for blob in blobs:
            is_dir = blob.name.endswith("/")
            full_name = blob.name.replace("/", sep)

            if full_name.endswith("/"):
                name = full_name.split(sep)[-2]
            else:
                name = full_name.split(sep)[-1]

            if blob.name.endswith("/"):
                yield AzureDirEntry(name, is_dir=is_dir, size=0, last_modified="Nan") #maybe change size?
            else:
                yield AzureDirEntry(name, is_dir=is_dir, size=blob.size, last_modified=blob.last_modified)


class _AzureConfigurationMap(dict):
    def __missing__(self, path):
        for parent in path.parents:
            if parent in self:
                return self[parent]
        return self.setdefault(Path('/'), {})

class _AzureAccessor(_Accessor):
    """
    An accessor implements a particular (system-specific or not)
    way of accessing paths on the filesystem.
    In this case this will access Azure blob storage service
    """

    def __init__(self, **kwargs):
        if ContainerClient is not None:
            retry_policy = ExponentialRetry(
                retry_total=7
            )
            kwargs["retry_policy"] = retry_policy

            self.az = ContainerClient.from_container_url(**kwargs)
        self.configuration_map = _AzureConfigurationMap()

    def stat(self, path): # TODO
        object_summery = self.s3.ObjectSummary(self.bucket_name(path.bucket), str(path.key))
        return StatResult(
            size=object_summery.size,
            last_modified=object_summery.last_modified,
        )

    def is_dir(self, path):
        if str(path) == path.root:
            return True
        sep = path._flavour.sep
        path = str(path)
        path = path.replace(sep, "/")

        blobs = list(self.az.walk_blobs(path))
        if len(blobs) > 1:
            return True
        else:
            name = blobs[0].name
            if name.endswith("/") or len(name) > len(path):
                return True

        return False

    def exists(self, path):
        sep = path._flavour.sep
        path = str(path)
        path = path.replace(sep, "/")
        blobs = self.az.list_blobs(name_starts_with=str(path))
        blob = next(blobs, None)

        return blob is not None

    def scandir(self, path):
        return _AzureScandir(azure_accessor=self, path=path)

    def listdir(self, path):
        with self.scandir(path) as scandir_iter:
            return [entry.name for entry in scandir_iter]

    def open(self, path, *, mode='rb', buffering=-1, encoding=None, errors=None, newline=None): # not sure if this will work..
        if not _SUPPORTED_OPEN_MODES.__contains__(mode) :
            raise NotImplemented

        sep = path._flavour.sep
        path = str(path).replace(sep, "/")

        blob = self.az.download_blob(path)
        if mode == "r":
            return StringIO(blob.content_as_text())

        return BytesIO(blob.content_as_bytes())

    def owner(self, path): # TODO
        raise NotImplemented

    def rename(self, path, target): # TODO
        raise NotImplemented

    def replace(self, path, target): # TODO
        raise NotImplemented

    def rmdir(self, path): # TODO
        raise NotImplemented

    def mkdir(self, path, mode): # TODO
        raise NotImplemented

    def container_name(self, path): # TODO
        return self.az.container_name

    def generate_prefix(self, path): # TODO
        raise NotImplemented

    def unlink(self, path, *args, **kwargs): # TODO
        raise NotImplemented


def _string_parser(text, *, mode, encoding): # TODO
    raise NotImplemented


class StatResult(namedtuple('BaseStatResult', 'size, last_modified')):
    """
    Base of os.stat_result but with azure features
    """

    def __getattr__(self, item):
        if item in vars(stat_result):
            raise UnsupportedOperation('{} do not support {} attribute'.format(type(self).__name__, item))
        return super().__getattribute__(item)

    @property
    def st_size(self):
        return self.size

    @property
    def st_mtime(self):
        return self.last_modified.timestamp()


_azure_flavour = _AzureFlavour()
_azure_Accessor = None


def initiate_accessor(connection_string):
    """
    Initiates the global accessor, to be used if the path objects was initiated without the accessor.
    :param connection_string: connection string to the paths blobstore
    :return:
    """
    global _azure_Accessor
    kwargs = {"container_url": connection_string}
    _azure_Accessor = _AzureAccessor(**kwargs)


class PureAzurePath(PurePath):
    """
    PurePath subclass for Azure blob store service.
    S3 is not a file-system but we can look at it like a POSIX system.
    """
    _flavour = _azure_flavour

    __slots__ = ()

    @classmethod
    def from_uri(cls, uri): # TODO

        if not uri.startswith("https://"):
            raise ValueError('...')

        return cls(uri)

    @property
    def container(self): # TODO
        """
        container property
        return a new instance of only the container path
        """
        self._absolute_path_validation()
        return self._accessor.container_name

    @property
    def key(self): # TODO
        """
        bucket property
        return a new instance of only the key path
        """
        raise NotImplemented

    def as_uri(self): # TODO
        """
        Return the path as a 'azure' URI.
        """
        return super().as_uri()

    def _absolute_path_validation(self): # TODO
        if not self.is_absolute():
            raise ValueError('relative path')


class AzurePath(Path, PureAzurePath): # TODO
    """
    Path subclass for Azure blob service.
    Azure provide a Python convenient File-System/Path like interface for Azure blob service
     using azure ContainerClient resource as a driver.
    If azure.core isn't installed in your environment NotImplementedError will be raised.
    """
    __slots__ = ()

    @classmethod
    def from_sas_token(self, path="/", sas_token=None):

        global _azure_Accessor

        kwargs = {"container_url": sas_token}
        _azure_Accessor = _AzureAccessor(**kwargs)

        return self(path)


    @classmethod
    def from_container_url(self, container_url, path="/", sas_token=None):

        global _azure_Accessor

        if sas_token is not None:
            container_url = f'{container_url}?{sas_token}'
        elif os.environ['SAS_TOKEN']:
            container_url = f'{container_url}?{os.environ["SAS_TOKEN"]}'

        kwargs = {"container_url": container_url}
        _azure_Accessor = _AzureAccessor(**kwargs)

        return self(path)

    @classmethod
    def from_sas_connection_string(self, path="/", connection_string=None):

        global _azure_Accessor

        kwargs = {"container_url": connection_string}
        _azure_Accessor = _AzureAccessor(**kwargs)

        return self(path)


    def clone_accessor(self, accessor):
        self._accessor = accessor

    def stat(self): # TODO
        """
        Returns information about this path (similarly to boto3's ObjectSummary).
        For compatibility with pathlib, the returned object some similar attributes like os.stat_result.
        The result is looked up at each call to this method
        """
        self._absolute_path_validation()
        if not self.key:
            return None
        return super().stat()

    def exists(self): # TODO
        """
        Whether the path points to an existing Bucket, key or key prefix.
        """
        self._absolute_path_validation()
        if not self.container:
            return True
        return self._accessor.exists(self)

    def is_dir(self): # TODO
        """
        Returns True if the path points to a Bucket or a key prefix, False if it points to a full key path.
        False is also returned if the path doesn’t exist.
        Other errors (such as permission errors) are propagated.
        """
        self._absolute_path_validation()
        #if self.bucket and not self.key:
        #    return True
        return self._accessor.is_dir(self)

    def is_file(self): # TODO
        """
        Returns True if the path points to a Bucket key, False if it points to Bucket or a key prefix.
        False is also returned if the path doesn’t exist.
        Other errors (such as permission errors) are propagated.
        """
        self._absolute_path_validation()
        if not self.bucket or not self.key:
            return False
        try:
            return bool(self.stat())
        except ClientError:
            return False

    def iterdir(self): # TODO
        """
        When the path points to a Bucket or a key prefix, yield path objects of the directory contents
        """
        self._absolute_path_validation()
        yield from super().iterdir()

    def glob(self, pattern): # TODO
        """
        Glob the given relative pattern in the Bucket / key prefix represented by this path,
        yielding all matching files (of any kind)
        """
        # import ipdb; ipdb.set_trace()

        yield from super().glob(pattern)

    def rglob(self, pattern): # TODO
        """
        This is like calling S3Path.glob with "**/" added in front of the given relative pattern
        """
        yield from super().rglob(pattern)

    def open(self, mode='rb', buffering=DEFAULT_BUFFER_SIZE, encoding=None, errors=None, newline=None): # TODO
        """
        Opens the Bucket key pointed to by the path, returns a Key file object that you can read/write with
        """
        self._absolute_path_validation()
        if mode not in _SUPPORTED_OPEN_MODES:
            raise ValueError('supported modes are {} got {}'.format(_SUPPORTED_OPEN_MODES, mode))
        if buffering == 0 or buffering == 1:
            raise ValueError('supported buffering values are only block sizes, no 0 or 1')
        if 'b' in mode and encoding:
            raise ValueError("binary mode doesn't take an encoding argument")

        #if self._closed:
        #    self._raise_closed()
        return self._accessor.open(
            self,
            mode=mode,
            buffering=buffering,
            encoding=encoding,
            errors=errors,
            newline=newline)

    def owner(self): # TODO
        """
        Returns the owner of the blob, i guess
        """
        raise NotImplemented

    def rename(self, target): # TODO
        """
        Renames this file or Bucket / key prefix / key to the given target.
        If target exists and is a file, it will be replaced silently if the user has permission.
        If path is a key prefix, it will replace all the keys with the same prefix to the new target prefix.
        Target can be either a string or another S3Path object.
        """
        raise NotImplemented


    def replace(self, target): # TODO
        """
        Renames this Bucket / key prefix / key to the given target.
        If target points to an existing Bucket / key prefix / key, it will be unconditionally replaced.
        """
        raise NotImplemented

    def unlink(self, missing_ok=False): # TODO
        """
        Remove this key from its bucket.
        """
        raise NotImplemented

    def rmdir(self): # TODO
        """
        Removes this Bucket / key prefix. The Bucket / key prefix must be empty
        """
        raise NotImplemented

    def samefile(self, other_path): # TODO
        """
        Returns whether this path points to the same blob as other_path,
        Which can be either a Path object, or a string
        """
        raise NotImplemented

    def touch(self, mode=0o666, exist_ok=True): # TODO
        """
        Creates a key at this given path.
        If the key already exists,
        the function succeeds if exist_ok is true (and its modification time is updated to the current time),
        otherwise FileExistsError is raised
        """

        raise NotImplemented


    def mkdir(self, mode=0o777, parents=False, exist_ok=False): # TODO
        """
        Create a path bucket.
        Azure blob service doesn't support folders, therefore the mkdir method will only create the current blob.
        If the blob path already exists, FileExistsError is raised.
        If exist_ok is false (the default), FileExistsError is raised if the target Bucket already exists.
        If exist_ok is true, OSError exceptions will be ignored.
        if parents is false (the default), mkdir will create the bucket only if this is a Bucket path.
        if parents is true, mkdir will create the bucket even if the path have a Key path.
        mode argument is ignored.
        """
        raise NotImplemented

    def is_mount(self): # TODO
        """
        Azure blob service only support mounting on linux enviornments
        """
        return False

    def is_symlink(self): # TODO
        """
        Azure blob service doesn't have symlink feature, There for this method will always return False
        """
        return False

    def is_socket(self): # TODO
        """
        Azure blob service doesn't have sockets feature, There for this method will always return False
        """
        return False

    def is_fifo(self): # TODO
        """
        Azure blob service doesn't have fifo feature, There for this method will always return False
        """
        return False


    def _init(self, template=None, sas_token=None): # TODO
        super()._init(template)

        if sas_token is not None:
            global _azure_Accessor

            kwargs = {"container_url": sas_token}
            _azure_Accessor = _AzureAccessor(**kwargs)

        if template is None:
            global azure_Accessor
            self._accessor = _azure_Accessor

class AzureDirEntry:

    def __init__(self, name, is_dir, size=None, last_modified=None):
        self.name = name
        self._is_dir = is_dir
        self._stat = StatResult(size=size, last_modified=last_modified)

    def __repr__(self):
        return '{}(name={}, is_dir={}, stat={})'.format(
            type(self).__name__, self.name, self._is_dir, self._stat)

    def inode(self, *args, **kwargs):
        return None

    def is_dir(self):
        return self._is_dir

    def is_file(self):
        return not self._is_dir

    def is_symlink(self, *args, **kwargs):
        return False

    def stat(self):
        return self._stat

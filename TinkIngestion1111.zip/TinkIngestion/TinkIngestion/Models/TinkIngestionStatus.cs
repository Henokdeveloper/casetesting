﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TinkIngestion.Models
{
    public class TinkIngestionStatus
    {
        public string WalletId { get; set; }
        public string IBAN { get; set; }
        public bool AccountIngestionStatus { get; set; }
        public bool TxnIngestionStatus { get; set; }
        public string ExternalIds { get; set; }
    }
}

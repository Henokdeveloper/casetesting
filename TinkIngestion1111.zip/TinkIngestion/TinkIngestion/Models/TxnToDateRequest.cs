﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TinkIngestion.Models
{
    public class TxnToDateRequest
    {
        public string TxnToDate { get; set; }
        public string InvokeType { get; set; }
    }
}

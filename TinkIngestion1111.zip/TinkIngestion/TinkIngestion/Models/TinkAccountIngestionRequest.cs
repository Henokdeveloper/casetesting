﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TinkIngestion.Models
{
    public class TinkAccountIngestionRequest
    {
        public string CustomerID { get; set; }
        public string ProductID { get; set; }
        public string AccountNo { get; set; }
        public string IBAN { get; set; }
        public string BANKID { get; set; }
        public string WalletType { get; set; }
        public string SettledBalance { get; set; }
        public string WalletNickName { get; set; }
        public string WalletID { get; set; }
        public string TxnFrmDate { get; set; }
        public string TxnToDate { get; set; }
        public string Index { get; set; }
        public string TestInstance { get; set; }

        public List<MasterTransacationDetails> TxnMasterData { get; set; }
        public string InvokeType { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TinkIngestion.Models
{
    public class TinkIngestAPIRequest
    {
        public bool autoBook { get; set; }
        public bool overridePending { get; set; }
        public List<TransactionAccount> transactionAccounts { get; set; }
        public string type { get; set; }

    }
    public class TransactionAccount
    {
        public string balance { get; set; }
        public string externalId { get; set; }
        public List<Transactions> transactions { get; set; }

    }
    public class Transactions
    {
        public string amount { get; set; }
        public string date { get; set; }
        public string description { get; set; }
        public string externalId { get; set; }
        public string pending { get; set; }
        public string type { get; set; }

    }

}

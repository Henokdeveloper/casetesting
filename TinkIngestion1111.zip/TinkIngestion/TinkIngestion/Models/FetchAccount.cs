﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TinkIngestion.Models
{
    public class FetchAccount
    {
        public List<AccountDetails> Accounts { get; set; }
    }
    public class AccountDetails
    {
        public string AccountNumber { get; set; }
        public string BankId { get; set; }
        public string Type { get; set; }

    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TinkIngestion.Models
{
    public class AccountIngestionRequest
    {
        public List<Accounts> accounts { get; set; }
    }
    public class Accounts
    {
        public string availableCredit { get; set; }
        public string balance { get; set; }
        public bool closed { get; set; }
        public string exclusion { get; set; }
        public string externalId { get; set; }
        public string name { get; set; }
        public string number { get; set; }
        public string type { get; set; }

    }
}

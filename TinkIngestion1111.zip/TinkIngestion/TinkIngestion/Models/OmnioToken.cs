﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TinkIngestion
{
    class OmnioToken
    {
        public string Issue { get; set; }
        public string Audience { get; set; }
        public string Ckey { get; set; }
        public string CSecret { get; set; }
        public string Pkhash { get; set; }
        public string CustRefId { get; set; }
        public long Iat { get; set; }
        public long Nbf { get; set; }
        public long Expiry { get; set; }
        public string OmnioRSAKeyPgpEncrypted { get; set; }

        public string PgpPrivateKeyBase64Encoded { get; set; }
        public string PgpCertificatePassPhrase { get; set; }
    }
}

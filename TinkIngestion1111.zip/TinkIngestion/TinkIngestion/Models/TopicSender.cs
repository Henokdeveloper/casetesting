﻿using Azure.Messaging.ServiceBus;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TinkIngestion.Domain;

namespace TinkIngestion
{
    public class TopicSender
    {
        string serviceBusConnectionString = Environment.GetEnvironmentVariable("Service_Bus_Con_String");
        string topicName = Environment.GetEnvironmentVariable("Service_Bus_Topic");
        ILogger _logger;

        ServiceBusClient client;
        ServiceBusSender sender;
        public TopicSender(ILogger logger)
        {
            _logger = logger;
        }
        public async void SendMessageeAsync(string statusPayload, string source)
        {

            try
            {
                //await Task.Run(() =>
                //{
                client = new ServiceBusClient(serviceBusConnectionString);
                sender = client.CreateSender(topicName);
                ServiceBusMessage message = new ServiceBusMessage(statusPayload);

                // ServiceBusMessageBatch messageBatch = sender.CreateMessageBatchAsync().Result;

                //if (!messageBatch.TryAddMessage(new ServiceBusMessage($"{statusPayload}")))
                //{
                //    throw new Exception($"The message {statusPayload} is too large to fit in the batch.");
                //}
                try
                {
                    //_logger.LogInformation($"TopicSender SendMessageeAsync messagebatch count {messageBatch.Count}");
                    _logger.LogInformation($"TopicSender SendMessagesAsync started for {source}");
                    await sender.SendMessageAsync(message);
                    _logger.LogInformation($"TopicSender SendMessagesAsync completed for {source}");
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Exception occured in sendMessageAsync method, while sending payloads to topic : {ex.Message}");
                }
                //});
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception occured while establishing connection to service bus topic : {ex.Message}");
            }
        }
    }
}

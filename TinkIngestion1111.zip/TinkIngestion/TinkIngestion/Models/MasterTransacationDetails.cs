﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TinkIngestion.Models
{
    public class MasterTransacationDetails
    {
        public string amount { get; set; }
        public string date { get; set; }
        public string description { get; set; }
        public string externalId { get; set; }
        public string pending { get; set; }
        public string type { get; set; }
        public string WalletID { get; set; }
        public string IBAN { get; set; }
        public string dateTime { get; set; }
    }
}

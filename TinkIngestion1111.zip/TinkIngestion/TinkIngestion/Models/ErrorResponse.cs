﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TinkIngestion.Models
{
    public class ErrorResponse
    {
        public string ErrorMessage { get; set; }
        public List<Errors> Errors { get; set; }
    }
    public class Errors
    {
        public string errormessage { get; set; }
        public string FieldName { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TinkIngestion
{
    public static class constants
    {
        public static class OmnioKeys
        {
            public const string issue = "http://anpost.com";
            public const string audience = "http://omnio.global";
            
        }

        public static class AzureKeysSecrets
        {
        public const string ominoKeyVault = "env_omnio_keyvault";
        public const string cKeySecretName = "env_kvs_omnio_ckey";
        public const string cKeyPwdSecretName = "env_kvs_omnio_csecret";
        public const string pkhashSecretName = "env_kvs_omnio_pkhash";
        public const string encryptSecretName = "env_kvs_omnio_encryptstring";
        public const string pgpSecretName = "env_kvs_omnio_pgpkey";
        public const string passPhrase = "env_kvs_omnio_passphrase";
        }

    }
}

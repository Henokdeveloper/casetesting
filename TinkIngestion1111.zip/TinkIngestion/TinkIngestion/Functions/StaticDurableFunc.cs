using Azure.Core;
using Azure.Messaging.ServiceBus;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TinkIngestion.Domain;
using TinkIngestion.Models;

namespace TinkIngestion.Functions
{
    public class StaticDurableFunc
    {
        static SqlConnection _sqlConnection;

        public static List<TinkWalletAccount> tinkWalletSAccountDetails;
        public static List<MasterTransacationDetails> ls_MastertransactionsListFromDB;
        public static List<int> listInt;

        public static string connectionStringForDB = string.Empty;
        public static string TinkClientID = string.Empty;
        public static string TinkClientSecret = string.Empty;

        public static string ServiceBus_Conn_String = string.Empty;
        public static string Tink_Auth_Grant_Api_Url = string.Empty;
        public static string Tink_AccountFetch_Api_Url = string.Empty;
        public static string Tink_Auth_Api_Url = string.Empty;
        public static string Test_Instance = string.Empty;
        public static string serviceBusConnectionString = Environment.GetEnvironmentVariable("Service_Bus_Con_String");
        public static string topicName = Environment.GetEnvironmentVariable("Service_Bus_Topic");

        public static ServiceBusClient serviceBusClient = null;
        public static ServiceBusSender sender = null;

        public static SemaphoreSlim _semaphoregate = null;

        static int intCount;
        static StaticDurableFunc()
        {

            _sqlConnection = new SqlConnection(Environment.GetEnvironmentVariable("Db_Con_String"));
            _sqlConnection.Open();
            listInt = new List<int>();
            ls_MastertransactionsListFromDB = new List<MasterTransacationDetails>();
            tinkWalletSAccountDetails = new List<TinkWalletAccount>();

            serviceBusClient = new ServiceBusClient(serviceBusConnectionString);
            sender = serviceBusClient.CreateSender(topicName);

            _semaphoregate = new SemaphoreSlim(Convert.ToInt16(Environment.GetEnvironmentVariable("semaphoregate_Count")));
        }

        [FunctionName("StaticMMOrchestrator")]
        public async Task<string> RunOrchestrator(
            [OrchestrationTrigger] IDurableOrchestrationContext context, ILogger logger)
        {
            try
            {
                logger.LogInformation($"************** RunOrchestrator method executing  ********************");
                logger.LogInformation($"RunOrchestrator started at {DateTime.Now}");

                //int loopCount = Convert.ToInt16(Environment.GetEnvironmentVariable("Loop_Count"));
                //int batchCount = Convert.ToInt16(Environment.GetEnvironmentVariable("Batch_Count"));
                //int delayTime = Convert.ToInt16(Environment.GetEnvironmentVariable("Delay_Count"));//100
                //string listOfIndexes = Environment.GetEnvironmentVariable("Index_List");//100
                //var newIndexList = listOfIndexes.Split(",").ToList();
                //Test_Instance = Environment.GetEnvironmentVariable("Test_Instance");

                var httpReqBody = context.GetInput<TxnToDateRequest>();
                logger.LogInformation($"Request body json: {JsonConvert.SerializeObject(httpReqBody)}");

                if (!context.IsReplaying)
                {

                    Random random = new Random();
                    logger.LogInformation($"RunOrchestrator method execution started with Random Number {random.Next(1, 10)}");
                    var randomInstanceNumber = random.Next(1, 1000);
                    logger.LogInformation($"RunOrchestrator method execution started with Random Number: {randomInstanceNumber}");
                    //logger.LogInformation($"loopCount = {loopCount} and batchCount = {batchCount}");

                    if (_sqlConnection.State != ConnectionState.Open)
                    {
                        _sqlConnection.Open();
                    }
                    bool Isrecordsdeleted = DeleteWalletAndTransactionsFromDB(logger);
                    logger.LogInformation($"Isrecordsdeleted before MMOpted starts = {Isrecordsdeleted}");

                    TxnToDateRequest requestBody = context.GetInput<TxnToDateRequest>();
                    List<TinkAccountIngestionRequest> listMMOptedUsers = new List<TinkAccountIngestionRequest>();
                    var listOutput = GetMMOptedAccountsDetails(logger); // get all users
                    listMMOptedUsers = listOutput;

                    //bool Loop_Required = Convert.ToBoolean(Environment.GetEnvironmentVariable("Loop_Required"));
                    //for (int i = 0; i < loopCount; i++)
                    //{
                    //    listMMOptedUsers.AddRange(listOutput);
                    //}

                    var fetchAllTransactionsResponse = FetchMasterTransactionsDetailsFromDB(logger);
                    ls_MastertransactionsListFromDB = fetchAllTransactionsResponse;
                    string mindate = GetMinDateTimeFromMasterTxnsList(ls_MastertransactionsListFromDB, logger);

                    logger.LogInformation($"StaticMMTinkIngestion opted users count {listMMOptedUsers.Count} and ls_MastertransactionsListFromDB count {ls_MastertransactionsListFromDB.Count}");
                    if (listMMOptedUsers.Count > 0)
                    {
                        logger.LogInformation($"StaticMMTinkIngestion opted users found");
                        int index = 0;

                        foreach (var item in listMMOptedUsers)
                        {
                            logger.LogInformation($"foreach loop with instance:{randomInstanceNumber} and index value: {index}");
                            logger.LogInformation($"foreach MMTinkIngestion user id {item.CustomerID}, walletID {item.WalletID}");
                            TinkAccountIngestionRequest tinkAccountIngestionRequest = item;
                            tinkAccountIngestionRequest.TxnToDate = requestBody.TxnToDate;
                            tinkAccountIngestionRequest.TxnFrmDate = mindate;
                            tinkAccountIngestionRequest.TxnMasterData = ls_MastertransactionsListFromDB;
                            tinkAccountIngestionRequest.Index = index.ToString();
                            tinkAccountIngestionRequest.InvokeType = httpReqBody.InvokeType;
                            tinkAccountIngestionRequest.TestInstance = randomInstanceNumber.ToString();

                            var task = context.CallActivityAsync<TinkIngestionStatusPayload>("StaticMMTinkIngestion", tinkAccountIngestionRequest);

                            index++;
                        }

                    }
                    else
                    {
                        logger.LogInformation($"No records found for TINK ingestion for instance {randomInstanceNumber} on datetime {DateTime.Now}");
                    }

                }



                logger.LogInformation($"********All Activites completed for instance and MMActivity Count = {listInt.Count}***********");

                logger.LogInformation($"RunOrchestrator completed at {DateTime.Now}");
                logger.LogInformation("RunOrchestrator return true");
                return "true";

            }
            catch (Exception ex)
            {
                logger.LogError($" exception {ex.Message}");
                return "false";

            }
        }

        private static string GetMinDateTimeFromMasterTxnsList(List<MasterTransacationDetails> masterTransacationDetails, ILogger logger)
        {
            try
            {
                logger.LogInformation("GetMinDateTimeFromMasterTxnsList method started");
                List<DateTime> datesList = new List<DateTime>();
                foreach (var item in masterTransacationDetails)
                {
                    DateTime parsedate;
                    var isParsed = DateTime.TryParseExact(item.dateTime, "yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.None, out parsedate);
                    if (isParsed)
                        datesList.Add(parsedate);
                }

                if (datesList?.Count > 0)
                {
                    DateTime minDate = datesList.Min();
                    DateTime maxDate = datesList.Max();
                    logger.LogInformation($"GetMinDateTime with Mindate = {minDate}, maxDate = {maxDate}");
                    logger.LogInformation("GetMinDateTimeFromMasterTxnsList method completed");
                    return minDate.ToString();
                }
                return string.Empty;
            }
            catch (Exception ex)
            {
                logger.LogInformation($"Exception in GetMinDateTimeFromMasterTxnsList with message {ex.Message}");
                CustomExceptionMessageLogger("GetMinDateTimeFromMasterTxnsList", ex, logger);
                return string.Empty;
            }
        }

        [FunctionName("StaticMMTinkIngestion")]
        public static TinkIngestionStatusPayload MMTinkIngestionFunction([ActivityTrigger] TinkAccountIngestionRequest tinkAccountIngestionRequest, ILogger logger)
        {
            StaticDurableFunc.intCount++;

            logger.LogInformation($"MMTinkIngestion Test load started for instance {tinkAccountIngestionRequest.TestInstance}");
            string transactionErrorMessage = string.Empty, AccountErrorMessage = string.Empty, AccessToken = string.Empty;
            logger.LogInformation($"MMTinkIngestionFunction started for UID {tinkAccountIngestionRequest.CustomerID}, walletID {tinkAccountIngestionRequest.WalletID}");
            Stopwatch sw = new Stopwatch();
            sw.Start();
            TinkIngestionStatusPayload statusPayload = null;

            try
            {
                GetAllEnvironmentVariables(logger);

                var bearerToken = GetBearerToken(tinkAccountIngestionRequest, logger); // return token
                var getTinkAccountListResponse1 = GetTinkExistingAccountList(tinkAccountIngestionRequest, bearerToken, logger); //getAccountDetails

                var tinkWalletDetails = CheckWalletExistsOrNotFromList(tinkAccountIngestionRequest, logger);
                if (tinkWalletDetails != null & Convert.ToInt32(tinkWalletDetails.Recordcount) > 0)
                {
                    AccountErrorMessage = "Account already exists";
                    logger.LogInformation($"customer ID {tinkAccountIngestionRequest.CustomerID} and walletID {tinkAccountIngestionRequest.WalletID} already exits in TINK");
                    //we have to call Transaction Ingestion 
                    statusPayload = FetchAndIngestTransaction(tinkAccountIngestionRequest, tinkWalletDetails, tinkAccountIngestionRequest.WalletID, tinkAccountIngestionRequest.IBAN, logger, AccountErrorMessage);
                    sw.Stop();

                    logger.LogInformation($"FetchAndIngestTransaction completed for UID {tinkAccountIngestionRequest.CustomerID} performance counter time = {sw.Elapsed} and end datetime : {DateTime.Now}");

                }
                else
                {
                    //we have to call the both Account & Transaction Ingestion
                    logger.LogInformation($"tinkWalletDetails count = 0 and TinkIngestWallet Started");
                    var token = Tink_OAuth_Token(logger, tinkAccountIngestionRequest.InvokeType, tinkAccountIngestionRequest.TestInstance).Result;
                    statusPayload = TinkIngestWallet(tinkAccountIngestionRequest, token.access_token, tinkWalletDetails, logger, AccountErrorMessage);

                    sw.Stop();

                    logger.LogInformation($"TinkIngestWallet performance for UID {tinkAccountIngestionRequest.CustomerID} performance time = {sw.Elapsed} and end datetime : {DateTime.Now}");

                }
                logger.LogInformation($"MMTinkIngestion Test load completed for instance {tinkAccountIngestionRequest.TestInstance} and Index {tinkAccountIngestionRequest.Index} and intCount {intCount}");
                return statusPayload;
            }
            catch (Exception ex)
            {
                sw.Stop();
                logger.LogInformation($"ExcePtion in Main Method for UID {tinkAccountIngestionRequest.CustomerID} with Message{ex.Message} & performance counter time = {sw.Elapsed} and end datetime : {DateTime.Now}");
                CustomExceptionMessageLogger("MMTinkIngestionFunction", ex, logger, tinkAccountIngestionRequest);
                return statusPayload;
            }

        }

        /*Delete the exisitng records from DB in Wallet & Transaction tables before starting the activity func */
        public static bool DeleteWalletAndTransactionsFromDB(ILogger logger)
        {
            logger.LogInformation($"DeleteWalletAndTransactionsFromDB started");
            try
            {
                string connectionStringForDB = Environment.GetEnvironmentVariable("Db_Con_String");

                if (_sqlConnection.State != ConnectionState.Open)
                    _sqlConnection.Open();

                string deleteWalletsCommand = "DELETE FROM [eco].[ecoTinkWalletIngestion] WHERE CRN NOT IN ( SELECT DISTINCT EW.CRN FROM [eco].[ecoTinkWalletIngestion] EW INNER JOIN [ECO].ecosbstatus SBS ON SBS.ProductID = EW.CRN AND SBS.IsValidUser = 'Y' );";

                using (SqlCommand command = new SqlCommand(deleteWalletsCommand, _sqlConnection))
                {

                    int totalWalletRecordsDeleted = command.ExecuteNonQueryAsync().Result;
                    logger.LogInformation($"DeleteWalletAndTransactionsFromDB  Method total records deleted from ecoTinkWalletIngestion table = {totalWalletRecordsDeleted}");
                }

                string deleteTransactionsCommand = "DELETE FROM eco.ecoTinkTransactionIngestion WHERE WalletId NOT IN ( SELECT distinct WalletId FROM eco.ecoTinkWalletIngestion );";
                using (SqlCommand command = new SqlCommand(deleteTransactionsCommand, _sqlConnection))
                {

                    int totalTxnRecordsDeleted = command.ExecuteNonQueryAsync().Result;
                    logger.LogInformation($"DeleteWalletAndTransactionsFromDB  Method total records deleted from ecoTinkTransactionIngestion table = {totalTxnRecordsDeleted}");
                }

                logger.LogInformation("DeleteWalletAndTransactionsFromDB completed");
                _sqlConnection.Close();

                return true;

            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in DeleteWalletAndTransactionsFromDB with message {ex.Message}"); //handle alert

                CustomExceptionMessageLogger("DeleteWalletAndTransactionsFromDB", ex, logger);
                return false;
            }
        }

        /* get All MM opted users from DB*/
        public static List<TinkAccountIngestionRequest> GetMMOptedAccountsDetails(ILogger logger)
        {
            logger.LogInformation($"GetMMOptedAccountsDetails started");
            try
            {
                string connectionStringForDB = Environment.GetEnvironmentVariable("Db_Con_String");
                List<TinkAccountIngestionRequest> listMMOptedUsers = new List<TinkAccountIngestionRequest>();

                if (_sqlConnection.State != ConnectionState.Open)
                    _sqlConnection.Open();

                string selectedCommand = "SELECT DISTINCT CP.ProductID, CP.CustomerID, CP.AccountNo, EW.IBAN, EW.WalletId, CP.ProductTypeID, SBS.IsValidUser, EW.WalletType, EW.SettledBalance, EW.WalletNickName, EW.CRN + CP.AccountNo + EW.WalletId AS 'BANKID', SBS.TxnFromDate as 'LastRunTxnFromDate', SBS.TxnToDate as 'LastRunTxnToDate' FROM [ECO].ecoCustomerProduct CP INNER JOIN eco.ecosbstatus SBS ON SBS.ProductID = CP.ProductID AND SBS.CustomerID=CP.CustomerID AND SBS.AccountNo=CP.AccountNo INNER JOIN eco.ecoFirstLogin FL ON FL.ProductID=CP.ProductID AND FL.AccountNo=CP.AccountNo AND CP.ProductID = SBS.ProductID INNER JOIN [eco].[ecoTinkWalletIngestion] EW ON EW.CRN = CP.ProductID and EW.IBAN=FL.IBAN WHERE CP.ProductTypeID = 6 AND SBS.IsValidUser = 'Y'  ORDER BY CP.CustomerID DESC;";

                using (SqlCommand command = new SqlCommand(selectedCommand, _sqlConnection))
                {

                    using (SqlDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            TinkAccountIngestionRequest tinkIngestusers = new TinkAccountIngestionRequest();
                            tinkIngestusers.ProductID = dr.GetValue(0).ToString();
                            tinkIngestusers.CustomerID = dr.GetValue(1).ToString();
                            tinkIngestusers.AccountNo = dr.GetValue(2).ToString();
                            tinkIngestusers.IBAN = dr.GetValue(3).ToString();
                            tinkIngestusers.WalletID = dr.GetValue(4).ToString();
                            //tinkIngestusers.ProductTypeID = dr.GetValue(5).ToString();
                            //tinkIngestusers.IsValidUser = dr.GetValue(6).ToString();
                            tinkIngestusers.WalletType = dr.GetValue(7).ToString();
                            tinkIngestusers.SettledBalance = dr.GetValue(8).ToString();
                            tinkIngestusers.WalletNickName = dr.GetValue(9).ToString();

                            tinkIngestusers.BANKID = dr.GetValue(10).ToString();
                            tinkIngestusers.TxnFrmDate = dr.GetValue(11).ToString();
                            tinkIngestusers.TxnToDate = dr.GetValue(12).ToString();
                            listMMOptedUsers.Add(tinkIngestusers);
                        }
                        dr.Close();
                    }

                }
                logger.LogInformation($"MMTinkIngestionFunction completed and total MM opted user list count = {listMMOptedUsers.Count}");
                _sqlConnection.Close();

                return listMMOptedUsers;

            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in GetMMOptedAccountsDetails with message {ex.Message}"); //handle alert

                CustomExceptionMessageLogger("GetMMOptedAccountsDetails", ex, logger);
                throw;
            }
        }

        /*Converts the date value into Epoch value*/
        public static string EpocDateConvertor(string date, ILogger logger)
        {
            try
            {
                logger.LogInformation($"EpocDateConvertor method started");
                string EpocFormat = "";
                DateTime startDate;

                var data = DateTime.TryParseExact(date, "dd-MM-yyyy",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out startDate);
                if (data)
                {
                    DateTime epochTime = DateTime.Parse("1970-01-01 00:00:00.000");
                    EpocFormat = Convert.ToString(startDate.Subtract(epochTime).TotalMilliseconds);
                }
                else
                {
                    EpocFormat = date;
                }
                logger.LogInformation($"EpocDateConvertor method completed");
                return EpocFormat;

            }
            catch (Exception ex)
            {
                logger.LogError($"exception in EpocDateConvertor with message {ex.Message}");
                CustomExceptionMessageLogger("EpocDateConvertor", ex, logger);
                return date;
            }
        }

        /*Converts the date&time value into Epoch value*/
        public static string EpocDateTimeConvertor(string date, ILogger logger)
        {
            try
            {
                string EpocFormat = "";
                DateTime startDate;
                logger.LogInformation($"EpocDateTimeConvertor Method started incoming date {date}");

                var data = DateTime.TryParseExact(date, "yyyy-MM-dd HH:mm:ss",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out startDate);
                if (data)
                {
                    DateTime epochTime = DateTime.Parse("1970-01-01 00:00:00.000");
                    EpocFormat = Convert.ToString(startDate.Subtract(epochTime).TotalMilliseconds);
                }
                else
                {
                    EpocFormat = date;
                }
                logger.LogInformation($"EpocDateTimeConvertor completed with out going date= {EpocFormat}");
                return EpocFormat;
            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in EpocDateTimeConvertor with message {ex.Message}");
                CustomExceptionMessageLogger("EpocDateTimeConvertor", ex, logger);
                return date;
            }
        }

        /*Logs the custom exception message to send Azure appInsight alerts*/
        public static void CustomExceptionMessageLogger(string methodName, Exception ex, ILogger logger, [Optional] TinkAccountIngestionRequest tinkAccountIngestionRequest)
        {
            logger.LogError($"In DurableFunc CustomExceptionMessageLogger triggered and Exception occurred in Method {methodName} for UID {tinkAccountIngestionRequest?.CustomerID} " +
                $"and WalletID {tinkAccountIngestionRequest?.WalletID} with message {ex?.Message}");
        }

        /*Logs the API statuscode message if response code is TooManyreq ro InternalServerError to send Azure appInsight alerts*/
        public static void StatusCodeMessageLogger(string APIName, string statusCodes, ILogger logger, [Optional] TinkAccountIngestionRequest tinkAccountIngestionRequest)
        {
            logger.LogCritical($"In DurableFunc TINK API failed and StatusCodeMessageLogger triggered for  {APIName} API with statusCode {statusCodes}" +
                $" for UID {tinkAccountIngestionRequest?.CustomerID} and WalletID {tinkAccountIngestionRequest?.WalletID}");
        }

        /*Fetches all the Transactions data from Trxn table from DB*/
        public static List<MasterTransacationDetails> FetchMasterTransactionsDetailsFromDB(ILogger logger)
        {
            try
            {
                List<MasterTransacationDetails> transactionsList = new List<MasterTransacationDetails>();

                logger.LogInformation("FetchMasterTransactionsDetailsFromDB started");
                string connectionString = Environment.GetEnvironmentVariable("Db_Con_String");
                //string selectCommand = "SELECT TF.SettlementAmount as 'amount',   CAST(DATEDIFF_BIG(MILLISECOND, '1970-01-01 00:00:00.000',  CONVERT(DATETIME,SettlementDate,103)) as bigint) as 'date',   TF.TransactionDescription as 'description',   CONCAT(ISNULL(TF.TLOGID, 0), ISNULL( TF.ITEMID,0) , ISNULL(TF.FEEID,0) ,CAST(DATEDIFF_BIG(MILLISECOND, '1970-01-01 00:00:00.000',  CAST(convert(varchar(20), CONVERT(DATETIME,SettlementDate,103),112) as datetime)) as bigint)) AS 'externalId',    'false' as 'pending', 'DEFAULT' as 'type'  FROM [ECO].[ecoCustomerProduct] CP    INNER JOIN eco.ecoFirstLogin FL  ON   CP.ProductID = FL.ProductID AND   CP.AccountNo=FL.AccountNo    INNER JOIN  [eco].[ecoTinkWalletIngestion] WF  ON    WF.CRN = CP.ProductID  AND    WF.IBAN=FL.IBAN  INNER JOIN [eco].[ecoTinkTransactionIngestion] TF  ON    TF.IBAN = WF.IBAN AND    TF.WalletId = WF.WalletId  WHERE  CP.ProductTypeID = 6 AND TF.WalletId  = @WalletID AND TF.IBAN= @IBAN  ORDER BY CP.CustomerID DESC";
                //string selectCommand = "SELECT  TF.SettlementAmount as 'amount',  CAST(DATEDIFF_BIG(MILLISECOND, '1970-01-01 00:00:00.000',  CONVERT(DATETIME,TransactionDate,103)) as bigint) as 'date', \r\nTF.TransactionDescription as 'description',   CONCAT(ISNULL(TF.TLOGID, 0), ISNULL( TF.ITEMID,0) , ISNULL(TF.FEEID,0) ,CAST(DATEDIFF_BIG(MILLISECOND, '1970-01-01 00:00:00.000',  CAST(convert(varchar(20),\r\nCONVERT(DATETIME,TransactionDate,103),112) as datetime)) as bigint)) AS 'externalId',    'false' as 'pending', 'DEFAULT' as 'type' ,\r\nTF.WalletId, TF.IBAN\r\nFROM [ECO].[ecoCustomerProduct] CP    INNER JOIN eco.ecoFirstLogin FL  ON   CP.ProductID = FL.ProductID AND   CP.AccountNo=FL.AccountNo  \r\nINNER JOIN  [eco].[ecoTinkWalletIngestion] WF  ON    WF.CRN = CP.ProductID  AND    WF.IBAN=FL.IBAN  INNER JOIN [eco].[ecoTinkTransactionIngestion] TF \r\nON    TF.IBAN = WF.IBAN AND    TF.WalletId = WF.WalletId  WHERE  CP.ProductTypeID = 6  ORDER BY CP.CustomerID DESC";
                string selectCommand = "SELECT  TF.SettlementAmount as 'amount',  TransactionDate as 'date', CAST( CAST( SettlementDate AS char(8)) AS date ) as 'SettlementDate', TF.TransactionDescription as 'description',  TF.TransactionLineID AS 'externalId' ,    'false' as 'pending', 'DEFAULT' as 'type' , TF.WalletId, TF.IBAN,TF.TransactionDate FROM [ECO].[ecoCustomerProduct] CP    INNER JOIN eco.ecoFirstLogin FL  ON   CP.ProductID = FL.ProductID AND   CP.AccountNo=FL.AccountNo  INNER JOIN  [eco].[ecoTinkWalletIngestion] WF  ON    WF.CRN = CP.ProductID  AND    WF.IBAN=FL.IBAN  INNER JOIN [eco].[ecoTinkTransactionIngestion] TF ON    TF.IBAN = WF.IBAN AND    TF.WalletId = WF.WalletId  WHERE  CP.ProductTypeID = 6  ORDER BY CP.CustomerID DESC";

                if (_sqlConnection.State != ConnectionState.Open)
                    _sqlConnection.Open();

                using (SqlCommand command = new SqlCommand(selectCommand, _sqlConnection))
                {
                    using (SqlDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            MasterTransacationDetails transactions = new MasterTransacationDetails();
                            transactions.amount = dr.GetValue(0).ToString();
                            transactions.date = EpocDateTimeConvertor(dr.GetValue(1).ToString(), logger);
                            transactions.description = dr.GetValue(3).ToString();
                            transactions.externalId = dr.GetValue(4).ToString();//string.Concat(dr.GetValue(4).ToString(), EpocDateConvertor(dr.GetValue(2).ToString(),logger));
                            transactions.pending = dr.GetValue(5).ToString();
                            transactions.type = dr.GetValue(6).ToString();
                            transactions.WalletID = dr.GetValue(7).ToString();
                            transactions.IBAN = dr.GetValue(8).ToString();
                            transactions.dateTime = dr.GetValue(1).ToString();
                            transactionsList.Add(transactions);
                        }
                    }
                }
                logger.LogInformation($"FetchMasterTransactionsDetailsFromDB completed  with count {transactionsList.Count}");
                _sqlConnection.Close();
                return transactionsList;

            }
            catch (Exception ex)
            {
                logger.LogWarning($"Exception in FetchMasterTransactionsDetailsFromDB with Message {ex.Message}"); //handle alert
                CustomExceptionMessageLogger("FetchMasterTransactionsDetailsFromDB", ex, logger);
                throw;
            }
        }

        /*API Request call for GetAccountsAPI*/
        public static HttpResponseMessage GetAsyncAccountListAPIRequest(string bearerToken, ILogger logger)
        {
            logger.LogInformation("GetAsyncAccountListAPIRequest method started");
            HttpResponseMessage response = null;
            try
            {
                HttpClient newClient = new HttpClient();

                if (_semaphoregate == null)
                    _semaphoregate = new SemaphoreSlim(Convert.ToInt16(Environment.GetEnvironmentVariable("semaphoregate_Count")));

                newClient.DefaultRequestHeaders.Clear();
                newClient.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json");
                newClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {bearerToken}");

                //Read Server Response
                Tink_AccountFetch_Api_Url = Environment.GetEnvironmentVariable("id-tink-fetchaccount-api-url");
                logger.LogInformation("static AccountList TinkAPI called");
                _semaphoregate.WaitAsync();
                response = newClient.GetAsync(Tink_AccountFetch_Api_Url).Result;
                var semaphoreCount = _semaphoregate.Release();
                logger.LogInformation($"GetAsyncAccountListAPIRequest _semaphoregate count {semaphoreCount}");
                logger.LogInformation("GetAsyncAccountListAPIRequest method completed");
                return response;

            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in GetAsyncAccountListAPIRequest with message {ex.Message}");
                CustomExceptionMessageLogger("GetAsyncAccountListAPIRequest", ex, logger);
                return response;
            }


        }

        /*Return true or false if all Config conditions satisfy*/
        public static bool EnvironmentCheck(string env, List<string> uatUsersList, TinkAccountIngestionRequest tinkAccountIngestionRequest, ILogger logger)
        {
            logger.LogInformation($"EnvironmentCheck started Env = {env}, uatUsersList = {JsonConvert.SerializeObject(uatUsersList)} , customerID = {tinkAccountIngestionRequest.CustomerID}");
            if (env == "PRD" || env == "QA" || (env == "UAT" && uatUsersList.Contains(tinkAccountIngestionRequest.CustomerID)))
            {
                logger.LogInformation($"EnvironmentCheck completed returned true for UID {tinkAccountIngestionRequest.CustomerID}");
                return true;
            }
            else
            {
                logger.LogInformation($"EnvironmentCheck completed returned false for UID {tinkAccountIngestionRequest.CustomerID}");
                return false;
            }
        }

        /*Get All GetTinkExistingAccountList*/
        private static FetchAccount GetTinkExistingAccountList(TinkAccountIngestionRequest tinkAccountIngestionRequest, string bearerToken, ILogger logger)
        {
            try
            {
                logger.LogInformation($"GetTinkExistingAccountList  started for customerID : {tinkAccountIngestionRequest.CustomerID} & walletID {tinkAccountIngestionRequest.WalletID}");
                FetchAccount fetchAccountResponse = null;
                HttpResponseMessage response = null;
                for (int i = 0; i < 5; i++)
                {
                    response = GetAsyncAccountListAPIRequest(bearerToken, logger);
                    if (response.StatusCode == HttpStatusCode.TooManyRequests)
                    {
                        logger.LogInformation($"In forLoop GetTinkExistingAccountList in continue block responseCode {response.StatusCode}");
                        Task.Delay(2000);
                        continue;
                    }
                    else
                    {
                        logger.LogInformation($"In forLoop GetTinkExistingAccountList in break block responseCode {response.StatusCode}");
                        break;
                    }
                }
                string responseContent = response.Content.ReadAsStringAsync().Result;

                logger.LogInformation($"GetTinkExistingAccountList completed for instance {tinkAccountIngestionRequest.TestInstance} with status code {response.StatusCode}");

                if ((tinkAccountIngestionRequest.InvokeType == "SECOND" && response.StatusCode == HttpStatusCode.TooManyRequests) || response.StatusCode == HttpStatusCode.InternalServerError)
                {
                    StatusCodeMessageLogger("GetTinkExistingAccountList", response?.StatusCode.ToString(), logger, tinkAccountIngestionRequest);
                }

                if (response.IsSuccessStatusCode)
                {
                    fetchAccountResponse = JsonConvert.DeserializeObject<FetchAccount>(responseContent);
                    logger.LogInformation($"GetTinkExistingAccountList SerializeObject response for CustomerID {tinkAccountIngestionRequest.CustomerID} - {JsonConvert.SerializeObject(fetchAccountResponse)}");
                    if (fetchAccountResponse != null && fetchAccountResponse.Accounts.Count > 0)
                    {
                        InsertTinkAccountInList(tinkAccountIngestionRequest, fetchAccountResponse, logger);
                        return fetchAccountResponse;
                    }
                }
                return fetchAccountResponse;

            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in GetTinkExistingAccountList  with message {ex.Message}");
                CustomExceptionMessageLogger("GetTinkExistingAccountList", ex, logger, tinkAccountIngestionRequest);
                throw;
            }

        }

        /*Insert records into AccountList object*/
        private static void InsertTinkAccountInList(TinkAccountIngestionRequest tinkAccountIngestionRequest, FetchAccount fetchAccountdetails, ILogger logger)
        {
            try
            {
                logger.LogInformation($"InsertTinkAccountInList started for customerID {tinkAccountIngestionRequest.CustomerID}, walletID {tinkAccountIngestionRequest.WalletID}");
                foreach (var item in fetchAccountdetails.Accounts)
                {

                    var count = tinkWalletSAccountDetails.Count(a => a.CustomerID == tinkAccountIngestionRequest.CustomerID && a.IBAN == tinkAccountIngestionRequest.IBAN && a.BankID == tinkAccountIngestionRequest.BANKID && a.WalletType == tinkAccountIngestionRequest.WalletType);

                    if (count == 0)
                    {
                        TinkWalletAccount Tinkaccount = new TinkWalletAccount();
                        Tinkaccount.CustomerID = tinkAccountIngestionRequest.CustomerID;
                        Tinkaccount.IBAN = item.AccountNumber;
                        Tinkaccount.WalletType = item.Type;
                        Tinkaccount.BankID = item.BankId;
                        tinkWalletSAccountDetails.Add(Tinkaccount);
                    }
                }
                logger.LogInformation($"InsertTinkAccountInList completed for customerID {tinkAccountIngestionRequest.CustomerID} and tinkWalletSAccountDetails count = {tinkWalletSAccountDetails?.Count}");
            }
            catch (Exception ex)
            {
                logger.LogWarning($"Exception in InsertRecordsInDB with message {ex.Message}");
                CustomExceptionMessageLogger("InsertTinkAccountInList", ex, logger, tinkAccountIngestionRequest);
                throw;
            }

        }

        /*checks if WalletExistsOrNotFromList object*/
        private static TinkWalletDetails CheckWalletExistsOrNotFromList(TinkAccountIngestionRequest tinkAccountIngestionRequest, ILogger logger)
        {
            try
            {
                logger.LogInformation($"CheckWalletExistsOrNot started for customerID {tinkAccountIngestionRequest.CustomerID} and walletID - {tinkAccountIngestionRequest.WalletID}");
                TinkWalletDetails tinkWalletDetails = new TinkWalletDetails();

                TinkWalletAccount tinkWalletAccount = new TinkWalletAccount();
                int recordCount = 0;
                if (tinkAccountIngestionRequest.WalletID == "0")
                {
                    recordCount = tinkWalletSAccountDetails.Count(t => t.IBAN == tinkAccountIngestionRequest.IBAN && t.WalletType == tinkAccountIngestionRequest.WalletType);
                    var tinkAccount = tinkWalletSAccountDetails.Where(t => t.IBAN == tinkAccountIngestionRequest.IBAN && t.WalletType == tinkAccountIngestionRequest.WalletType).FirstOrDefault();

                    tinkWalletDetails.Recordcount = recordCount;
                    tinkWalletDetails.BankID = tinkAccount.BankID;
                    tinkWalletDetails.WalletId = tinkAccount.BankID.Replace(tinkAccountIngestionRequest.AccountNo, "").Replace(tinkAccountIngestionRequest.ProductID, "");

                    logger.LogInformation($"CheckWalletExistsOrNotFromList If block tinkWalletSAccountDetails for walletID {tinkWalletDetails.WalletId} - and count = {tinkWalletSAccountDetails?.Count} ");
                }
                else
                {
                    recordCount = tinkWalletSAccountDetails.Count(t => t.IBAN == tinkAccountIngestionRequest.IBAN && t.WalletType == tinkAccountIngestionRequest.WalletType && t.BankID == tinkAccountIngestionRequest.BANKID);
                    var tinkAccount = tinkWalletSAccountDetails.Where(t => t.IBAN == tinkAccountIngestionRequest.IBAN && t.WalletType == tinkAccountIngestionRequest.WalletType && t.BankID == tinkAccountIngestionRequest.BANKID).FirstOrDefault();

                    if (recordCount > 0)
                    {
                        tinkWalletDetails.Recordcount = recordCount;
                        tinkWalletDetails.BankID = tinkAccount.BankID;
                        tinkWalletDetails.WalletId = tinkAccount.BankID.Replace(tinkAccountIngestionRequest.AccountNo, "").Replace(tinkAccountIngestionRequest.ProductID, "");
                    }
                    else
                    {
                        tinkWalletDetails.Recordcount = 0;
                        tinkWalletDetails.BankID = "0";
                        tinkWalletDetails.WalletId = "0";
                    }
                    logger.LogInformation($"CheckWalletExistsOrNotFromList else block tinkWalletSAccountDetails count = {tinkWalletSAccountDetails?.Count} and record count {recordCount}");
                }

                return tinkWalletDetails;
            }
            catch (Exception ex)
            {
                logger.LogWarning($"CheckWalletExistsOrNot Exception with Message {ex.Message}");
                CustomExceptionMessageLogger("CheckWalletExistsOrNot", ex, logger, tinkAccountIngestionRequest);
                throw;
            }
        }

        /*Delete the txns on retry ingestion was successful*/
        private static TinkIngestionStatusPayload DeleteTxnsOnRetryTxnExists(TinkAccountIngestionRequest tinkAccountIngestionRequest, string walletId, string IBAN, string externalIds, ILogger logger, string transactionErrorMessage, string accountErrorMessage, string noOfTransactions)
        {
            logger.LogInformation($"DeleteTxnsOnRetryTxnExists Methos starts for walletID- {walletId} IBAN {IBAN} externalID {externalIds} with transactionMessage {transactionErrorMessage}");

            bool SBTxnIngestionStatus = true;
            bool Transaction_Error_Ids = false;
            TinkIngestionStatusPayload payload = null;
            string deleteCommand = string.Empty;
            try
            {

                if (transactionErrorMessage.Length > 0)
                    SBTxnIngestionStatus = false;

                if (externalIds.Length > 0)
                    Transaction_Error_Ids = true;

                logger.LogInformation($"DeleteTxnsOnRetryTxnExists Method Send payload to service bus started for instance {tinkAccountIngestionRequest.TestInstance}");
                payload = new TinkIngestionStatusPayload()
                {
                    CustomerId = tinkAccountIngestionRequest.CustomerID,
                    WalletID = walletId,
                    EventName = "DeleteOnRetry",
                    AccountErrorMessage = accountErrorMessage,
                    TxnErrorMessage = transactionErrorMessage,
                    TxnFromDate = tinkAccountIngestionRequest.TxnFrmDate,
                    TxnToDate = tinkAccountIngestionRequest.TxnToDate,
                    AccountIngestionStatus = false,
                    TxnIngestionStatus = SBTxnIngestionStatus,
                    IBAN = IBAN,
                    BankID = tinkAccountIngestionRequest.BANKID,
                    AccountNo = tinkAccountIngestionRequest.AccountNo,
                    ExternalId = externalIds,
                    NOOfTransactions = noOfTransactions
                };

                SendMessageeAsync(JsonConvert.SerializeObject(payload), "DeleteTxnsOnRetryTxnExists instance" + tinkAccountIngestionRequest.TestInstance, logger);
                logger.LogInformation($"DeleteTxnsOnRetryTxnExists send to serviceBus completed for instance {tinkAccountIngestionRequest.TestInstance}");
                return payload;
            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in DeleteTxnsOnRetryTxnExists with mesage {ex.Message}");
                CustomExceptionMessageLogger("DeleteTxnsOnRetryTxnExists", ex, logger, tinkAccountIngestionRequest);
                return payload;
            }
        }

        /*Fetch the user transactions and calls the TinkIngestTransaction method*/
        public static TinkIngestionStatusPayload FetchAndIngestTransaction(TinkAccountIngestionRequest tinkAccountIngestionRequest, TinkWalletDetails tinkWalletDetails, string walletID, string IBAN, ILogger logger, string accountErrorMessage)
        {
            TinkIngestionStatusPayload ingestionStatusPayload = null;
            string noOfTransactions = string.Empty;
            string transactionErrormessage = string.Empty;
            try
            {

                logger.LogInformation($"FetchAndIngestTransaction started for customerID {tinkAccountIngestionRequest.CustomerID} and walletID {tinkAccountIngestionRequest.WalletID}");
                var transactions = FetchTransactionsFromMasterList(walletID, IBAN, logger, tinkAccountIngestionRequest);

                if (transactions != null)
                    logger.LogInformation($"FetchAndIngestTransaction LINQ Filtered Data {JsonConvert.SerializeObject(transactions)}");
                else
                    logger.LogInformation($"FetchAndIngestTransaction LINQ Filtered data null");

                if (transactions?.Count > 0)
                {
                    logger.LogInformation($"FetchTransactionsFromDB completed and transactions count = {transactions?.Count}");
                    noOfTransactions = transactions?.Count.ToString();
                    TransactionAccount account = new TransactionAccount()
                    {
                        balance = tinkAccountIngestionRequest.SettledBalance,
                        externalId = tinkAccountIngestionRequest?.WalletType?.ToUpper() == "CHECKING" ? tinkWalletDetails.BankID : tinkAccountIngestionRequest.BANKID,
                        transactions = transactions
                    };
                    List<TransactionAccount> transactionAccounts = new List<TransactionAccount>();
                    transactionAccounts.Add(account);
                    var OAuthResponse = Tink_OAuth_Token(logger, tinkAccountIngestionRequest.InvokeType, tinkAccountIngestionRequest.TestInstance).Result;
                    TinkIngestTransaction(tinkAccountIngestionRequest, OAuthResponse.access_token, transactionAccounts, logger, noOfTransactions, accountErrorMessage, transactionErrormessage);
                    return ingestionStatusPayload;
                }
                else
                {
                    logger.LogInformation($"FetchAndIngestTransaction completed and transactions count = 0");
                    noOfTransactions = "0";
                    transactionErrormessage = string.Empty;

                    DeleteWalletAndTransactionsFromDB(tinkAccountIngestionRequest.WalletID, tinkAccountIngestionRequest.IBAN, transactionErrormessage, accountErrorMessage, logger, tinkAccountIngestionRequest, noOfTransactions);
                    return ingestionStatusPayload = ExecuteAuditLog(tinkAccountIngestionRequest, noOfTransactions, accountErrorMessage, transactionErrormessage, logger);

                }

            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in FetchAndIngestTransaction method with message {ex.Message}");
                CustomExceptionMessageLogger("FetchAndIngestTransaction", ex, logger, tinkAccountIngestionRequest);
                return ingestionStatusPayload;
            }
        }

        /*sends API Request to transactions Ingestion API*/
        public static async Task<HttpResponseMessage> PostAsyncTransactionAPIRequest(TinkAccountIngestionRequest tinkAccountIngestionRequest, string bearerToken, TinkIngestAPIRequest tinkIngestRequest, ILogger logger)
        {
            HttpResponseMessage response = null;
            try
            {
                HttpClient newClient = new HttpClient();


                if (_semaphoregate == null)
                    _semaphoregate = new SemaphoreSlim(Convert.ToInt16(Environment.GetEnvironmentVariable("semaphoregate_Count")));

                newClient.DefaultRequestHeaders.Clear();
                newClient.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json");
                newClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {bearerToken}");
                string ingestTransactionUrl = $"{Environment.GetEnvironmentVariable("id_tink_ingest_Transactions-url")}{tinkAccountIngestionRequest.CustomerID}/transactions";

                var obj = JsonConvert.SerializeObject(tinkIngestRequest);
                logger.LogInformation($"TinkIngestTransaction API URL {ingestTransactionUrl} and ReqObj {obj}");
                HttpContent httpContent = new StringContent(obj, Encoding.UTF8, "application/json");
                logger.LogInformation("static transactions TinkAPI called");

                string env = Environment.GetEnvironmentVariable("Environment");
                string uatUsers = Environment.GetEnvironmentVariable("Uat_Users");
                List<string> uatUsersList = new List<string>();
                uatUsersList = !string.IsNullOrEmpty(uatUsers) ? uatUsers.Split(",").ToList() : uatUsersList;
                logger.LogInformation($"Environment = {env} and uatUsers {uatUsers}");

                if (EnvironmentCheck(env, uatUsersList, tinkAccountIngestionRequest, logger))
                {
                    await _semaphoregate.WaitAsync();
                    response = newClient.PostAsync(ingestTransactionUrl, httpContent).Result;
                    var semaphoreCount = _semaphoregate.Release();
                    logger.LogInformation($"PostAsyncTransactionAPIRequest _semaphoregate count {semaphoreCount}");
                }
                else
                {
                    logger.LogInformation("set default response = NoContent ");
                    response = new HttpResponseMessage(HttpStatusCode.NoContent);

                }

                logger.LogInformation($"PostAsyncTransactionAPIRequest transactions API with status code {response.StatusCode}");
                return response;
            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in PostAsyncTransactionAPIRequest with message {ex.Message}");
                CustomExceptionMessageLogger("PostAsyncTransactionAPIRequest", ex, logger, tinkAccountIngestionRequest);
                return response;
            }

        }

        /*holds the Logic to call transactions API for retry 5 times if toomanyreq, retry on BadRequest , Conflict */
        private static FetchAccount TinkIngestTransaction(TinkAccountIngestionRequest tinkAccountIngestionRequest, string bearerToken, List<TransactionAccount> transactionsAccount, ILogger logger, string noOfTransactions, string accountErrorMessage, string transactionErrorMessage)
        {
            try
            {
                logger.LogInformation($"TinkIngestTransaction started for customerID{tinkAccountIngestionRequest.CustomerID} and walletID- {tinkAccountIngestionRequest.WalletID}");
                FetchAccount fetchAccountResponse = null;

                TinkIngestAPIRequest tinkIngestRequest = new TinkIngestAPIRequest()
                {
                    autoBook = false,
                    overridePending = false,
                    transactionAccounts = transactionsAccount,
                    type = "BATCH"

                };
                HttpResponseMessage response = null;

                logger.LogInformation($"externalID's for CustomerID: {tinkAccountIngestionRequest.CustomerID} and  walletID: {tinkAccountIngestionRequest.WalletID}: {JsonConvert.SerializeObject(transactionsAccount?.FirstOrDefault()?.transactions)}");
                logger.LogInformation($"TinkIngestTransaction PostAsyncTransactionAPIRequest started and req body {JsonConvert.SerializeObject(tinkIngestRequest)}");
                response = PostAsyncTransactionAPIRequest(tinkAccountIngestionRequest, bearerToken, tinkIngestRequest, logger).Result;
                if (response.StatusCode == HttpStatusCode.TooManyRequests)
                {
                    var OAuthResponse = Tink_OAuth_Token(logger, tinkAccountIngestionRequest.InvokeType, tinkAccountIngestionRequest.TestInstance).Result;
                    for (int i = 0; i < 5; i++)
                    {
                        response = PostAsyncTransactionAPIRequest(tinkAccountIngestionRequest, OAuthResponse.access_token, tinkIngestRequest, logger).Result;
                        if (response.StatusCode == HttpStatusCode.TooManyRequests)
                        {
                            Task.Delay(2000); // 2sec
                            logger.LogInformation($"In ForLoop continue case for UID {tinkAccountIngestionRequest.CustomerID}  PostAsyncTransactionAPIRequest response {response.StatusCode}");
                            continue;
                        }
                        else
                        {
                            logger.LogInformation($"In ForLoop break case for UID {tinkAccountIngestionRequest.CustomerID} PostAsyncTransactionAPIRequest response {response.StatusCode}");
                            break;
                        }
                    }
                }


                logger.LogInformation($"TinkIngestTransaction completed transactions API for instance {tinkAccountIngestionRequest.TestInstance} with status code {response.StatusCode}");
                if ((tinkAccountIngestionRequest.InvokeType == "SECOND" && response.StatusCode == HttpStatusCode.TooManyRequests) || response.StatusCode == HttpStatusCode.InternalServerError)
                {
                    StatusCodeMessageLogger("TinkIngestTransaction", response?.StatusCode.ToString(), logger, tinkAccountIngestionRequest);
                }

                if (response == null || response.StatusCode == HttpStatusCode.TooManyRequests)
                {
                    accountErrorMessage = string.IsNullOrEmpty(accountErrorMessage) ? "too many request" : accountErrorMessage;
                    transactionErrorMessage = "too many requests";
                    DeleteWalletAndTransactionsFromDB(tinkAccountIngestionRequest.WalletID, tinkAccountIngestionRequest.IBAN, transactionErrorMessage, accountErrorMessage, logger, tinkAccountIngestionRequest, noOfTransactions);
                    ExecuteAuditLog(tinkAccountIngestionRequest, "0", accountErrorMessage, transactionErrorMessage, logger);
                    return fetchAccountResponse;
                }
                else
                {

                    if (response.StatusCode == HttpStatusCode.NoContent)
                    {
                        logger.LogInformation($"TinkIngestTransaction response with NoContent for customerID {tinkAccountIngestionRequest.CustomerID}");
                        transactionErrorMessage = string.Empty;

                        DeleteWalletAndTransactionsFromDB(tinkAccountIngestionRequest.WalletID, tinkAccountIngestionRequest.IBAN, transactionErrorMessage, accountErrorMessage, logger, tinkAccountIngestionRequest, noOfTransactions);
                    }
                    else
                    {
                        if (response.StatusCode == HttpStatusCode.Conflict)
                        {

                            transactionErrorMessage = "Transaction Already Exists";
                            string responseContent = response.Content.ReadAsStringAsync().Result;
                            ConflictResponse conflictResponse = JsonConvert.DeserializeObject<ConflictResponse>(responseContent);

                            logger.LogInformation($"TinkIngestTransaction conflictResponse desearlize josn {JsonConvert.SerializeObject(conflictResponse)} ");

                            List<string> externalTransactionIds = conflictResponse.externalTransactionId.Split(",").ToList();
                            if (externalTransactionIds.Count > 0)
                            {
                                foreach (var item in externalTransactionIds)
                                {
                                    tinkIngestRequest.transactionAccounts.ForEach(u =>
                                    {
                                        u.transactions.RemoveAll(a => a.externalId == item);
                                    });
                                }
                            }
                            if (tinkIngestRequest.transactionAccounts?.FirstOrDefault().transactions.Count > 0)
                            {
                                logger.LogInformation($"RetryIngestTransacation started of externalID's {externalTransactionIds} and transactions count = {tinkIngestRequest.transactionAccounts.FirstOrDefault().transactions.Count} and Request body after removing externalId's {JsonConvert.SerializeObject(tinkIngestRequest)}");
                                var OAuthResponse = Tink_OAuth_Token(logger, tinkAccountIngestionRequest.InvokeType, tinkAccountIngestionRequest.TestInstance).Result;
                                var retryResponse = RetryIngestTransacation(tinkAccountIngestionRequest, OAuthResponse.access_token, tinkIngestRequest, logger);

                                if ((tinkAccountIngestionRequest.InvokeType == "SECOND" && response.StatusCode == HttpStatusCode.TooManyRequests) || response.StatusCode == HttpStatusCode.InternalServerError)
                                {
                                    StatusCodeMessageLogger("RetryIngestTransacation", response?.StatusCode.ToString(), logger, tinkAccountIngestionRequest);
                                }

                                logger.LogInformation($"RetryIngestTransacation completed for instance {tinkAccountIngestionRequest.TestInstance} with status code {retryResponse.StatusCode}");
                                if (retryResponse.StatusCode == HttpStatusCode.NoContent)
                                {

                                    transactionErrorMessage = string.Empty;
                                    DeleteWalletAndTransactionsFromDB(tinkAccountIngestionRequest.WalletID, tinkAccountIngestionRequest.IBAN, transactionErrorMessage, accountErrorMessage, logger, tinkAccountIngestionRequest, noOfTransactions);
                                }
                                else
                                {

                                    DeleteTxnsOnRetryTxnExists(tinkAccountIngestionRequest, tinkAccountIngestionRequest.WalletID, tinkAccountIngestionRequest.IBAN, conflictResponse.externalTransactionId, logger, transactionErrorMessage, accountErrorMessage, noOfTransactions);

                                }
                            }
                            else
                            {
                                logger.LogInformation($"No transaction to ingest for customerid {tinkAccountIngestionRequest.CustomerID}, wallet ID {tinkAccountIngestionRequest.WalletID}");
                                transactionErrorMessage = string.Empty;
                                DeleteWalletAndTransactionsFromDB(tinkAccountIngestionRequest.WalletID, tinkAccountIngestionRequest.IBAN, transactionErrorMessage, accountErrorMessage, logger, tinkAccountIngestionRequest, noOfTransactions);
                            }
                        }
                        else if (response.StatusCode == HttpStatusCode.BadRequest)
                        {
                            string responseContent = response.Content.ReadAsStringAsync().Result;
                            ErrorResponse errorResponse = JsonConvert.DeserializeObject<ErrorResponse>(responseContent);

                            logger.LogInformation($"RetryIngestTransacation on BadRequest started for wallet ID {tinkAccountIngestionRequest.WalletID} and error response {JsonConvert.SerializeObject(errorResponse)}");
                            /* Logic to handle the BadRequest response and remove elements from the tinkIngestRequest.transactionAccounts.transactions */
                            List<int> indexList = new List<int>();
                            if (errorResponse?.Errors.Count > 0)
                            {
                                errorResponse.Errors.ForEach(error =>
                                {

                                    var splitmsg = error.errormessage.Replace("transactionAccounts[0].transactions[", "").Split("]")[0];

                                    indexList.Add(Convert.ToInt16(splitmsg));
                                }
                                );

                                indexList = indexList.Distinct().ToList();
                                if (indexList?.Count > 0)
                                {
                                    int start = 0;
                                    int last = 1;
                                    indexList.Sort();
                                    foreach (var item in indexList)
                                    {
                                        if (start == 0)
                                        {
                                            start++;
                                            tinkIngestRequest.transactionAccounts.ForEach(u =>
                                            {
                                                u.transactions.RemoveAt(item);
                                            });
                                        }
                                        else
                                        {
                                            tinkIngestRequest.transactionAccounts.ForEach(u =>
                                            {
                                                u.transactions.RemoveAt(item - last);
                                            });
                                            last++;
                                        }
                                    }
                                }
                                /* after removing elements from the tinkIngestRequest checking transaction count if > 0 then call retry ingestion*/
                                if (tinkIngestRequest.transactionAccounts.FirstOrDefault().transactions.Count > 0)
                                {
                                    logger.LogInformation($"RetryIngestTransacation, Transactions found after removing indexs {tinkIngestRequest.transactionAccounts.FirstOrDefault().transactions.Count} and request body after index removed = {JsonConvert.SerializeObject(tinkIngestRequest)}");
                                    var OAuthResponse = Tink_OAuth_Token(logger, tinkAccountIngestionRequest.InvokeType, tinkAccountIngestionRequest.TestInstance).Result;
                                    var retryResponseFromBadRequest = RetryIngestTransacation(tinkAccountIngestionRequest, OAuthResponse.access_token, tinkIngestRequest, logger);

                                    logger.LogInformation($"RetryIngestTransacation on BadRequest completed for instance {tinkAccountIngestionRequest.TestInstance} with status code {retryResponseFromBadRequest.StatusCode}");

                                    if ((tinkAccountIngestionRequest.InvokeType == "SECOND" && response.StatusCode == HttpStatusCode.TooManyRequests) || response.StatusCode == HttpStatusCode.InternalServerError)
                                    {
                                        StatusCodeMessageLogger("RetryIngestTransacation", response?.StatusCode.ToString(), logger, tinkAccountIngestionRequest);
                                    }

                                    if (retryResponseFromBadRequest.StatusCode == HttpStatusCode.NoContent) //No content = 204 response,conflict = 409 reponse
                                    {
                                        transactionErrorMessage = "Transaction failed";

                                        var externalIDs = tinkIngestRequest.transactionAccounts.FirstOrDefault().transactions.Select(x => x.externalId).ToList();
                                        string externalIdArray = string.Join(",", externalIDs.ToArray());

                                        DeleteTxnsOnRetryTxnExists(tinkAccountIngestionRequest, tinkAccountIngestionRequest.WalletID, tinkAccountIngestionRequest.IBAN, externalIdArray, logger, transactionErrorMessage, accountErrorMessage, noOfTransactions);
                                    }
                                    else
                                    {

                                        transactionErrorMessage = "Transaction failed";
                                    }
                                }
                                else
                                {
                                    transactionErrorMessage = "Transaction failed";
                                }
                            }
                            else
                            {
                                logger.LogInformation("RetryIngestTransacation on BadReques in else part");
                                logger.LogInformation($"Very rare case ");
                                transactionErrorMessage = "Transaction failed";
                            }

                        }
                        else
                        {
                            transactionErrorMessage = $"Transaction failed from tink with statuscode {response.StatusCode}";
                            logger.LogInformation("TinkIngestTransaction Default case RetryIngestTransacation started");
                            var OAuthResponse = Tink_OAuth_Token(logger, tinkAccountIngestionRequest.InvokeType, tinkAccountIngestionRequest.TestInstance).Result;
                            var retryResponse = RetryIngestTransacation(tinkAccountIngestionRequest, OAuthResponse.access_token, tinkIngestRequest, logger);

                            logger.LogInformation($"RetryIngestTransacation on default completed for instance {tinkAccountIngestionRequest.TestInstance} with status code {retryResponse.StatusCode}");// handle ALert Trigger
                            if (retryResponse.StatusCode == HttpStatusCode.NoContent)
                            {
                                transactionErrorMessage = string.Empty;
                                DeleteWalletAndTransactionsFromDB(tinkAccountIngestionRequest.WalletID, tinkAccountIngestionRequest.IBAN, transactionErrorMessage, accountErrorMessage, logger, tinkAccountIngestionRequest, noOfTransactions);
                            }
                            if ((tinkAccountIngestionRequest.InvokeType == "SECOND" && response.StatusCode == HttpStatusCode.TooManyRequests) || response.StatusCode == HttpStatusCode.InternalServerError)
                            {
                                StatusCodeMessageLogger("RetryIngestTransacation", response?.StatusCode.ToString(), logger, tinkAccountIngestionRequest);
                            }
                        }


                        logger.LogInformation($"TinkIngestTransaction completed in else block with status code {response.StatusCode}");
                    }
                    var statusPayload = ExecuteAuditLog(tinkAccountIngestionRequest, noOfTransactions, accountErrorMessage, transactionErrorMessage, logger);
                    return fetchAccountResponse;
                }

            }
            catch (Exception ex)
            {
                logger.LogCritical($"Exception occured in TinkIngestTransaction with message {ex.Message}");
                CustomExceptionMessageLogger("TinkIngestTransaction", ex, logger, tinkAccountIngestionRequest);
                throw;
            }

        }

        /* Sends the payloads to ServiceBus for ExecuteAuditLog */
        private static TinkIngestionStatusPayload ExecuteAuditLog(TinkAccountIngestionRequest tinkAccountIngestionRequest, string noOfTransactions, string accountErrorMessage, string transactionErrorMessage, ILogger logger)
        {
            logger.LogInformation($"ExecuteAuditLog Method started");
            TinkIngestionStatusPayload payload = null;
            try
            {
                logger.LogInformation($"ExecuteAuditLog Method Send payload to service bus started for instance {tinkAccountIngestionRequest.TestInstance} and Index {tinkAccountIngestionRequest.Index}");

                payload = new TinkIngestionStatusPayload()
                {
                    CustomerId = tinkAccountIngestionRequest.CustomerID,
                    ProductID = tinkAccountIngestionRequest.ProductID,
                    WalletID = tinkAccountIngestionRequest.WalletID,
                    EventName = "ExecuteAuditLog",
                    AccountErrorMessage = accountErrorMessage,
                    TxnErrorMessage = transactionErrorMessage,
                    TxnFromDate = tinkAccountIngestionRequest.TxnFrmDate,
                    TxnToDate = tinkAccountIngestionRequest.TxnToDate,
                    AccountIngestionStatus = false,
                    TxnIngestionStatus = false,
                    IBAN = tinkAccountIngestionRequest.IBAN,
                    BankID = tinkAccountIngestionRequest.BANKID,
                    AccountNo = tinkAccountIngestionRequest.AccountNo,
                    ExternalId = string.Empty,
                    NOOfTransactions = noOfTransactions
                };

                SendMessageeAsync(JsonConvert.SerializeObject(payload), "ExecuteAuditLog for instance " + tinkAccountIngestionRequest.TestInstance, logger);
                logger.LogInformation($"ExecuteAuditLog send to serviceBus completed  for instance {tinkAccountIngestionRequest.TestInstance}");
                return payload;
            }
            catch (Exception ex)
            {
                logger.LogError($"Exception occured in ExecuteAuditLog while establishing connection to DB: {ex.Message}");
                CustomExceptionMessageLogger("ExecuteAuditLog", ex, logger, tinkAccountIngestionRequest);
                return payload;
            }
        }

        /* API Request for Transaction on retry*/
        private static HttpResponseMessage RetryIngestTransacation(TinkAccountIngestionRequest tinkAccountIngestionRequest, string bearerToken, TinkIngestAPIRequest retryTinkTransactionsAccount, ILogger logger)
        {
            HttpResponseMessage response = null;
            try
            {
                logger.LogInformation($"RetryIngestTransacation method started for customerID {tinkAccountIngestionRequest.CustomerID}");
                response = PostAsyncTransactionAPIRequest(tinkAccountIngestionRequest, bearerToken, retryTinkTransactionsAccount, logger).Result;
                if (response.StatusCode == HttpStatusCode.TooManyRequests)
                {
                    var OAuthResponse = Tink_OAuth_Token(logger, tinkAccountIngestionRequest.InvokeType, tinkAccountIngestionRequest.TestInstance).Result;
                    for (int i = 0; i < 5; i++)
                    {
                        response = PostAsyncTransactionAPIRequest(tinkAccountIngestionRequest, OAuthResponse.access_token, retryTinkTransactionsAccount, logger).Result;
                        if (response.StatusCode == HttpStatusCode.TooManyRequests)
                        {
                            logger.LogInformation($"In ForLoop continue block RetryIngestTransacation responsecode {response.StatusCode}");
                            Task.Delay(2000);
                            continue;
                        }
                        else
                        {
                            logger.LogInformation($"In ForLoop break block RetryIngestTransacation responsecode {response.StatusCode}");
                            break;
                        }
                    }
                }
                return response;
            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in RetryIngestTransacation method with message {ex.Message}");
                CustomExceptionMessageLogger("RetryIngestTransacation", ex, logger, tinkAccountIngestionRequest);
                return response;
            }
        }

        /* Fetch user level txrns from MasterTxnsList Object */
        private static List<Transactions> FetchTransactionsFromMasterList(string walletID, string IBAN, ILogger logger, TinkAccountIngestionRequest tinkAccountIngestionRequest)
        {
            logger.LogInformation($"FetchTransactionsFromMasterList LINQ started for walletID {walletID} and IBAN {IBAN}");
            logger.LogInformation($"FetchTransactionsFromMasterList LINQ Master List Count {tinkAccountIngestionRequest.TxnMasterData.Count}");
            try
            {
                List<Transactions> transactionsList = new List<Transactions>();

                var transactions = tinkAccountIngestionRequest.TxnMasterData.Where(x => x.WalletID == walletID && x.IBAN == IBAN).ToList();

                if (transactions != null)
                    logger.LogInformation($"FetchTransactionsFromMasterList LINQ Filtered Data {JsonConvert.SerializeObject(transactions)}");
                else
                    logger.LogInformation($"FetchTransactionsFromMasterList LINQ Filtered data null");

                foreach (var item in transactions)
                {
                    Transactions transactiondata = new Transactions()
                    {
                        type = item.type,
                        externalId = item.externalId,
                        description = item.description,
                        amount = item.amount,
                        date = item.date,
                        pending = item.pending
                    };
                    transactionsList.Add(transactiondata);
                }

                logger.LogInformation($"FetchTransactionsFromMasterList with LINQ query completed with response for customerID: {tinkAccountIngestionRequest.CustomerID} and walletID {tinkAccountIngestionRequest.WalletType}, response {JsonConvert.SerializeObject(transactionsList)} and count : {transactionsList.Count}");
                return transactionsList;
            }
            catch (Exception ex)
            {
                logger.LogWarning($"Exception in FetchTransactionsFromMasterList LINQ with Message {ex.Message}");
                CustomExceptionMessageLogger("FetchTransactionsFromMasterList", ex, logger, tinkAccountIngestionRequest);
                throw;
            }
        }

        /* sends API request to AccountAPI Ingestion */
        public static async Task<HttpResponseMessage> PostAsyncAccountsAPIRequest(string bearerToken, TinkAccountIngestionRequest tinkAccountIngestionRequest, AccountIngestionRequest accountIngestionRequest, ILogger logger)
        {
            HttpResponseMessage response = null;
            try
            {
                HttpClient newClient = new HttpClient();


                if (_semaphoregate == null)
                    _semaphoregate = new SemaphoreSlim(Convert.ToInt16(Environment.GetEnvironmentVariable("semaphoregate_Count")));

                newClient.DefaultRequestHeaders.Clear();
                newClient.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json");
                newClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {bearerToken}");
                string AccountIngestionUrl = $"{Environment.GetEnvironmentVariable("id_tink_ingest_Account-url")}{tinkAccountIngestionRequest.CustomerID}/accounts";
                logger.LogInformation($"TinkIngestWallet AccountIngestion URL {AccountIngestionUrl}");

                HttpContent httpContent = new StringContent(JsonConvert.SerializeObject(accountIngestionRequest), Encoding.UTF8, "application/json");
                string env = Environment.GetEnvironmentVariable("Environment");
                string uatUsers = Environment.GetEnvironmentVariable("Uat_Users");
                List<string> uatUsersList = new List<string>();
                uatUsersList = !string.IsNullOrEmpty(uatUsers) ? uatUsers.Split(",").ToList() : uatUsersList;
                logger.LogInformation($"Envirnoment = {env} and uatUsers {uatUsers}");

                if (EnvironmentCheck(env, uatUsersList, tinkAccountIngestionRequest, logger))
                {
                    await _semaphoregate.WaitAsync();
                    response = newClient.PostAsync(AccountIngestionUrl, httpContent).Result;
                    var semaphoreCount = _semaphoregate.Release();
                    logger.LogInformation($"PostAsyncAccountsAPIRequest _semaphoregate count {semaphoreCount}");
                }
                else
                {
                    logger.LogInformation("Flag set sending default response = nocontent");
                    response = new HttpResponseMessage(HttpStatusCode.NoContent);
                }
                return response;
            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in TriggerAccountsAPI Method with message {ex.Message}");
                CustomExceptionMessageLogger("PostAsyncAccountsAPIRequest", ex, logger, tinkAccountIngestionRequest);
                return response;
            }

        }

        /*holds the Logic to call Accounts API for retry 5 times if toomanyreq, retry on BadRequest , Conflict */
        public static TinkIngestionStatusPayload TinkIngestWallet(TinkAccountIngestionRequest tinkAccountIngestionRequest, string bearerToken, TinkWalletDetails tinkWalletDetails, ILogger logger, string accountErrorMessage)
        {
            TinkIngestionStatusPayload payload = null;
            try
            {
                logger.LogInformation($"TinkIngestWallet started for customerID: {tinkAccountIngestionRequest.CustomerID} and walletID {tinkAccountIngestionRequest.WalletID}");

                List<Accounts> accountList = new List<Accounts>();
                Accounts account = new Accounts()
                {
                    availableCredit = "0",
                    externalId = tinkAccountIngestionRequest.BANKID,
                    closed = false,
                    exclusion = "NONE",
                    name = tinkAccountIngestionRequest.WalletType?.ToUpper() == "CHECKING" ? "An Post current account" : tinkAccountIngestionRequest.WalletType?.ToUpper() == "SAVINGS" ? $"Savings jars-{tinkAccountIngestionRequest.WalletNickName}" : tinkAccountIngestionRequest.WalletNickName, //Need to use boomi logic
                    number = tinkAccountIngestionRequest.IBAN,
                    type = tinkAccountIngestionRequest.WalletType?.ToUpper() == "EMERGENCY" ? "SAVINGS" : tinkAccountIngestionRequest.WalletType, // Need to use boomi logic
                    balance = tinkAccountIngestionRequest.SettledBalance,
                };
                accountList.Add(account);

                AccountIngestionRequest accountIngestionRequest = new AccountIngestionRequest()
                {
                    accounts = accountList
                };

                logger.LogInformation("static accounts TinkAPI called");
                HttpResponseMessage response = null;
                logger.LogInformation($"TinkIngestWallet req body for walletId - {tinkAccountIngestionRequest.WalletID} : {JsonConvert.SerializeObject(accountIngestionRequest)}");

                response = PostAsyncAccountsAPIRequest(bearerToken, tinkAccountIngestionRequest, accountIngestionRequest, logger).Result;
                if (response.StatusCode == HttpStatusCode.TooManyRequests)
                {
                    var bearerTokenInLoop = GetBearerToken(tinkAccountIngestionRequest, logger);
                    for (int i = 0; i <= 5; i++)
                    {
                        response = PostAsyncAccountsAPIRequest(bearerTokenInLoop, tinkAccountIngestionRequest, accountIngestionRequest, logger).Result;
                        if (response.StatusCode == HttpStatusCode.TooManyRequests)
                        {
                            logger.LogInformation($"In forLoop continue PostAsyncAccountsAPI response {response.StatusCode}");
                            Task.Delay(2000);
                            continue;
                        }
                        else
                        {
                            logger.LogInformation($"In forLoop break PostAsyncAccountsAPI response {response.StatusCode}");
                            break;
                        }
                    }
                }

                logger.LogInformation($"TinkIngestWallet completed for instance {tinkAccountIngestionRequest.TestInstance} with status code {response.StatusCode}");
                if ((tinkAccountIngestionRequest.InvokeType == "SECOND" && response.StatusCode == HttpStatusCode.TooManyRequests) || response.StatusCode == HttpStatusCode.InternalServerError)
                {
                    StatusCodeMessageLogger("TinkIngestWallet", response?.StatusCode.ToString(), logger, tinkAccountIngestionRequest);
                }

                if (response == null || response.StatusCode == HttpStatusCode.TooManyRequests)
                {
                    accountErrorMessage = string.IsNullOrEmpty(accountErrorMessage) ? "too many request" : accountErrorMessage;
                    string transactionErrorMessage = "too many requests";
                    ExecuteAuditLog(tinkAccountIngestionRequest, "0", accountErrorMessage, transactionErrorMessage, logger);
                    return payload;
                }
                else
                {
                    if (response.StatusCode == HttpStatusCode.NoContent)
                    {
                        accountErrorMessage = string.Empty;
                        payload = FetchAndIngestTransaction(tinkAccountIngestionRequest, tinkWalletDetails, tinkAccountIngestionRequest.WalletID, tinkAccountIngestionRequest.IBAN, logger, accountErrorMessage);
                        return payload;
                    }
                    else
                    {
                        if (response.StatusCode == HttpStatusCode.Conflict)
                        {
                            accountErrorMessage = "Account already exists";
                            payload = FetchAndIngestTransaction(tinkAccountIngestionRequest, tinkWalletDetails, tinkAccountIngestionRequest.WalletID, tinkAccountIngestionRequest.IBAN, logger, accountErrorMessage);

                        }
                        else
                        {
                            var OAuthResponse = Tink_OAuth_Token(logger, tinkAccountIngestionRequest.InvokeType, tinkAccountIngestionRequest.TestInstance).Result;
                            var retrywalletIngestResponse = RetryIngestWallet(tinkAccountIngestionRequest, OAuthResponse.access_token, accountIngestionRequest, logger).Result;
                            logger.LogInformation($"RetryIngestWallet StatusCode for CustomerID {tinkAccountIngestionRequest.CustomerID} and statusCode {retrywalletIngestResponse.StatusCode}");
                            if (retrywalletIngestResponse.StatusCode == HttpStatusCode.NoContent)
                            {
                                accountErrorMessage = string.Empty;
                                payload = FetchAndIngestTransaction(tinkAccountIngestionRequest, tinkWalletDetails, tinkAccountIngestionRequest.WalletID, tinkAccountIngestionRequest.IBAN, logger, accountErrorMessage);
                                return payload;
                            }
                            else if (retrywalletIngestResponse.StatusCode == HttpStatusCode.Conflict)//need to handle
                            {
                                accountErrorMessage = "Account already exists";
                                payload = FetchAndIngestTransaction(tinkAccountIngestionRequest, tinkWalletDetails, tinkAccountIngestionRequest.WalletID, tinkAccountIngestionRequest.IBAN, logger, accountErrorMessage);
                            }
                            else
                            {
                                if ((tinkAccountIngestionRequest.InvokeType == "SECOND" && response.StatusCode == HttpStatusCode.TooManyRequests) || response.StatusCode == HttpStatusCode.InternalServerError)
                                {
                                    StatusCodeMessageLogger("RetryIngestWallet", response?.StatusCode.ToString(), logger, tinkAccountIngestionRequest);
                                }
                                logger.LogInformation($"Wallet Ingestion failed for CustomerID {tinkAccountIngestionRequest.CustomerID} and walletID {tinkAccountIngestionRequest.WalletID} with statuscode {response.StatusCode}");

                            }
                        }

                        logger.LogInformation($"Tink walletIngestion completed in else block with status code {response.StatusCode}");
                    }
                    return payload;
                }
            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in TinkIngestWallet with message {ex.Message}");
                CustomExceptionMessageLogger("TinkIngestWallet", ex, logger, tinkAccountIngestionRequest);
                return payload;
            }

        }

        /* sends the API Request for Accountslevel on retry*/
        public static async Task<HttpResponseMessage> RetryIngestWallet(TinkAccountIngestionRequest tinkAccountIngestionRequest, string bearerToken, AccountIngestionRequest accountIngestionRequest, ILogger logger)
        {
            HttpResponseMessage response = null;
            try
            {

                logger.LogInformation($"RetryIngestWallet started for customerID {tinkAccountIngestionRequest.CustomerID} and walletID {tinkAccountIngestionRequest.WalletID}");
                HttpClient newClient = new HttpClient();


                if (_semaphoregate == null)
                    _semaphoregate = new SemaphoreSlim(Convert.ToInt16(Environment.GetEnvironmentVariable("semaphoregate_Count")));

                newClient.DefaultRequestHeaders.Clear();
                newClient.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json");
                newClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {bearerToken}");
                string AccountIngestionUrl = $"{Environment.GetEnvironmentVariable("id_tink_ingest_Account-url")}{tinkAccountIngestionRequest.CustomerID}/accounts";

                logger.LogInformation($"RetryIngestWallet AccountIngestion URL {AccountIngestionUrl}");
                var objs = JsonConvert.SerializeObject(accountIngestionRequest);
                HttpContent httpContent = new StringContent(JsonConvert.SerializeObject(accountIngestionRequest), Encoding.UTF8, "application/json");
                logger.LogInformation("static accounts TinkAPI called");

                string env = Environment.GetEnvironmentVariable("Environment");
                string uatUsers = Environment.GetEnvironmentVariable("Uat_Users");
                List<string> uatUsersList = new List<string>();
                uatUsersList = !string.IsNullOrEmpty(uatUsers) ? uatUsers.Split(",").ToList() : uatUsersList;
                logger.LogInformation($"Environment = {env} and uatUsers {uatUsers}");

                if (EnvironmentCheck(env, uatUsersList, tinkAccountIngestionRequest, logger))
                {
                    await _semaphoregate.WaitAsync();
                    response = newClient.PostAsync(AccountIngestionUrl, httpContent).Result;
                    var semaphoreCount = _semaphoregate.Release();
                    logger.LogInformation($"RetryIngestWallet _semaphoregate count {semaphoreCount}");
                }
                else
                {
                    logger.LogInformation("Flag set sending default response Nocontent");
                    response = new HttpResponseMessage(HttpStatusCode.NoContent);
                }
                logger.LogInformation($"Tink_OAuth_Grant completed for instance {tinkAccountIngestionRequest.TestInstance} with status code {response.StatusCode}");

                return response;

            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in RetryIngestWallet with message {ex.Message}");
                CustomExceptionMessageLogger("RetryIngestWallet", ex, logger, tinkAccountIngestionRequest);
                throw;
            }

        }

        /* Delete wallet & Txns after ingestion is successful */
        public static void DeleteWalletAndTransactionsFromDB(string wallet, string IBAN, string transactionErrorMessage, string accountErrorMessage, ILogger logger, TinkAccountIngestionRequest tinkAccountIngestionRequest, string noOfTransactions)
        {
            try
            {

                logger.LogInformation($"DeleteWalletAndTransactionsFromDB method Started for customerID {tinkAccountIngestionRequest.CustomerID}, walletID {wallet} AccountError message = {accountErrorMessage} and Transaction error message = {transactionErrorMessage}, wallet {wallet}");
                string connectionString = Environment.GetEnvironmentVariable("Db_Con_String");
                bool SBAccountIngestionStatus = true, SBTxnIngestionStatus = true;

                if (accountErrorMessage.Length > 0 && !accountErrorMessage.Equals("Account already exists")) /*sets the flag for AccountIngestionStatus which is used in DB task func app to delete the records*/
                {
                    SBAccountIngestionStatus = false;
                }
                if (transactionErrorMessage.Length > 0 && !transactionErrorMessage.Equals("Transaction Already Exists")) /*sets the flag for SBTxnIngestionStatus which is used in DB task func app to delete the records*/
                {
                    SBTxnIngestionStatus = false;
                }
                logger.LogInformation($"SBAccountIngestionStatus = {SBAccountIngestionStatus} and SBTxnIngestionStatus = {SBTxnIngestionStatus}");

                List<Transactions> transactionsList = new List<Transactions>();

                logger.LogInformation($"DeleteWalletAndTransactionsFromDB Method send payload to service bus started for instance {tinkAccountIngestionRequest.TestInstance} and Index {tinkAccountIngestionRequest.Index} ");
                TinkIngestionStatusPayload payload = new TinkIngestionStatusPayload()
                {
                    CustomerId = tinkAccountIngestionRequest.CustomerID,
                    WalletID = wallet,
                    EventName = "DeleteOnSuccess",
                    AccountErrorMessage = accountErrorMessage,
                    TxnErrorMessage = transactionErrorMessage,
                    TxnFromDate = tinkAccountIngestionRequest.TxnFrmDate,
                    TxnToDate = tinkAccountIngestionRequest.TxnToDate,
                    AccountIngestionStatus = SBAccountIngestionStatus,
                    TxnIngestionStatus = SBTxnIngestionStatus,
                    IBAN = IBAN,
                    BankID = tinkAccountIngestionRequest.Index,// need to change
                    AccountNo = tinkAccountIngestionRequest.AccountNo,
                    ExternalId = string.Empty,
                    NOOfTransactions = noOfTransactions
                };

                SendMessageeAsync(JsonConvert.SerializeObject(payload), "DeleteWalletAndTransactionsFromDB for instance " + tinkAccountIngestionRequest.TestInstance, logger);
                logger.LogInformation("DeleteWalletAndTransactionsFromDB send to serviceBus completed");

            }
            catch (Exception ex)
            {
                logger.LogWarning($"Exception in DeleteWalletAndTransactionsFromDB with message {ex.Message}");
                CustomExceptionMessageLogger("DeleteWalletAndTransactionsFromDB", ex, logger, tinkAccountIngestionRequest);
                throw;
            }
        }

        /* Generates the Auth_Grant token */
        public static async Task<TinkGrantResponse> Tink_OAuth_Grant(string bearerToken, string external_userid, ILogger logger, string invokeType, string instance)
        {
            try
            {
                logger.LogInformation($"Tink_OAuth_Grant started");
                TinkGrantResponse tinkGrantResponse = null;
                HttpClient newClient = new HttpClient();

                if (_semaphoregate == null)
                    _semaphoregate = new SemaphoreSlim(Convert.ToInt16(Environment.GetEnvironmentVariable("semaphoregate_Count")));

                newClient.DefaultRequestHeaders.Clear();
                newClient.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/x-www-form-urlencoded");// "grant_type=client_credentials&client_id=3f9464d18ffc49e79e57cdc6f1775d82&client_secret=f3f187583e8146f8a170edb58cf8555d&scope=authorization:grant,user:create,user:delete,accounts:read,\naccounts:write,transactions:read,transactions:write,user:read"
                newClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {bearerToken}");
                string tink_Auth_Api_Url = Tink_Auth_Grant_Api_Url;

                logger.LogInformation($"Tink_OAuth_Grant URL {tink_Auth_Api_Url}");
                HttpContent httpContent = new StringContent($"external_user_id={external_userid}&scope=transactions:read,provider-consents:read, user:web_hooks,user:delete,accounts:read,user:read,user:write");
                logger.LogInformation("static grant TinkAPI call");
                await _semaphoregate.WaitAsync();
                HttpResponseMessage response = null;
                response = newClient.PostAsync(tink_Auth_Api_Url, httpContent).Result;

                if (response.StatusCode == HttpStatusCode.TooManyRequests)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        response = newClient.PostAsync(tink_Auth_Api_Url, httpContent).Result;
                        if (response.StatusCode == HttpStatusCode.TooManyRequests)
                        {
                            logger.LogInformation($"In forLoop continue Tink_OAuth_Grant response {response.StatusCode}");
                            continue;
                        }
                        else
                        {
                            logger.LogInformation($"In forLoop break Tink_OAuth_Grant response {response.StatusCode}");
                            break;
                        }

                    }
                }
                var semaphoreCount = _semaphoregate.Release();
                logger.LogInformation($"Tink_OAuth_Grant _semaphoregate count {semaphoreCount}");
                string responseContent = response.Content.ReadAsStringAsync().Result;
                logger.LogInformation($"Tink_OAuth_Grant completed for instance {instance} with status code {response.StatusCode}");

                if ((invokeType == "SECOND" && response.StatusCode == HttpStatusCode.TooManyRequests) || response.StatusCode == HttpStatusCode.InternalServerError)
                {
                    StatusCodeMessageLogger("Tink_OAuth_Grant", response?.StatusCode.ToString(), logger);
                }
                if (response.IsSuccessStatusCode)
                {
                    tinkGrantResponse = JsonConvert.DeserializeObject<TinkGrantResponse>(responseContent);
                    return tinkGrantResponse;
                }
                return tinkGrantResponse;


            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in Tink_OAuth_Grant with message {ex.Message}");
                CustomExceptionMessageLogger("Tink_OAuth_Grant", ex, logger);
                throw;
            }

        }

        /* Generates the OAuth_userAccess token */
        public static async Task<TinkAuthResponse> Tink_OAuth_UserAccess(string bearerToken, string code, ILogger logger, string invokeType, string instance)
        {
            try
            {
                logger.LogInformation("Tink_OAuth_UserAccess started");
                TinkAuthResponse tinkAuthResponse = null;
                HttpClient newClient = new HttpClient();


                if (_semaphoregate == null)
                    _semaphoregate = new SemaphoreSlim(Convert.ToInt16(Environment.GetEnvironmentVariable("semaphoregate_Count")));

                newClient.DefaultRequestHeaders.Clear();
                newClient.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/x-www-form-urlencoded");// "grant_type=client_credentials&client_id=3f9464d18ffc49e79e57cdc6f1775d82&client_secret=f3f187583e8146f8a170edb58cf8555d&scope=authorization:grant,user:create,user:delete,accounts:read,\naccounts:write,transactions:read,transactions:write,user:read"
                newClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {bearerToken}");
                string tink_Auth_Api_Url = Tink_Auth_Api_Url;

                logger.LogInformation($"Tink_OAuth_UserAccess URL {tink_Auth_Api_Url}");
                logger.LogInformation("Tink_OAuth_UserAccess URL ID: " + TinkClientID + " / " + TinkClientSecret);
                HttpContent httpContent = new StringContent($"client_id={TinkClientID}&client_secret={TinkClientSecret}&grant_type=authorization_code&code={code}");
                logger.LogInformation("static userAccess TinkAPI called");
                await _semaphoregate.WaitAsync();
                HttpResponseMessage response = null;
                response = newClient.PostAsync(tink_Auth_Api_Url, httpContent).Result;
                if (response.StatusCode == HttpStatusCode.TooManyRequests)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        response = newClient.PostAsync(tink_Auth_Api_Url, httpContent).Result;
                        if (response.StatusCode == HttpStatusCode.TooManyRequests)
                        {
                            logger.LogInformation($"In forLoop continue Tink_OAuth_UserAccess response {response.StatusCode}");
                            continue;
                        }
                        else
                        {
                            logger.LogInformation($"In forLoop break Tink_OAuth_UserAccess response {response.StatusCode}");
                            break;
                        }

                    }
                }
                var semaphoreCount = _semaphoregate.Release();
                logger.LogInformation($"Tink_OAuth_UserAccess _semaphoregate count {semaphoreCount}");
                string responseContent = response.Content.ReadAsStringAsync().Result;
                logger.LogInformation($"Tink_OAuth_UserAccess completed for instance {instance} with status code {response.StatusCode}");
                if ((invokeType == "SECOND" && response.StatusCode == HttpStatusCode.TooManyRequests) || response.StatusCode == HttpStatusCode.InternalServerError)
                {
                    StatusCodeMessageLogger("Tink_OAuth_UserAccess", response?.StatusCode.ToString(), logger);
                }

                if (response.IsSuccessStatusCode)
                {
                    tinkAuthResponse = JsonConvert.DeserializeObject<TinkAuthResponse>(responseContent);
                    return tinkAuthResponse;
                }
                return tinkAuthResponse;

            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in Tink_OAuth_UserAccess with message {ex.Message}");
                CustomExceptionMessageLogger("Tink_OAuth_UserAccess", ex, logger);
                throw;
            }

        }

        /* Generates the OAuth_Token */
        public static async Task<TinkAuthResponse> Tink_OAuth_Token(ILogger logger, string invokeType, string instance)
        {
            try
            {
                logger.LogInformation("Tink_OAuth_Token started");
                TinkAuthResponse tinkAuthResponse = null;
                HttpClient newClient = new HttpClient();


                if (_semaphoregate == null)
                    _semaphoregate = new SemaphoreSlim(Convert.ToInt16(Environment.GetEnvironmentVariable("semaphoregate_Count")));

                newClient.DefaultRequestHeaders.Clear();

                newClient.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/x-www-form-urlencoded");
                string tink_Auth_url = Tink_Auth_Api_Url;

                logger.LogInformation($"Tink_OAuth_Token URL {tink_Auth_url}");
                logger.LogInformation("Tink_OAuth_Token ID: " + TinkClientID + " / " + TinkClientSecret);
                HttpContent httpContent = new StringContent($"grant_type=client_credentials&client_id={TinkClientID}&client_secret={TinkClientSecret}&scope=authorization:grant,user:create,user:delete,accounts:read,accounts:write,transactions:read,transactions:write,user:read");
                logger.LogInformation("static OAuth TinkAPI called");
                await _semaphoregate.WaitAsync();
                HttpResponseMessage response = null;
                response = newClient.PostAsync(tink_Auth_url, httpContent).Result;
                if (response.StatusCode == HttpStatusCode.TooManyRequests)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        response = newClient.PostAsync(tink_Auth_url, httpContent).Result;
                        if (response.StatusCode == HttpStatusCode.TooManyRequests)
                        {
                            logger.LogInformation($"In forLoop continue Tink_OAuth_Token response {response.StatusCode}");
                            continue;
                        }
                        else
                        {
                            logger.LogInformation($"In forLoop break Tink_OAuth_Token response {response.StatusCode}");
                            break;
                        }

                    }
                }
                var semaphoreCount = _semaphoregate.Release();
                var responseContent = response.Content.ReadAsStringAsync().Result;

                logger.LogInformation($"Tink_OAuth_Token _semaphoregate count {semaphoreCount}");
                //Test_Instance = string.IsNullOrEmpty(Test_Instance) ? Environment.GetEnvironmentVariable("Test_Instance") : Test_Instance;
                logger.LogInformation($"Tink_OAuth_Token completed for instance {instance} with status code {response.StatusCode}");

                if ((invokeType == "SECOND" && response.StatusCode == HttpStatusCode.TooManyRequests) || response.StatusCode == HttpStatusCode.InternalServerError)
                {
                    StatusCodeMessageLogger("Tink_OAuth_Token", response?.StatusCode.ToString(), logger);
                }

                if (response.IsSuccessStatusCode)
                {
                    tinkAuthResponse = JsonConvert.DeserializeObject<TinkAuthResponse>(responseContent);
                    return tinkAuthResponse;
                }
                return tinkAuthResponse;
            }
            catch (Exception ex)
            {
                CustomExceptionMessageLogger("Tink_OAuth_Token", ex, logger);
                logger.LogError($"Exception in Tink_OAuth_Token with message {ex.Message}");
                throw;
            }
        }

        /* Method will incorporate all Token Api's and returns the final token */
        public static string GetBearerToken(TinkAccountIngestionRequest tinkAccountIngestionRequest, ILogger logger)
        {
            try
            {
                logger.LogInformation($"GetBearerToken started for UID {tinkAccountIngestionRequest.CustomerID}");

                var authResponse = Tink_OAuth_Token(logger, tinkAccountIngestionRequest.InvokeType, tinkAccountIngestionRequest.TestInstance).Result;
                var grantResponse = Tink_OAuth_Grant(authResponse.access_token, tinkAccountIngestionRequest.CustomerID, logger, tinkAccountIngestionRequest.InvokeType, tinkAccountIngestionRequest.TestInstance).Result;
                var userAccessResponse = Tink_OAuth_UserAccess(authResponse.access_token, grantResponse.code, logger, tinkAccountIngestionRequest.InvokeType, tinkAccountIngestionRequest.TestInstance).Result;

                logger.LogInformation($"GetBearerToken completed and Token {userAccessResponse.access_token}");
                return userAccessResponse.access_token;
            }
            catch (Exception ex)
            {
                logger.LogError($"Exception in GetBearerToken {ex.Message}");

                throw;
            }

        }

        /* Get all the Env values */
        public static void GetAllEnvironmentVariables(ILogger logger)
        {

            connectionStringForDB = Environment.GetEnvironmentVariable("Db_Con_String");
            TinkClientID = Environment.GetEnvironmentVariable("kvs-tink-clientId");
            TinkClientSecret = Environment.GetEnvironmentVariable("kvs-tink-clientsecret");

            ServiceBus_Conn_String = Environment.GetEnvironmentVariable("id-tink-useraccess-api-url");
            Tink_Auth_Grant_Api_Url = Environment.GetEnvironmentVariable("id-tink-grant-api-url");
            Tink_AccountFetch_Api_Url = Environment.GetEnvironmentVariable("id-tink-fetchaccount-api-url");
            Tink_Auth_Api_Url = Environment.GetEnvironmentVariable("id-tink-useraccess-api-url");
            logger.LogInformation("Tink id: " + TinkClientID + " / " + TinkClientSecret);
            logger.LogInformation("Tink Auth url: " + Tink_Auth_Api_Url);
            logger.LogInformation("Tink Grant url: " + Tink_Auth_Grant_Api_Url);
            logger.LogInformation("Tink AccountFetch url: " + Tink_AccountFetch_Api_Url);
            logger.LogInformation("GetAllEnvironmentVariables completed");
        }

        /* Sends the payloads of DelteTxns,DeleteWallet&Txns and ExecuteAuditLog payloads to ServiceBus topic DB Subscriber FuncApp */
        public static void SendMessageeAsync(string statusPayload, string source, ILogger logger)
        {

            try
            {
                if (sender == null)
                {
                    serviceBusClient = new ServiceBusClient(Environment.GetEnvironmentVariable("Service_Bus_Con_String"));
                    sender = serviceBusClient.CreateSender(Environment.GetEnvironmentVariable("Service_Bus_Topic"));
                }

                ServiceBusMessage message = new ServiceBusMessage(statusPayload);

                try
                {
                    logger.LogInformation($"Static Durable SendMessagesAsync started for {source}");
                    sender.SendMessageAsync(message);
                    logger.LogInformation($"Static Durable SendMessagesAsync completed for {source}");
                }
                catch (Exception ex)
                {
                    logger.LogError($"Exception occured in Static Durable sendMessageAsync method, while sending payloads to topic : {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                logger.LogError($"Exception occured in Static Durable while establishing connection to service bus topic : {ex.Message}");
                CustomExceptionMessageLogger("SendMessageeAsync", ex, logger);
            }
        }

        [FunctionName("StaticDurableFunc_HttpStart")]
        public static async Task<HttpResponseMessage> HttpStart(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post")] HttpRequestMessage req,
            [DurableClient] IDurableOrchestrationClient starter,
            ILogger log)
        {
            var data = await req.Content.ReadAsAsync<TxnToDateRequest>();
            log.LogInformation($"Started orchestration Datetime {DateTime.Now}");

            string instanceId = await starter.StartNewAsync("StaticMMOrchestrator", data);

            log.LogInformation($"Completed orchestration with ID = '{instanceId}'. Datetime {DateTime.Now}");

            return starter.CreateCheckStatusResponse(req, instanceId);
        }
    }
}

using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Security.Cryptography;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;
using System.Collections.Generic;
using JWT.Algorithms;
using JWT.Serializers;
using JWT;
using System.Text;

namespace TinkIngestion
{
    public static class GenerateJWTToken
    {
        [FunctionName("GenerateJWTToken")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("TinkIngestion GenerateJWTToken Started");

            string productId = req.Query["productId"];
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);

            productId = productId ?? data?.productId;
            log.LogInformation("productId: ", productId);

            string token = GenerateJWTOmnioToken(productId, log);

            return new OkObjectResult(token);
        }
        public static string GenerateJWTOmnioToken(string productId, ILogger log)
        {
            try
            {
                var OmnioToken = new OmnioToken();
                var AzureKeyVault = new AzureKeyVault();

                OmnioToken.OmnioRSAKeyPgpEncrypted = AzureKeyVault.GetAzureSecretValue(AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.ominoKeyVault), AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.encryptSecretName));
                OmnioToken.PgpPrivateKeyBase64Encoded = AzureKeyVault.GetAzureSecretValue(AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.ominoKeyVault), AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.pgpSecretName));
                OmnioToken.PgpCertificatePassPhrase = AzureKeyVault.GetAzureSecretValue(AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.ominoKeyVault), AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.passPhrase));

                //log.LogInformation("OmnioRSAKeyPgpEncrypted key: " + AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.encryptSecretName) + ", value: " + AzureKeyVault.GetAzureSecretValue(AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.ominoKeyVault), AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.encryptSecretName)));
                //log.LogInformation("PgpPrivateKey key: " + AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.pgpSecretName) + ", value: " + AzureKeyVault.GetAzureSecretValue(AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.ominoKeyVault), AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.pgpSecretName)));
                //log.LogInformation("PassPhrase key: " + AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.passPhrase) + ", value: " + AzureKeyVault.GetAzureSecretValue(AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.ominoKeyVault), AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.passPhrase)));

                var rsaParams = ReadAsymmetricKeyParameter(OmnioToken.OmnioRSAKeyPgpEncrypted, OmnioToken.PgpPrivateKeyBase64Encoded, OmnioToken.PgpCertificatePassPhrase, log);

                //log.LogInformation("ReadAsymmetricKeyParameter method execution done");

                var encoder = GetRS256JWTEncoder(rsaParams, log);

                //log.LogInformation("GetRS256JWTEncoder method execution done");

                OmnioToken.Iat = DateTimeOffset.UtcNow.ToUnixTimeSeconds() / 1000L;
                OmnioToken.Nbf = OmnioToken.Iat;
                OmnioToken.Expiry = DateTimeOffset.UtcNow.AddMinutes(60).ToUnixTimeSeconds();
                OmnioToken.Issue = constants.OmnioKeys.issue;
                OmnioToken.Audience = constants.OmnioKeys.audience;
                OmnioToken.Ckey = AzureKeyVault.GetAzureSecretValue(AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.ominoKeyVault), AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.cKeySecretName));
                OmnioToken.CSecret = AzureKeyVault.GetAzureSecretValue(AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.ominoKeyVault), AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.cKeyPwdSecretName));
                OmnioToken.Pkhash = AzureKeyVault.GetAzureSecretValue(AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.ominoKeyVault), AzureKeyVault.GetEnvironmentVariable(constants.AzureKeysSecrets.pkhashSecretName));
                var payload = new Dictionary<string, object>{
                    {   "iss",OmnioToken.Issue},
                    {   "aud",OmnioToken.Audience },
                    {   "ckey",OmnioToken.Ckey},
                    {   "csecret",OmnioToken.CSecret},
                    {   "pkhash",OmnioToken.Pkhash },
                    {   "custref", productId},
                    {   "iat",OmnioToken.Iat},
                    {   "nbf",OmnioToken.Nbf },
                    {   "exp",OmnioToken.Expiry}
                };

                //Final token
                var token = encoder.Encode(payload, new byte[0]);
                log.LogInformation("Final token generated");
                return token;
            }
            catch (Exception ex)
            {
                log.LogError("GenerateJWTOmnioToken Exception message: " + ex.Message + ", StackTrace: " + ex.StackTrace);
                throw;
            }
        }
        private static IJwtEncoder GetRS256JWTEncoder(RSAParameters rsaParams, ILogger log)
        {
            try
            {
                var csp = new RSACryptoServiceProvider();
                csp.ImportParameters(rsaParams);
                var algorithm = new RS256Algorithm(csp, csp);
                var serializer = new JsonNetSerializer();
                var urlEncoder = new JwtBase64UrlEncoder();
                var encoder = new JwtEncoder(algorithm, serializer, urlEncoder);
                return encoder;
            }
            catch (Exception ex)
            {
                log.LogError("GetRS256JWTEncoder Exception Message: " + ex.Message + ", StackTrace: " + ex.StackTrace);
                throw;
            }
        }


        public static RSAParameters ReadAsymmetricKeyParameter(string pkey, string privateKey, string passPhrase, ILogger log)
        {
            try
            {
                var messageKeyBytes = Encoding.ASCII.GetBytes(pkey);

                var pgp = new Pgp();

                var strdecrypt = PGPDecryptString(privateKey);

                //log.LogInformation("PGPDecryptString: " + strdecrypt);

                var privateKeyBytes = Encoding.ASCII.GetBytes(strdecrypt);

                //log.LogInformation("privateKeyBytes: " + privateKeyBytes);

                Stream keyStream = new MemoryStream(privateKeyBytes);

                ASCIIEncoding ascii = new ASCIIEncoding();
                var decryptedData = Pgp.Decrypt(messageKeyBytes, keyStream, passPhrase, log);
                var stringData = Encoding.ASCII.GetString(decryptedData);

                //log.LogInformation("stringData before: " + stringData);

                stringData = stringData.Replace("\r\n", "").Replace("\n", "").Replace("-----BEGIN PRIVATE KEY-----", "").Replace("-----END PRIVATE KEY-----", "");

                //log.LogInformation("stringData after: " + stringData);

                RsaPrivateCrtKeyParameters rsaPrivateCrtKeyParameters;
                var keyBytes = Convert.FromBase64String(stringData);
                var asymmetricKeyParameter = PrivateKeyFactory.CreateKey(keyBytes);
                rsaPrivateCrtKeyParameters = (RsaPrivateCrtKeyParameters)asymmetricKeyParameter;
                RSAParameters rsaParameters = DotNetUtilities.ToRSAParameters(rsaPrivateCrtKeyParameters);
                return rsaParameters;
            }
            catch (Exception ex)
            {
                log.LogError("ReadAsymmetricKeyParameter Exception Message: " + ex.Message + ", StackTrace: " + ex.StackTrace);
                throw;
            }
        }

        public static string PGPDecryptString(string encrString)
        {
            byte[] b;
            string decrypted;
            try
            {
                b = Convert.FromBase64String(encrString);
                decrypted = System.Text.ASCIIEncoding.ASCII.GetString(b);
            }
            catch (FormatException fe)
            {
                decrypted = "";
            }
            return decrypted;
        }

    }
}

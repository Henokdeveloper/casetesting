﻿using Microsoft.Extensions.Logging;
using Org.BouncyCastle.Bcpg;
using Org.BouncyCastle.Bcpg.OpenPgp;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Utilities.IO;
using System;
using System.IO;
using System.Text;


namespace TinkIngestion
{
    public class Pgp
    {
        private const int BufferSize = 512;

        /**
        * Search a secret key ring collection for a secret key corresponding to
        * keyId if it exists.
        *
        * @param pgpSec a secret key ring collection.
        * @param keyId keyId we want.
        * @param pass passphrase to decrypt secret key with.
        * @return
        */
        private static PgpPrivateKey FindSecretKey(PgpSecretKeyRingBundle pgpSec, long keyId, char[] pass)
        {
            PgpSecretKey pgpSecKey = pgpSec.GetSecretKey(keyId);
            if (pgpSecKey == null)
                return null;

            return pgpSecKey.ExtractPrivateKey(pass);
        }

        /**
        * Decrypt the byte array passed into inputData and return it as
        * another byte array.
        *
        * @param inputData - the data to decrypt
        * @param keyIn - a stream from your private keyring file
        * @param passCode - the password
        * @return - decrypted data as byte array
        */
        public static byte[] Decrypt(byte[] inputData, Stream keyIn, string passCode, ILogger log)
        {
            byte[] error = Encoding.ASCII.GetBytes("ERROR");

            Stream inputStream = new MemoryStream(inputData);
            inputStream = PgpUtilities.GetDecoderStream(inputStream);
            MemoryStream decoded = new MemoryStream();

            try
            {
                PgpObjectFactory pgpF = new PgpObjectFactory(inputStream);

                string pgpFData = pgpF != null ? "not null" : "null";
                log.LogInformation("PgpObjectFactory data:" + pgpFData);

                PgpEncryptedDataList enc;
                PgpObject o = pgpF.NextPgpObject();

                string oData = o != null ? "not null" : "null";
                log.LogInformation("PgpObject data:" + oData);

                //
                //the first object might be a PGP marker packet.

                if (o is PgpEncryptedDataList)
                {
                    //log.LogInformation("PgpEncryptedDataList using PgpObject start");
                    enc = (PgpEncryptedDataList)o;
                    //log.LogInformation("PgpEncryptedDataList using PgpObject end");
                }
                else
                {
                    //log.LogInformation("PgpEncryptedDataList using PgpObjectFactory start");
                    enc = (PgpEncryptedDataList)pgpF.NextPgpObject();
                    //log.LogInformation("PgpEncryptedDataList using PgpObjectFactory end");
                }

                string cnt = enc != null ? enc.Count.ToString() : "null";
                log.LogInformation("PgpEncryptedDataList count:" + cnt);

                //
                // find the secret key
                //
                PgpPrivateKey sKey = null;
                PgpPublicKeyEncryptedData pbe = null;

                PgpSecretKeyRingBundle pgpSec = new PgpSecretKeyRingBundle(
                PgpUtilities.GetDecoderStream(keyIn));

                foreach (PgpPublicKeyEncryptedData pked in enc.GetEncryptedDataObjects())
                {
                    sKey = FindSecretKey(pgpSec, pked.KeyId, passCode.ToCharArray());
                    if (sKey != null)
                    {
                        pbe = pked;
                        break;
                    }
                }
                if (sKey == null)
                {
                    log.LogError("secret key for message not found.");
                    throw new ArgumentException("secret key for message not found.");
                }

                Stream clear = pbe.GetDataStream(sKey);
                PgpObjectFactory plainFact = new PgpObjectFactory(clear);
                PgpObject message = plainFact.NextPgpObject();

                if (message is PgpCompressedData)
                {
                    PgpCompressedData cData = (PgpCompressedData)message;
                    PgpObjectFactory pgpFact = new PgpObjectFactory(cData.GetDataStream());
                    message = pgpFact.NextPgpObject();
                }
                if (message is PgpLiteralData)
                {
                    PgpLiteralData ld = (PgpLiteralData)message;
                    Stream unc = ld.GetInputStream();
                    PipeAll(unc, decoded);
                }
                else if (message is PgpOnePassSignatureList)
                {
                    log.LogError("encrypted message contains a signed message - not literal data.");
                    throw new PgpException("encrypted message contains a signed message - not literal data.");
                }
                else
                {
                    log.LogError("message is not a simple encrypted file - type unknown.");
                    throw new PgpException("message is not a simple encrypted file - type unknown.");
                }

                return decoded.ToArray();
            }
            catch (Exception ex)
            {
                log.LogError("Decrypt Exception: " + ex.Message + ", StackTrace: " + ex.StackTrace);
                return error;
            }
        }

        public static void PipeAll(Stream inStr, Stream outStr)
        {
            byte[] bs = new byte[BufferSize];
            int numRead;
            while ((numRead = inStr.Read(bs, 0, bs.Length)) > 0)
            {
                outStr.Write(bs, 0, numRead);
            }
        }
    }

}


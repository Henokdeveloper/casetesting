﻿using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using System;

namespace TinkIngestion
{
    class AzureKeyVault
    {
        public string GetAzureSecretValue(string keyvault, string secret)
        {

            Console.WriteLine(secret);
            var client = new SecretClient(new Uri("https://" + keyvault + ".vault.azure.net"), new DefaultAzureCredential());

            var secrettoken = client.GetSecret(secret).Value;

            return secrettoken.Value;
        }

        public static string GetEnvironmentVariable(string name)

        {
            return System.Environment.GetEnvironmentVariable(name, EnvironmentVariableTarget.Process);

        }
    }
    }

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TinkIngestion.Domain
{
    public class TinkIngestionStatusPayload
    {
        public string CustomerId { get; set; }
        public string ProductID { get; set; }
        public string AccountNo { get; set; }
        public string WalletID { get; set; }
        public string NOOfTransactions { get; set; }
        public string TxnFromDate { get; set; }
        public string TxnToDate { get; set; }
        public string AccountErrorMessage { get; set; }
        public string TxnErrorMessage { get; set; }
        public string EventName { get; set; }
        public string ExternalId { get; set; } //need in AccountIngestion
        public string Balance { get; set; }//need in AccountIngestion
        public string IBAN { get; set; } //need in AccountIngestion
        public string Name { get; set; }//need in AccountIngestion
        public string Type { get; set; }
        public string CRN { get; set; }
        public string BankID { get; set; }
        public bool AccountIngestionStatus { get; set; }
        public bool TxnIngestionStatus { get; set; }
    }
}

